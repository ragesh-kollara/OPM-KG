"""Change package: turn a set of generated / modified rules into review-ready deliverables.

  <name>.docx        change package for review: requirement, summary, each change with its
                     rule (OPM styles), validation, impact, example results and test scenarios
  <name>_rules.docx  just the rules in OPM styles, to paste into Policy Modeling rule documents
  <name>_tests.xlsx  test scenarios with expected results (one sheet per change) + example checks
"""
from __future__ import annotations

import datetime as dt
import os
import re
from typing import Optional

from .authoring import _ensure_styles, _ids, format_rule, validate_rule, write_rule
from .requirements import check_examples, generate_test_cases


def _slug(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9_\-]+", "_", s).strip("_")[:60] or "change_package"


def assess_changes(store, changes: list[dict], today: Optional[str] = None,
                   max_cases: int = 24) -> list[dict]:
    """Validate, test and example-check each change. Change fields:
    rule_text (required), name, change_id, requirement_ref, rationale, replacing_rule_id,
    examples [{inputs, expected, name}]"""
    out = []
    all_texts = [format_rule(c["rule_text"]) for c in changes]
    for i, ch in enumerate(changes, start=1):
        text = format_rule(ch["rule_text"])
        replacing = _ids(ch.get("replacing_rule_id"))
        others = [t for j, t in enumerate(all_texts) if j != i - 1]
        v = validate_rule(store, text, replacing, others)
        tests = generate_test_cases(text, max_cases=max_cases, today=today)
        ex = check_examples(text, ch.get("examples") or [], store=None, today=today,
                            supporting_rules=others) if ch.get("examples") else None
        ok = v["valid"] and (ex is None or ex["all_pass"])
        out.append({
            "change_id": ch.get("change_id") or f"C{i}",
            "name": ch.get("name"),
            "type": "Modified" if replacing else "New",
            "replacing_rule_id": replacing,
            "requirement_ref": ch.get("requirement_ref"),
            "rationale": ch.get("rationale"),
            "rule_text": text,
            "conclusion": (v.get("conclusions") or [{}])[0].get("attribute"),
            "validation": v, "tests": tests, "examples": ex,
            "status": "READY" if ok else "NEEDS WORK",
            "simulated": not any("unsupported" in c for c in tests["cases"]),
        })
    return out


def export_change_package(store, title: str, requirement: str, changes: list[dict], out_dir: str,
                          file_name: Optional[str] = None, author: Optional[str] = None,
                          today: Optional[str] = None) -> dict:
    import docx
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.shared import Pt, RGBColor

    os.makedirs(out_dir, exist_ok=True)
    base = _slug(file_name or title)
    assessed = assess_changes(store, changes, today=today)

    # ---------------- review document --------------------------------------------------------
    doc = docx.Document()
    _ensure_styles(doc)
    st = doc.styles["Normal"]
    st.font.name = "Calibri"
    st.font.size = Pt(10.5)
    doc.add_heading(title, 0)
    meta = f"Generated {dt.date.today().isoformat()}"
    if author:
        meta += f" · {author}"
    doc.add_paragraph(meta).runs[0].font.color.rgb = RGBColor(0x66, 0x66, 0x66)
    ready = all(a["status"] == "READY" for a in assessed)
    p = doc.add_paragraph()
    r = p.add_run("Overall status: " + ("READY FOR POLICY MODELING" if ready else "NEEDS WORK"))
    r.bold = True
    r.font.color.rgb = RGBColor(0x1E, 0x7B, 0x34) if ready else RGBColor(0xB0, 0x3A, 0x2E)

    doc.add_heading("Business requirement", 1)
    for para in requirement.strip().splitlines():
        if para.strip():
            doc.add_paragraph(para.strip())

    doc.add_heading("Summary of changes", 1)
    t = doc.add_table(rows=1, cols=6)
    t.style = "Light Grid Accent 1"
    t.alignment = WD_TABLE_ALIGNMENT.LEFT
    for c, h in enumerate(["ID", "Req.", "Type", "Attribute concluded", "Replaces", "Status"]):
        t.rows[0].cells[c].text = h
    for a in assessed:
        row = t.add_row().cells
        for c, v in enumerate([a["change_id"], a["requirement_ref"] or "", a["type"],
                               a["conclusion"] or "", "\n".join(a["replacing_rule_id"]) or "\u2014", a["status"]]):
            row[c].text = str(v)

    for a in assessed:
        doc.add_heading(f"{a['change_id']} · {a['name'] or a['conclusion']}", 1)
        if a["rationale"]:
            doc.add_paragraph(a["rationale"])
        for rid in a["replacing_rule_id"]:
            old = store.get_rule(rid)
            if old.get("found"):
                doc.add_heading("Current rule" + (" (to be replaced)" if len(a["replacing_rule_id"]) == 1
                                                  else " (to be removed / merged)"), 2)
                doc.add_paragraph(f"{old['id']}").runs[0].italic = True
                write_rule(doc, old["text"])
        doc.add_heading("New rule" if a["type"] == "New" else "Proposed rule", 2)
        write_rule(doc, a["rule_text"], a["name"])

        v = a["validation"]
        doc.add_heading("Validation", 2)
        if not v["errors"] and not v["warnings"]:
            doc.add_paragraph("No errors or warnings.")
        for e in v["errors"]:
            doc.add_paragraph("Error: " + e, style="List Bullet")
        for w in v["warnings"]:
            doc.add_paragraph("Warning: " + w, style="List Bullet")
        for i_ in v.get("info", []):
            doc.add_paragraph("Note: " + i_, style="List Bullet")
        new_attrs = [c["attribute"] for c in v.get("conditions", []) + v.get("conclusions", [])
                     if not c.get("exists") and not c.get("defined_in_this_change")]
        if new_attrs:
            doc.add_paragraph("New attributes to add to the data model: " + "; ".join(sorted(set(new_attrs))))

        imp = next(iter(v.get("impact", {}).values()), None)
        doc.add_heading("Impact", 2)
        if imp and (imp["affected_attributes"] or imp["affected_rules"]):
            doc.add_paragraph("Attributes affected downstream: " +
                              ("; ".join(imp["affected_attributes"]) or "none"))
            doc.add_paragraph("Rules to retest: " + ("; ".join(imp["affected_rules"]) or "none"))
        else:
            doc.add_paragraph("Nothing in the current rulebase uses this conclusion yet.")

        if a["examples"]:
            doc.add_heading("Requirement examples", 2)
            et = doc.add_table(rows=1, cols=4)
            et.style = "Light Grid Accent 1"
            for c, h in enumerate(["Example", "Expected", "Actual", "Result"]):
                et.rows[0].cells[c].text = h
            for res in a["examples"]["results"]:
                row = et.add_row().cells
                for c, val in enumerate([res["example"], _fmt(res["expected"]), _fmt(res["actual"]),
                                         "Pass" if res["pass"] else "FAIL"]):
                    row[c].text = str(val)

        tc = a["tests"]
        doc.add_heading("Test scenarios", 2)
        if tc.get("note"):
            doc.add_paragraph("Warning: " + tc["note"])
        cases = tc["cases"][:24]
        if cases and cases[0]["inputs"]:
            cols = list(cases[0]["inputs"])
            tt = doc.add_table(rows=1, cols=len(cols) + 1)
            tt.style = "Light Grid Accent 1"
            for c, h in enumerate(cols + [a["conclusion"] or "result"]):
                tt.rows[0].cells[c].text = h
            for case in cases:
                row = tt.add_row().cells
                for c, h in enumerate(cols):
                    row[c].text = _fmt(case["inputs"].get(h))
                row[len(cols)].text = _fmt(case["expected"]) if "unsupported" not in case else "n/a"
            if len(tc["cases"]) > 24:
                doc.add_paragraph(f"{len(tc['cases']) - 24} more scenarios in the test workbook.")
        else:
            doc.add_paragraph("This rule has no inputs to vary.")

    doc.add_heading("Applying the changes", 1)
    for step in [
        f"Open {base}_rules.docx - every rule uses the OPM styles (conclusion, level 1..n, rule tables).",
        "For modified rules, replace the rule(s) named in 'Replaces'. When several rules are listed, "
        "keep the new rule in the first rule's document and delete the others.",
        "For new rules, paste into the relevant rule document and add any new attributes to the data model.",
        "Build the project in Policy Modeling and fix any compile messages.",
        f"Run the scenarios in {base}_tests.xlsx (or add them as test cases) and compare results.",
        "Rebuild the knowledge graph and call reload_graph.",
    ]:
        doc.add_paragraph(step, style="List Number")
    review_path = os.path.join(out_dir, f"{base}.docx")
    doc.save(review_path)

    # ---------------- rules only -----------------------------------------------------------------
    rdoc = docx.Document()
    _ensure_styles(rdoc)
    rdoc.add_paragraph(title, style="OPM - heading 1")
    for a in assessed:
        cmt = f"{a['change_id']}" + (f" ({a['requirement_ref']})" if a["requirement_ref"] else "") + \
              (f" - replaces {', '.join(a['replacing_rule_id'])}" if a["replacing_rule_id"] else " - new rule")
        write_rule(rdoc, a["rule_text"], a["name"], cmt)
        rdoc.add_paragraph("")
    rules_path = os.path.join(out_dir, f"{base}_rules.docx")
    rdoc.save(rules_path)

    # ---------------- tests workbook ----------------------------------------------------------
    import openpyxl
    from openpyxl.styles import Font, PatternFill
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    hdr_font, hdr_fill = Font(bold=True, color="FFFFFF"), PatternFill("solid", fgColor="2F5597")
    for a in assessed:
        ws = wb.create_sheet(_slug(a["change_id"])[:31])
        cases = a["tests"]["cases"]
        cols = list(cases[0]["inputs"]) if cases else []
        ws.append(["Scenario"] + cols + [f"Expected: {a['conclusion']}"])
        for k, case in enumerate(cases, start=1):
            ws.append([f"{a['change_id']}-{k:02d}"] + [_fmt(case["inputs"].get(c)) for c in cols] +
                      [_fmt(case["expected"])])
        for c in ws[1]:
            c.font, c.fill = hdr_font, hdr_fill
        for col in ws.columns:
            ws.column_dimensions[col[0].column_letter].width = min(48, max(12, max(len(str(x.value or "")) for x in col) + 2))
        ws.freeze_panes = "B2"
    ex_rows = [(a["change_id"], r) for a in assessed if a["examples"] for r in a["examples"]["results"]]
    if ex_rows:
        ws = wb.create_sheet("Requirement examples")
        ws.append(["Change", "Example", "Expected", "Actual", "Result"])
        for cid, r in ex_rows:
            ws.append([cid, r["example"], _fmt(r["expected"]), _fmt(r["actual"]), "Pass" if r["pass"] else "FAIL"])
        for c in ws[1]:
            c.font, c.fill = hdr_font, hdr_fill
    tests_path = os.path.join(out_dir, f"{base}_tests.xlsx")
    wb.save(tests_path)

    return {
        "status": "READY" if ready else "NEEDS WORK",
        "files": {"review": review_path, "rules": rules_path, "tests": tests_path},
        "changes": [{"change_id": a["change_id"], "status": a["status"], "type": a["type"],
                     "conclusion": a["conclusion"], "errors": a["validation"]["errors"],
                     "warnings": a["validation"]["warnings"],
                     "examples": (f"{a['examples']['passed']}/{a['examples']['passed'] + a['examples']['failed']} pass"
                                  if a["examples"] else "none given"),
                     "branches_never_reached": a["tests"]["branches_never_reached"],
                     "test_cases": len(a["tests"]["cases"])} for a in assessed],
    }


def _fmt(v) -> str:
    if v is None:
        return "unknown"
    if v is True:
        return "true"
    if v is False:
        return "false"
    return str(v)
