"""Command line: build the knowledge graph from a rulebase export and load it into Neo4j.

  python -m opm_kg.cli inspect  <export.zip|folder>
  python -m opm_kg.cli build    <export.zip|folder> -o graph.json [--cypher graph.cypher]
  python -m opm_kg.cli neo4j    graph.json --uri bolt://localhost:7687 --user neo4j --password ... [--keep-existing]
  python -m opm_kg.cli validate graph.json rule.txt [--replacing <rule id>]
"""
from __future__ import annotations

import argparse
import json
import os
import sys

from .graph import GraphStore, build_graph, graph_from_json, graph_to_json
from .parsers import inspect_source, load_rulebase


def main(argv=None):
    ap = argparse.ArgumentParser(prog="opm-kg")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("inspect", help="show files / XML structure of an export")
    p.add_argument("source")

    p = sub.add_parser("build", help="parse rulebase and write graph JSON (+ optional Cypher)")
    p.add_argument("source")
    p.add_argument("-o", "--out", default="graph.json")
    p.add_argument("--cypher", help="also write a .cypher load script")
    p.add_argument("--name", help="rulebase name")

    p = sub.add_parser("neo4j", help="load graph JSON into Neo4j")
    p.add_argument("graph")
    p.add_argument("--uri", default=os.environ.get("NEO4J_URI", "bolt://localhost:7687"))
    p.add_argument("--user", default=os.environ.get("NEO4J_USER", "neo4j"))
    p.add_argument("--password", default=os.environ.get("NEO4J_PASSWORD"))
    p.add_argument("--database", default=os.environ.get("NEO4J_DATABASE"))
    p.add_argument("--keep-existing", action="store_true",
                   help="do not delete existing OPM nodes first (default: replace them, so reloading "
                        "never duplicates relationships)")

    p = sub.add_parser("validate", help="validate a proposed rule (plain text) against graph JSON")
    p.add_argument("graph")
    p.add_argument("rule_file")
    p.add_argument("--replacing")

    a = ap.parse_args(argv)

    if a.cmd == "inspect":
        print(inspect_source(a.source))
    elif a.cmd == "build":
        rb = load_rulebase(a.source, a.name)
        g = build_graph(rb)
        with open(a.out, "w", encoding="utf-8") as fh:
            json.dump(graph_to_json(g), fh, indent=1)
        if a.cypher:
            from .neo4j_store import export_cypher
            export_cypher(g, a.cypher)
        st = GraphStore(g).stats()
        print(json.dumps(st, indent=2))
        for w in rb.warnings:
            print("WARNING:", w, file=sys.stderr)
        print(f"wrote {a.out}" + (f" and {a.cypher}" if a.cypher else ""))
    elif a.cmd == "neo4j":
        from .neo4j_store import load_to_neo4j
        if not a.password:
            ap.error("--password or NEO4J_PASSWORD required")
        with open(a.graph, encoding="utf-8") as fh:
            g = graph_from_json(json.load(fh))
        print(json.dumps(load_to_neo4j(g, a.uri, a.user, a.password, a.database, not a.keep_existing), indent=2))
    elif a.cmd == "validate":
        from .authoring import validate_rule
        store = GraphStore.from_file(a.graph)
        with open(a.rule_file, encoding="utf-8") as fh:
            print(json.dumps(validate_rule(store, fh.read(), a.replacing), indent=2))


if __name__ == "__main__":
    main()
