"""Backend-independent lineage / impact / cycle logic.

Both the in-memory GraphStore and Neo4jStore implement three primitives and inherit the rest,
so answers are identical whichever backend is used:

  _attr_key(text)            -> attribute key or None (resolves negative forms / curly quotes)
  _dep_edges(keys, direction)-> [{"from", "to", "to_text", "rule", "to_is_base"}]
                                direction "up": attribute -> what it depends on
                                direction "down": attribute -> what depends on it
  _rules_using(keys)         -> sorted rule ids that USE any of the keys
  _all_dep_pairs()           -> [(from_key, to_key, from_text, to_text)] for cycle detection
"""
from __future__ import annotations

import networkx as nx


class TraversalMixin:
    MAX_DEPTH = 50

    def _walk_keys(self, key: str, direction: str, depth: int) -> list[dict]:
        depth = max(1, min(int(depth), self.MAX_DEPTH))
        seen = {key: 0}
        out = []
        frontier = [key]
        level = 0
        while frontier and level < depth:
            level += 1
            nxt = []
            for e in sorted(self._dep_edges(frontier, direction),
                            key=lambda x: (x["to_text"] or "", x["rule"] or "")):
                if e["to"] in seen:
                    continue
                seen[e["to"]] = level
                out.append({"attribute": e["to_text"], "depth": level, "via_rule": e["rule"],
                            "is_base_attribute": bool(e["to_is_base"])})
                nxt.append(e["to"])
            frontier = nxt
        return out

    def upstream(self, text: str, depth: int = 10) -> dict:
        """Everything the attribute depends on (its inputs, transitively)."""
        key = self._attr_key(text)
        if not key:
            return {"found": False, "suggestions": self.suggest(text)}
        items = self._walk_keys(key, "up", depth)
        return {"found": True, "attribute": self._attr_text(key), "dependencies": items,
                "base_inputs": sorted({i["attribute"] for i in items if i["is_base_attribute"]})}

    def downstream(self, text: str, depth: int = 10) -> dict:
        """Impact analysis: attributes and rules affected if this attribute changes."""
        key = self._attr_key(text)
        if not key:
            return {"found": False, "suggestions": self.suggest(text)}
        items = self._walk_keys(key, "down", depth)
        keys = [key] + [self._attr_key(i["attribute"]) for i in items]
        return {"found": True, "attribute": self._attr_text(key), "affected_attributes": items,
                "affected_rules": self._rules_using([k for k in keys if k])}

    def depends_on_closure(self, text: str) -> set[str]:
        key = self._attr_key(text)
        if not key:
            return set()
        seen, frontier = {key}, [key]
        while frontier:
            nxt = []
            for e in self._dep_edges(frontier, "up"):
                if e["to"] not in seen:        # dedupe within the level too (fan-in graphs)
                    seen.add(e["to"])
                    nxt.append(e["to"])
            frontier = nxt
        seen.discard(key)
        return seen

    def dependency_cycles(self, limit: int = 20) -> list[list[str]]:
        dep = nx.DiGraph()
        text = {}
        for a, b, ta, tb in self._all_dep_pairs():
            dep.add_edge(a, b)
            text[a], text[b] = ta, tb
        cycles = []
        for c in nx.simple_cycles(dep):
            cycles.append([text[k] for k in c])
            if len(cycles) >= limit:
                break
        return cycles
