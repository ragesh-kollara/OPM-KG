"""From business requirement to rules: context retrieval, test generation and example checking.

The language model writes the rules; this module gives it the facts it needs and checks the result:

  requirement_context(store, text)   what already exists that the requirement touches
  generate_test_cases(rule_text)     boundary / combination scenarios with expected outcomes
  check_examples(rule_text, examples) does the rule reproduce the requirement's worked examples?
"""
from __future__ import annotations

import itertools
import random
import re
from typing import Optional

from .evaluator import Evaluator, Unsupported, _jsonable, evaluate_rule
from .model import norm
from .rule_text import parse_indented, refs_from_lines

_STOP = set("""a an the of to in for and or if is are be been being was were will shall should must
may can could would not no nor with without by on at as from into than then that this these those
it its their them they he she his her who whom which what when where while also only such any all
each every both either per new existing rule rules requirement requirements br system""".split())

_INTENT = {
    "modify": r"\b(change|changed|modify|amend|update|increase|decrease|raise|raised|lower|reduce|"
              r"replace|instead|now|no longer|from \S+ to)\b",
    "add": r"\b(add|introduce|new|create|additional|also)\b",
    "remove": r"\b(remove|delete|withdraw|abolish|discontinue|no longer)\b",
}


def _phrases(text: str) -> list[str]:
    """Candidate search phrases: quoted terms, then content-word n-grams."""
    out = [m.group(1) for m in re.finditer(r'["“]([^"”]+)["”]', text)]
    words = [w for w in re.findall(r"[A-Za-z][A-Za-z\-']+", text.lower())]
    content = [w for w in words if w not in _STOP and len(w) > 2]
    for n in (3, 2):
        for i in range(len(content) - n + 1):
            out.append(" ".join(content[i:i + n]))
    out.extend(content)
    seen, uniq = set(), []
    for p in out:
        if p not in seen:
            seen.add(p)
            uniq.append(p)
    return uniq


def _numbers(text: str) -> list[str]:
    """Numbers in the requirement, ignoring requirement ids such as BR-101 or REQ_7."""
    return sorted({m.group(0).replace(",", "") for m in
                   re.finditer(r"(?<![\w.\-])\d[\d,]*(\.\d+)?(?![\w\-])", text)}, key=lambda x: float(x))


def requirement_context(store, requirement: str, max_attributes: int = 25, max_rules: int = 12) -> dict:
    """Everything in the rulebase a requirement is likely to touch."""
    attr_scores: dict[str, float] = {}
    attr_info: dict[str, dict] = {}
    rule_scores: dict[str, float] = {}
    phrases = _phrases(requirement)
    for weight, p in enumerate(phrases[:60]):
        w = 3.0 if " " in p else 1.0
        for hit in store.search(p, limit=8):
            if hit["type"] == "Attribute":
                attr_scores[hit["text"]] = attr_scores.get(hit["text"], 0) + w * hit["score"]
                attr_info[hit["text"]] = hit
            elif hit["type"] == "Rule":
                rule_scores[hit["id"]] = rule_scores.get(hit["id"], 0) + w * hit["score"]

    top_attrs = sorted(attr_scores, key=lambda a: -attr_scores[a])[:max_attributes]
    attributes = []
    for text in top_attrs:
        a = store.get_attribute(text)
        if not a.get("found"):
            continue
        for r in a["concluded_by"]:
            rule_scores[r["id"]] = rule_scores.get(r["id"], 0) + attr_scores[text]
        attributes.append({
            "text": a["text"], "type": a.get("type"), "entity": a.get("entity"),
            "negative_text": a.get("negative_text"),
            "kind": "derived" if a["concluded_by"] else "base input",
            "concluded_by": [r["id"] for r in a["concluded_by"]],
            "used_by_rules": len(a["used_by"]),
            "relevance": round(attr_scores[text], 2),
        })

    nums = _numbers(requirement)
    # rules that literally contain a threshold mentioned in the requirement (ignore 0-3: too common)
    for n in [n for n in nums if float(n) > 3 or "." in n]:
        for rid in store.rules_containing(n):
            rule_scores[rid] = rule_scores.get(rid, 0) + 80
    rules = []
    for rid in sorted(rule_scores, key=lambda r: -rule_scores[r])[:max_rules * 2]:
        r = store.get_rule(rid)
        if not r.get("found"):
            continue
        hits = [n for n in nums if re.search(rf"(?<![\w.]){re.escape(n)}(?![\w.])", r["text"] or "")]
        rules.append({"id": r["id"], "document": r["document"], "name": r.get("name"),
                      "text": r["text"], "concludes": r["concludes"],
                      "contains_requirement_numbers": hits,
                      "relevance": round(rule_scores[rid] + 5 * len(hits), 2)})
    rules.sort(key=lambda r: -r["relevance"])
    rules = rules[:max_rules]
    # attributes concluded by number-matching rules belong in the attribute list too
    listed = {a["text"] for a in attributes}
    for r in rules:
        if r["contains_requirement_numbers"]:
            for c in r["concludes"]:
                if c not in listed:
                    a = store.get_attribute(c)
                    if a.get("found"):
                        listed.add(a["text"])
                        attributes.append({
                            "text": a["text"], "type": a.get("type"), "entity": a.get("entity"),
                            "negative_text": a.get("negative_text"), "kind": "derived",
                            "concluded_by": [x["id"] for x in a["concluded_by"]],
                            "used_by_rules": len(a["used_by"]),
                            "relevance": r["relevance"]})

    intents = [k for k, pat in _INTENT.items() if re.search(pat, requirement, re.I)]
    diag = store.diagnostics()
    touched = {a["text"] for a in attributes}
    multi = [m for m in diag["attributes_proven_by_multiple_rules"] if m["attribute"] in touched]

    examples = [a["text"] for a in attributes[:8]]
    return {
        "requirement": requirement,
        "intent": intents or ["unclear"],
        "numbers_in_requirement": nums,
        "relevant_attributes": attributes,
        "relevant_rules": rules,
        "existing_problems_in_scope": {"attributes_proven_by_multiple_rules": multi},
        "phrasing_examples": examples,
        "guidance": [
            "Reuse the exact text of relevant_attributes; only invent a new attribute when nothing fits.",
            "If a relevant rule already concludes the attribute you need, MODIFY it (validate with "
            "replacing_rule_id) instead of writing a second rule.",
            "Rules whose contains_requirement_numbers is non-empty are the likeliest places a changed "
            "threshold lives.",
            "Write new attribute text in the same style as phrasing_examples.",
        ],
    }


# ----------------------------------------------------------------------------------------------
# tests
# ----------------------------------------------------------------------------------------------
def _boundary(op: str, lit) -> list:
    if isinstance(lit, str):
        return [lit, lit + "_other"]
    step = 1 if float(lit).is_integer() else 0.01
    vals = {lit - step, lit, lit + step}
    return sorted(_jsonable(v) for v in vals)


def _inputs(rule_text: str) -> dict[str, list]:
    """Input attributes of one rule and the values worth testing for each."""
    refs, _ = refs_from_lines(parse_indented(rule_text))
    concl = {r.key for r in refs if r.role == "conclusion"}
    domain: dict[str, set] = {}
    display: dict[str, str] = {}
    for r in refs:
        if r.role != "condition" or r.key in concl:
            continue
        key = r.key
        display.setdefault(key, r.text)
        vals = domain.setdefault(key, set())
        if r.operator in ("<", ">", "<=", ">=", "=", "<>") and r.value is not None:
            v = r.value.strip()
            if re.match(r"^-?\d[\d,]*(\.\d+)?$", v):
                n = float(v.replace(",", ""))
                vals.update(_boundary(r.operator, int(n) if n.is_integer() else n))
            elif v.startswith('"'):
                vals.update(_boundary(r.operator, v.strip('"')))
            elif re.match(r"^\d{4}-\d{2}-\d{2}$", v):
                vals.update({v})
            else:
                vals.update({0, 1, 100})
        elif r.operator and r.operator.startswith("is "):
            vals.update({None, 1})
        elif r.usage == "value":
            vals.update({0, 1, 100})
        else:
            vals.update({True, False})
    return {display[k]: sorted(v, key=lambda x: (x is None, str(type(x)), x if x is not None else 0))
            for k, v in domain.items()}


def generate_test_cases(rule_text: str, max_cases: int = 32, seed: int = 7,
                        fixed: Optional[dict] = None, today: Optional[str] = None) -> dict:
    """Scenarios that exercise every branch and threshold of one rule, with expected outcomes."""
    dom = _inputs(rule_text)
    fixed = fixed or {}
    for k in list(dom):
        if norm(k) in {norm(f) for f in fixed}:
            del dom[k]
    names = list(dom)
    combos_total = 1
    for n in names:
        combos_total *= max(1, len(dom[n]))
    rnd = random.Random(seed)
    if combos_total <= max_cases:
        combos = list(itertools.product(*[dom[n] for n in names])) if names else [()]
    else:
        combos = set()
        # every value of every input at least once, others random
        for i, n in enumerate(names):
            for v in dom[n]:
                combos.add(tuple(v if j == i else rnd.choice(dom[m]) for j, m in enumerate(names)))
        while len(combos) < max_cases:
            combos.add(tuple(rnd.choice(dom[n]) for n in names))
        combos = sorted(combos, key=str)[:max(max_cases, len(combos))]
    cases, branches_hit = [], set()
    for combo in combos:
        facts = {**fixed, **dict(zip(names, combo))}
        res = evaluate_rule(rule_text, facts, today=today)
        branches_hit.add(res.get("branch"))
        cases.append({"inputs": {k: _jsonable(v) for k, v in facts.items()}, "expected": res.get("value"),
                      "branch": res.get("branch"), **({"unsupported": res["unsupported"]}
                                                        if "unsupported" in res else {})})
    n_branches = len([1 for lvl, _ in parse_indented(rule_text) if lvl == 0])
    unsupported = sorted({c["unsupported"] for c in cases if "unsupported" in c})
    if unsupported:
        return {"inputs": {k: [_jsonable(x) for x in v] for k, v in dom.items()},
                "combinations_possible": combos_total, "cases": cases, "branches_never_reached": [],
                "simulated": False,
                "note": "not simulated: " + "; ".join(unsupported) +
                        " - test this rule in Policy Modeling"}
    unreachable = [b for b in range(1, n_branches + 1) if b not in branches_hit]
    return {"inputs": {k: [_jsonable(x) for x in v] for k, v in dom.items()},
            "combinations_possible": combos_total, "cases": cases,
            "branches_never_reached": unreachable, "simulated": True,
            "note": ("some conclusion lines are never reached by any combination - check for "
                     "overlapping or contradictory conditions") if unreachable else None}


def check_examples(rule_text: str, examples: list[dict], store=None, today: Optional[str] = None,
                   supporting_rules: Optional[list] = None) -> dict:
    """examples: [{"inputs": {...}, "expected": value, "name": optional}] taken from the requirement.
    supporting_rules: other draft rules, so end-to-end examples can be checked through a chain."""
    results, passed = [], 0
    for i, ex in enumerate(examples):
        res = evaluate_rule(rule_text, ex.get("inputs", {}), store=store, today=today,
                            supporting_rules=supporting_rules)
        exp = Evaluator._coerce(ex.get("expected"))
        got = res.get("value")
        ok = _eq(got, exp)
        passed += ok
        results.append({"example": ex.get("name") or f"example {i + 1}", "expected": _jsonable(exp),
                        "actual": got, "pass": ok,
                        **({"unsupported": res["unsupported"]} if "unsupported" in res else {}),
                        **({"inferred": res["inferred"]} if res.get("inferred") else {})})
    return {"passed": passed, "failed": len(examples) - passed, "all_pass": passed == len(examples),
            "results": results}


def _eq(a, b):
    if isinstance(a, (int, float)) and isinstance(b, (int, float)) and not isinstance(a, bool) \
            and not isinstance(b, bool):
        return abs(a - b) < 1e-9
    if isinstance(a, str) and isinstance(b, str):
        return a.lower() == b.lower()
    return _jsonable(a) == _jsonable(b)
