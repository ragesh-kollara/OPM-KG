"""OPM / Oracle Intelligent Advisor rulebase knowledge graph."""
__version__ = "0.1.0"
