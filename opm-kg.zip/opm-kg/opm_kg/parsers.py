"""Parsers for Intelligent Advisor 12.2 rulebase sources.

Supported inputs
  * Word rule documents (.docx) using the "OPM - ..." paragraph styles, plus Word rule tables
  * Excel rule tables (.xlsx) using "OPM - conclusion heading" / "OPM - condition heading" styles
    (falls back to "first column is the conclusion")
  * XML (project .xprj, data model / properties XML, compiled rulebase XML) - scanned generically
    for entity, attribute, relationship and rule elements
  * .zip exports (project export or deployable) - every supported file inside is parsed
  * a folder containing any of the above
"""
from __future__ import annotations

import io
import os
import re
import zipfile
from pathlib import PurePosixPath
from typing import Optional

from lxml import etree

from .model import AttributeDef, EntityDef, Rule, RuleBase, norm, positive_candidates
from .rule_text import refs_from_lines, parse_indented, is_group_line

SUPPORTED = (".docx", ".xlsx", ".xlsm", ".xml", ".xprj")   # scanned inside zips / folders
DIRECT_ONLY = (".txt",)                                     # parsed only when given explicitly


# ----------------------------------------------------------------------------------------------
# Word
# ----------------------------------------------------------------------------------------------
_LEVEL_RE = re.compile(r"level\s*(\d+)", re.I)


def _style_role(style_name: str) -> tuple[str, int]:
    s = (style_name or "").lower()
    if "opm" not in s:
        if s.startswith("heading"):
            return "heading", 0
        return "other", 0
    if "rule name" in s:
        return "rule_name", 0
    if "conclusion" in s:
        return "conclusion", 0
    m = _LEVEL_RE.search(s)
    if m:
        return "condition", int(m.group(1))
    if "heading" in s:
        return "heading", 0
    if "comment" in s:
        return "comment", 0
    return "other", 0


def _iter_block_items(doc):
    """Yield paragraphs and tables in document order."""
    from docx.table import Table
    from docx.text.paragraph import Paragraph
    body = doc.element.body
    for child in body.iterchildren():
        tag = child.tag.split("}")[-1]
        if tag == "p":
            yield Paragraph(child, doc)
        elif tag == "tbl":
            yield Table(child, doc)


def parse_docx(data: bytes, docname: str, rb: RuleBase) -> None:
    import docx
    from docx.table import Table

    doc = docx.Document(io.BytesIO(data))
    section: Optional[str] = None
    pending_name: Optional[str] = None
    current: Optional[list] = None   # [(level, text)]
    cur_meta: dict = {}
    counter = 0

    def flush():
        nonlocal current, counter
        if current:
            counter += 1
            _add_rule(rb, docname, "word", current, cur_meta.get("name"),
                      cur_meta.get("section"), f"rule {counter}")
        current = None

    for block in _iter_block_items(doc):
        if isinstance(block, Table):
            flush()
            if _parse_word_table(block, docname, section, counter + 1, rb, pending_name):
                counter += 1
                pending_name = None
            continue
        text = block.text.strip()
        role, level = _style_role(block.style.name if block.style is not None else "")
        if not text:
            continue
        if role == "heading":
            flush()
            section = text
        elif role == "rule_name":
            flush()
            pending_name = text
        elif role == "conclusion":
            # "x = 0 otherwise" continues the current rule; anything else starts a new one
            if current and text.lower().rstrip(".").endswith(" otherwise"):
                current.append((0, text))
                continue
            flush()
            current = [(0, text)]
            cur_meta = {"name": pending_name, "section": section}
            pending_name = None
        elif role == "condition" and current is not None:
            current.append((level, text))
    flush()


def _parse_word_table(table, docname: str, section: Optional[str], idx: int, rb: RuleBase,
                      name: Optional[str] = None) -> bool:
    """Word rule table: first column conclusions (values), second column conditions.

    Header row holds the conclusion attribute text in column 1.
    """
    styled = any("opm" in (p.style.name or "").lower()
                 for r in table.rows for c in r.cells for p in c.paragraphs if p.style is not None)
    if not styled:
        return False  # ordinary Word table (version history, notes ...) - not a rule table
    def cell_lines(cell):
        out = []
        for p in cell.paragraphs:
            t = p.text.strip()
            if not t:
                continue
            role, lvl = _style_role(p.style.name if p.style is not None else "")
            out.append((lvl if role == "condition" else 1, t))
        return out

    rows = []
    for r in table.rows:
        cells = list(r.cells)
        if len(cells) < 2:
            continue
        rows.append((cells[0].text.strip(), [ln for c in cells[1:] for ln in cell_lines(c)]))
    rows = [r for r in rows if r[0] or r[1]]
    if len(rows) < 2:
        return False
    header = rows[0][0]
    if not header:
        return False
    lines = []
    for value, conds in rows[1:]:
        texts = " ".join(t for _, t in conds).strip().lower()
        if texts == "otherwise" or not conds:
            lines.append((0, f"{header} = {value} otherwise" if value else f"{header} otherwise"))
            continue
        lines.append((0, f"{header} = {value} if" if value else f"{header} if"))
        base = min(l for l, _ in conds)
        conds = [(l - base + 1, t) for l, t in conds]
        for k, (lvl, t) in enumerate(conds):
            nxt = conds[k + 1] if k + 1 < len(conds) else None
            end = t.lower().split()[-1] if t.split() else ""
            # plain cells without connectors: consecutive siblings are joined with "and"
            if nxt and nxt[0] == lvl and end not in ("and", "or") and not is_group_line(t):
                t += " and"
            lines.append((lvl, t))
    # All conclusion lines refer to the same attribute; merge into one rule
    _add_rule(rb, docname, "table", lines, name, section, f"table {idx}", conclusion=header)
    return True


# ----------------------------------------------------------------------------------------------
# Excel
# ----------------------------------------------------------------------------------------------
def parse_xlsx(data: bytes, docname: str, rb: RuleBase) -> None:
    import openpyxl
    wb = openpyxl.load_workbook(io.BytesIO(data), data_only=False)
    for ws in wb.worksheets:
        rows = list(ws.iter_rows())
        # locate header row: first row with >=2 non-empty cells
        hdr_idx = None
        for i, row in enumerate(rows):
            if sum(1 for c in row if c.value not in (None, "")) >= 2:
                hdr_idx = i
                break
        if hdr_idx is None:
            continue
        header = rows[hdr_idx]
        concl_cols, cond_cols = [], []
        for c in header:
            if c.value in (None, ""):
                continue
            st = (c.style or "").lower()
            if "conclusion" in st:
                concl_cols.append(c.column)
            elif "condition" in st:
                cond_cols.append(c.column)
        if not concl_cols:
            filled = [c.column for c in header if c.value not in (None, "")]
            concl_cols, cond_cols = filled[:1], filled[1:]
        hdr_text = {c.column: str(c.value).strip() for c in header if c.value not in (None, "")}

        for cc in concl_cols:
            concl_attr = hdr_text[cc]
            lines = []
            for row in rows[hdr_idx + 1:]:
                vals = {c.column: c.value for c in row}
                v = vals.get(cc)
                if v in (None, ""):
                    continue
                conds = []
                for k in cond_cols:
                    cv = vals.get(k)
                    if cv in (None, "", "-"):
                        continue
                    conds.append(_excel_condition(hdr_text[k], str(cv).strip()))
                otherwise = not conds or any(str(vals.get(k, "")).strip().lower() == "otherwise"
                                             for k in cond_cols)
                conds = [c for c in conds if c]
                if otherwise and not conds:
                    lines.append((0, f"{concl_attr} = {v} otherwise"))
                else:
                    lines.append((0, f"{concl_attr} = {v} if"))
                    lines.extend((1, c + (" and" if i < len(conds) - 1 else "")) for i, c in enumerate(conds))
            if lines:
                _add_rule(rb, docname, "excel", lines, None, ws.title,
                          f"sheet '{ws.title}' col {cc}", conclusion=concl_attr)


def _excel_condition(header: str, cell: str) -> Optional[str]:
    low = cell.lower()
    if low == "otherwise":
        return None
    if low in ("true", "yes"):
        return header
    if low in ("false", "no"):
        return f"it is not the case that {header}"
    m = re.match(r"^(<=|>=|<>|=|<|>)\s*(.*)$", cell)
    if m:
        return f"{header} {m.group(1)} {m.group(2).strip()}"
    if cell.lower().startswith("the ") or "(" in cell:
        return cell  # full statement in the cell
    return f"{header} = {cell}"


# ----------------------------------------------------------------------------------------------
# XML (data model, project file, compiled rulebase)
# ----------------------------------------------------------------------------------------------
_TEXT_KEYS = ("text", "attribute-text", "attributetext", "statement", "base-text", "positive-text",
              "caption", "name")
_TYPE_KEYS = ("type", "data-type", "datatype", "value-type", "valuetype")
_NAME_KEYS = ("public-name", "publicname", "public_name", "id", "name")


def _local(tag) -> str:
    return tag.split("}")[-1].lower() if isinstance(tag, str) else ""


def _get(el, keys) -> Optional[str]:
    attrs = {k.split("}")[-1].lower(): v for k, v in el.attrib.items()}
    for k in keys:
        if k in attrs and attrs[k].strip():
            return attrs[k].strip()
    for child in el:
        if _local(child.tag) in keys and (child.text or "").strip():
            return child.text.strip()
    return None


def parse_xml(data: bytes, docname: str, rb: RuleBase) -> None:
    try:
        root = etree.fromstring(data, parser=etree.XMLParser(recover=True, huge_tree=True))
    except Exception as e:  # pragma: no cover
        rb.warnings.append(f"{docname}: XML parse failed: {e}")
        return
    if root is None:
        return
    n_attr = n_rule = 0
    for el in root.iter():
        tag = _local(el.tag)
        if not tag:
            continue
        if tag in ("entity", "entitydef", "entity-definition"):
            name = _get(el, ("name", "public-name", "id", "text"))
            if name and name not in rb.entities:
                parent_el = next((a for a in el.iterancestors() if _local(a.tag).startswith("entity")), None)
                rb.entities[name] = EntityDef(
                    name=name, text=_get(el, ("text", "caption")),
                    parent=_get(parent_el, ("name", "public-name", "id")) if parent_el is not None else None)
        elif tag in ("relationship", "reference-relationship", "containment-relationship"):
            src = next((a for a in el.iterancestors() if _local(a.tag).startswith("entity")), None)
            src_name = _get(src, ("name", "public-name", "id")) if src is not None else "global"
            target = _get(el, ("target", "target-entity", "targetentity", "to"))
            rel = {"name": _get(el, ("text", "name", "public-name")), "target": target,
                   "type": _get(el, ("type", "cardinality"))}
            rb.entities.setdefault(src_name, EntityDef(name=src_name)).relationships.append(rel)
        elif tag in ("attribute", "attributedef", "attribute-definition", "attr"):
            text = _get(el, _TEXT_KEYS)
            if not text or len(text) < 3:
                continue
            ent_el = next((a for a in el.iterancestors() if _local(a.tag).startswith("entity")), None)
            entity = (_get(ent_el, ("name", "public-name", "id")) if ent_el is not None
                      else _get(el, ("entity", "entity-name"))) or "global"
            a = AttributeDef(text=text, entity=entity, type=_get(el, _TYPE_KEYS),
                             name=_get(el, ("public-name", "publicname", "id")),
                             negative_text=_get(el, ("negative-text", "negativetext", "negative")),
                             question_text=_get(el, ("question", "question-text", "questiontext")),
                             source=docname)
            existing = rb.attributes.get(a.key)
            if existing is None or (existing.type is None and a.type):
                rb.attributes[a.key] = a
                n_attr += 1
        elif tag in ("rule", "ruledef", "rule-definition"):
            text = _get(el, ("text", "rule-text", "ruletext", "source")) or (el.text or "").strip()
            if not text:
                continue
            lines = parse_indented(text)
            if lines:
                n_rule += 1
                _add_rule(rb, docname, "xml", lines, _get(el, ("name", "id")), None,
                          f"xml rule {n_rule}")
    if n_attr == 0 and n_rule == 0:
        rb.warnings.append(f"{docname}: no entities/attributes/rules recognised "
                           f"(root <{_local(root.tag)}>) - run `opm-kg inspect` and adapt parse_xml")


def parse_txt(data: bytes, docname: str, rb: RuleBase) -> None:
    """Plain-text rules: blank line separates rules, indent = 2 spaces or tab per level."""
    text = data.decode("utf-8", errors="replace")
    for i, block in enumerate(re.split(r"\n\s*\n", text)):
        lines = parse_indented(block)
        if lines:
            _add_rule(rb, docname, "text", lines, None, None, f"block {i + 1}")


# ----------------------------------------------------------------------------------------------
# Common
# ----------------------------------------------------------------------------------------------
def _render(lines) -> str:
    return "\n".join("  " * lvl + txt for lvl, txt in lines)


def _add_rule(rb: RuleBase, docname: str, kind: str, lines, name, section, location,
              conclusion: Optional[str] = None) -> None:
    refs, functions = refs_from_lines(lines)
    if conclusion is None:
        conclusion = next((r.text for r in refs if r.role == "conclusion"), lines[0][1])
    # de-duplicate conclusion refs (rule tables list the conclusion on every row)
    seen, dedup = set(), []
    for r in refs:
        k = (r.role, r.key, r.negated, r.operator, r.value, r.function)
        if r.role == "conclusion":
            k = ("conclusion", r.key)
        if k in seen:
            continue
        seen.add(k)
        dedup.append(r)
    rid = f"{PurePosixPath(docname).name}#{location}"
    rb.rules.append(Rule(id=rid, document=docname, kind=kind, conclusion=conclusion,
                         text=_render(lines), name=name, section=section, location=location,
                         refs=dedup, functions=sorted(set(functions))))


def _dispatch(name: str, data: bytes, rb: RuleBase, direct: bool = False) -> None:
    ext = os.path.splitext(name)[1].lower()
    base = os.path.basename(name)
    if base.startswith("~$") or (ext in DIRECT_ONLY and not direct):
        return
    rb.documents.append(name)
    try:
        if ext == ".docx":
            parse_docx(data, name, rb)
        elif ext in (".xlsx", ".xlsm"):
            parse_xlsx(data, name, rb)
        elif ext in (".xml", ".xprj"):
            parse_xml(data, name, rb)
        elif ext == ".txt":
            parse_txt(data, name, rb)
    except Exception as e:
        rb.warnings.append(f"{name}: failed to parse ({type(e).__name__}: {e})")


def _walk_zip(zf: zipfile.ZipFile, prefix: str, rb: RuleBase) -> None:
    for info in zf.infolist():
        if info.is_dir():
            continue
        name = prefix + info.filename
        data = zf.read(info)
        if name.lower().endswith(".zip"):
            with zipfile.ZipFile(io.BytesIO(data)) as inner:
                _walk_zip(inner, name + "!/", rb)
        elif name.lower().endswith(SUPPORTED):
            _dispatch(name, data, rb)


def load_rulebase(path: str, name: Optional[str] = None) -> RuleBase:
    rb = RuleBase(name=name or os.path.splitext(os.path.basename(path.rstrip("/\\")))[0])
    if os.path.isdir(path):
        for dirpath, _, files in os.walk(path):
            for f in sorted(files):
                full = os.path.join(dirpath, f)
                rel = os.path.relpath(full, path).replace("\\", "/")
                if f.lower().endswith(".zip"):
                    with zipfile.ZipFile(full) as zf:
                        _walk_zip(zf, rel + "!/", rb)
                elif f.lower().endswith(SUPPORTED):
                    with open(full, "rb") as fh:
                        _dispatch(rel, fh.read(), rb)
    elif path.lower().endswith(".zip"):
        with zipfile.ZipFile(path) as zf:
            _walk_zip(zf, "", rb)
    else:
        with open(path, "rb") as fh:
            _dispatch(os.path.basename(path), fh.read(), rb, direct=True)
    _make_rule_ids_unique(rb)
    _infer_attribute_defs(rb)
    return rb


def _make_rule_ids_unique(rb: RuleBase) -> None:
    """Rule ids are '<file>#<location>'; when two documents share a file name, use enough of the
    path to tell them apart (e.g. 'Sub/Eligibility.docx#rule 1')."""
    docs = sorted({r.document for r in rb.rules})
    label = {}
    for d in docs:
        parts = re.split(r"[/\\!]+", d)
        for n in range(1, len(parts) + 1):
            cand = "/".join(parts[-n:])
            clash = [o for o in docs if o != d and "/".join(re.split(r"[/\\!]+", o)[-n:]) == cand]
            if not clash:
                label[d] = cand
                break
        else:
            label[d] = d
    seen: dict[str, int] = {}
    for r in rb.rules:
        rid = f"{label[r.document]}#{r.location}"
        if rid in seen:
            seen[rid] += 1
            rid = f"{rid} ({seen[rid]})"
        else:
            seen[rid] = 1
        r.id = rid


def _infer_attribute_defs(rb: RuleBase) -> None:
    """Every attribute referenced in a rule gets an AttributeDef (inferred if not in the data model).

    The type of an inferred attribute is decided from all of its uses, not just the first one.
    """
    ordered = [r for rule in rb.rules for r in rule.refs if r.role == "conclusion"] + \
              [r for rule in rb.rules for r in rule.refs if r.role == "condition" and not r.negated] + \
              [r for rule in rb.rules for r in rule.refs if r.role == "condition" and r.negated]
    evidence: dict[str, list] = {}
    for ref in ordered:
        key = resolve_key(rb, ref.text)
        if key not in rb.attributes:
            rb.attributes[key] = AttributeDef(text=ref.text.strip(), entity=_entity_for(rb, ref.text),
                                              type=None, source="inferred")
        if rb.attributes[key].source == "inferred":
            evidence.setdefault(key, []).append(_guess_type(ref))
    rank = ["text", "date", "number", "number/date", "boolean", "value"]
    for key, types in evidence.items():
        types = [t for t in types if t]
        if "boolean" in types and any(t in ("number", "text", "date", "number/date") for t in types):
            types = [t for t in types if t != "boolean"]
        rb.attributes[key].type = min(types, key=rank.index) if types else None


def resolve_key(rb: RuleBase, text: str) -> str:
    """Map attribute text to a known attribute key, handling negative forms."""
    k = norm(text)
    if k in rb.attributes:
        return k
    for a in rb.attributes.values():
        if a.negative_text and norm(a.negative_text) == k:
            return a.key
    for pos in positive_candidates(k):
        if pos in rb.attributes:
            return pos
    return k


def _subject(text: str) -> Optional[str]:
    m = re.match(r"^(the [a-z][a-z \-]*?)(?:'s|\u2019s|\s(?:is|has|was|does|can|will|should|must|meets|are)\b)",
                 text.strip().lower())
    return m.group(1) if m else None


def _entity_for(rb: RuleBase, text: str) -> str:
    """Use the entity of a declared attribute with the same subject ("the applicant ..."), else guess."""
    subj = _subject(text)
    if subj:
        for a in rb.attributes.values():
            if a.source != "inferred" and _subject(a.text) == subj:
                return a.entity
    return _guess_entity(text)


def _guess_entity(text: str) -> str:
    m = re.match(r"^the ([a-z][a-z \-]*?)(?:'s|’s)\s", text.strip().lower())
    if m:
        return m.group(1)
    m = re.match(r"^the ([a-z][a-z\-]*) (is|has|was|does|can|will|should|must|meets)\b", text.strip().lower())
    return m.group(1) if m else "global"


def _guess_type(ref) -> Optional[str]:
    v = (ref.value or "").strip()
    if v.startswith('"'):
        return "text"
    if re.match(r"^(Date|DateTime|CurrentDate|AddDays|AddMonths|AddYears|AddWeeks)\s*\(", v):
        return "date"
    if re.match(r"^(YearDifference|DayDifference|MonthDifference|WeekDifference|InstanceCount|"
                r"InstanceCountIf|InstanceSum|InstanceSumIf|Round|RoundUp|RoundDown|Trunc|Abs|Maximum|"
                r"Minimum|Number|Length|ExtractYear|ExtractMonth|ExtractDay)\s*\(", v):
        return "number"
    if ref.operator in ("<", ">", "<=", ">=", "=", "<>") and re.match(r"^[-+]?[$\u20ac\u00a3\u20b9]?\d[\d,]*(\.\d+)?%?$", v):
        return "number"
    if ref.role == "conclusion" and re.search(r"\d", v) and re.search(r"\s[+\-*/]\s", v):
        return "number"
    if ref.function and ref.function.lower() in ("yeardifference", "daydifference", "monthdifference",
                                                   "weekdifference", "adddays", "addmonths", "addyears",
                                                   "extractyear", "extractmonth", "extractday"):
        return "date"
    if ref.role == "condition" and ref.usage == "boolean" and ref.operator is None:
        return "boolean"
    if ref.operator in ("<", ">", "<=", ">="):
        return "number/date"
    if ref.value:
        v = ref.value.strip()
        if re.match(r"^-?\d[\d,]*(\.\d+)?$", v):
            return "number"
        if v.startswith('"'):
            return "text"
        return "value"
    if ref.role == "conclusion":
        return "boolean"
    return "value" if ref.usage == "value" else "boolean"


def inspect_source(path: str, max_depth: int = 3) -> str:
    """Describe the files and XML element structure of an export (to adapt the parser)."""
    out = []

    def xml_summary(name, data):
        try:
            root = etree.fromstring(data, parser=etree.XMLParser(recover=True, huge_tree=True))
        except Exception as e:
            out.append(f"    (xml error {e})")
            return
        if root is None:
            return
        counts: dict[str, int] = {}
        samples: dict[str, str] = {}

        def walk(el, path, depth):
            if not isinstance(el.tag, str):
                return
            p = f"{path}/{_local(el.tag)}"
            counts[p] = counts.get(p, 0) + 1
            if p not in samples:
                samples[p] = " ".join(f'{k.split("}")[-1]}="{v[:40]}"' for k, v in list(el.attrib.items())[:5])
            if depth < max_depth + 3:
                for c in el:
                    walk(c, p, depth + 1)
        walk(root, "", 0)
        for p, c in list(counts.items())[:80]:
            out.append(f"    {p}  x{c}  {samples[p]}")

    def handle(name, data):
        out.append(f"{name}  ({len(data):,} bytes)")
        if name.lower().endswith((".xml", ".xprj")):
            xml_summary(name, data)

    if path.lower().endswith(".zip"):
        with zipfile.ZipFile(path) as zf:
            for info in zf.infolist():
                if not info.is_dir():
                    handle(info.filename, zf.read(info))
    elif os.path.isdir(path):
        for dp, _, fs in os.walk(path):
            for f in fs:
                with open(os.path.join(dp, f), "rb") as fh:
                    handle(os.path.relpath(os.path.join(dp, f), path), fh.read())
    else:
        with open(path, "rb") as fh:
            handle(path, fh.read())
    return "\n".join(out)
