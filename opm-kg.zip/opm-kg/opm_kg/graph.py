"""Knowledge-graph construction and the in-memory (JSON / NetworkX) query backend.

Graph schema (identical in Neo4j):

  (:RuleBase {name})-[:HAS_DOCUMENT]->(:Document {path})
  (:Document)-[:CONTAINS]->(:Rule {id, kind, conclusion, text, name, section, location})
  (:Rule)-[:CONCLUDES {value}]->(:Attribute {key, text, entity, type, public_name, source})
  (:Rule)-[:USES {negated, operator, value, function}]->(:Attribute)
  (:Rule)-[:TRAVERSES {function}]->(:Relationship {key, text})
  (:Rule)-[:CALLS]->(:Function {name})
  (:Entity {name})-[:HAS_ATTRIBUTE]->(:Attribute)
  (:Entity)-[:RELATES_TO {name, type}]->(:Entity)
  (:Attribute)-[:DEPENDS_ON {rule}]->(:Attribute)      derived: conclusion -> condition
"""
from __future__ import annotations

import difflib
import json
import re
from collections import defaultdict, deque
from typing import Optional

import networkx as nx

from .model import RuleBase, norm
from .parsers import resolve_key


def build_graph(rb: RuleBase) -> nx.MultiDiGraph:
    g = nx.MultiDiGraph(name=rb.name)
    rbid = f"rulebase:{rb.name}"
    g.add_node(rbid, label="RuleBase", name=rb.name)

    for ent in rb.entities.values():
        g.add_node(f"entity:{ent.name}", label="Entity", name=ent.name, text=ent.text, parent=ent.parent)
    for a in rb.attributes.values():
        aid = f"attr:{a.key}"
        g.add_node(aid, label="Attribute", key=a.key, text=a.text, entity=a.entity, type=a.type,
                   public_name=a.name, negative_text=a.negative_text, source=a.source)
        eid = f"entity:{a.entity}"
        if eid not in g:
            g.add_node(eid, label="Entity", name=a.entity)
        g.add_edge(eid, aid, type="HAS_ATTRIBUTE")
    for ent in rb.entities.values():
        for rel in ent.relationships:
            if rel.get("target"):
                tid = f"entity:{rel['target']}"
                if tid not in g:
                    g.add_node(tid, label="Entity", name=rel["target"])
                g.add_edge(f"entity:{ent.name}", tid, type="RELATES_TO", name=rel.get("name"),
                           rel_type=rel.get("type"))

    for doc in rb.documents:
        did = f"doc:{doc}"
        g.add_node(did, label="Document", path=doc)
        g.add_edge(rbid, did, type="HAS_DOCUMENT")

    for rule in rb.rules:
        rid = f"rule:{rule.id}"
        g.add_node(rid, label="Rule", id=rule.id, kind=rule.kind, conclusion=rule.conclusion,
                   text=rule.text, name=rule.name, section=rule.section, location=rule.location,
                   document=rule.document)
        did = f"doc:{rule.document}"
        if did not in g:
            g.add_node(did, label="Document", path=rule.document)
        g.add_edge(did, rid, type="CONTAINS")
        concluded = []
        for ref in rule.refs:
            if ref.role == "relationship":
                relid = f"rel:{norm(ref.text)}"
                g.add_node(relid, label="Relationship", key=norm(ref.text), text=ref.text)
                g.add_edge(rid, relid, type="TRAVERSES", function=ref.function)
                continue
            key = resolve_key(rb, ref.text)
            aid = f"attr:{key}"
            if aid not in g:
                g.add_node(aid, label="Attribute", key=key, text=ref.text, entity="global",
                           source="inferred")
            if ref.role == "conclusion":
                g.add_edge(rid, aid, type="CONCLUDES", value=ref.value)
                concluded.append(aid)
            else:
                implicit_neg = key != norm(ref.text)
                g.add_edge(rid, aid, type="USES", negated=ref.negated ^ implicit_neg,
                           operator=ref.operator, value=ref.value, function=ref.function)
        for fn in rule.functions:
            fid = f"fn:{fn}"
            g.add_node(fid, label="Function", name=fn)
            g.add_edge(rid, fid, type="CALLS")
        used = {v for _, v, d in g.out_edges(rid, data=True) if d["type"] == "USES"}
        for c in concluded:
            for u in used:
                if u != c:
                    g.add_edge(c, u, type="DEPENDS_ON", rule=rule.id)
    return g


def graph_to_json(g: nx.MultiDiGraph) -> dict:
    return {
        "name": g.graph.get("name"),
        "nodes": [{"_id": n, **d} for n, d in g.nodes(data=True)],
        "edges": [{"source": u, "target": v, **d} for u, v, d in g.edges(data=True)],
    }


def graph_from_json(data: dict) -> nx.MultiDiGraph:
    g = nx.MultiDiGraph(name=data.get("name"))
    for n in data["nodes"]:
        n = dict(n)
        g.add_node(n.pop("_id"), **n)
    for e in data["edges"]:
        e = dict(e)
        g.add_edge(e.pop("source"), e.pop("target"), **e)
    return g


# ----------------------------------------------------------------------------------------------
# Query backend (NetworkX).  Neo4jStore in neo4j_store.py implements the same methods.
# ----------------------------------------------------------------------------------------------
_TOKEN_RE = re.compile(r"[a-z0-9]+")
_STOP = {"the", "a", "an", "of", "is", "and", "or", "to", "in", "for", "if", "s", "be", "has", "on"}


def _tokens(s: str) -> list[str]:
    return [t for t in _TOKEN_RE.findall((s or "").lower()) if t not in _STOP]


class GraphStore:
    def __init__(self, g: nx.MultiDiGraph):
        self.g = g

    @classmethod
    def from_file(cls, path: str) -> "GraphStore":
        with open(path, encoding="utf-8") as fh:
            return cls(graph_from_json(json.load(fh)))

    # -- helpers -------------------------------------------------------------------------------
    def _attr_id(self, text: str) -> Optional[str]:
        k = norm(text)
        if f"attr:{k}" in self.g:
            return f"attr:{k}"
        for n, d in self.g.nodes(data=True):
            if d.get("label") == "Attribute" and d.get("negative_text") and norm(d["negative_text"]) == k:
                return n
        for pos in (k.replace(" is not ", " is ", 1), k.replace(" does not ", " does ", 1),
                    k.replace(" has not ", " has ", 1), k.replace(" are not ", " are ", 1)):
            if f"attr:{pos}" in self.g:
                return f"attr:{pos}"
        return None

    def _edges(self, node, etype, out=True):
        it = self.g.out_edges(node, data=True) if out else self.g.in_edges(node, data=True)
        return [(u, v, d) for u, v, d in it if d.get("type") == etype]

    def _rule_summary(self, rid) -> dict:
        d = self.g.nodes[rid]
        return {"id": d["id"], "document": d.get("document"), "conclusion": d.get("conclusion"),
                "name": d.get("name"), "section": d.get("section")}

    # -- public API ----------------------------------------------------------------------------
    def stats(self) -> dict:
        counts = defaultdict(int)
        for _, d in self.g.nodes(data=True):
            counts[d.get("label")] += 1
        inputs = len(self.base_attributes(limit=100000))
        return {"rulebase": self.g.graph.get("name"), **counts, "base_attributes": inputs}

    def search(self, query: str, kind: str = "all", limit: int = 20) -> list[dict]:
        """Keyword search over attribute text, rule text, rule names and entity names."""
        q = _tokens(query)
        qs = norm(query)
        results = []
        for n, d in self.g.nodes(data=True):
            label = d.get("label")
            if kind != "all" and label.lower() != kind.lower():
                continue
            if label == "Attribute":
                hay = f"{d.get('text')} {d.get('public_name') or ''} {d.get('negative_text') or ''}"
            elif label == "Rule":
                hay = f"{d.get('name') or ''} {d.get('section') or ''} {d.get('text')}"
            elif label in ("Entity", "Function"):
                hay = d.get("name") or ""
            elif label == "Document":
                hay = d.get("path") or ""
            else:
                continue
            ht = set(_tokens(hay))
            if not q:
                continue
            score = sum(1.0 for t in q if t in ht) + sum(0.5 for t in q for h in ht if t != h and (h.startswith(t) or t.startswith(h)))
            if qs and qs in hay.lower():
                score += 3
            if score <= 0:
                continue
            score /= (1 + 0.02 * len(ht))
            item = {"type": label, "score": round(score, 3)}
            if label == "Attribute":
                item.update(text=d.get("text"), entity=d.get("entity"), attr_type=d.get("type"))
            elif label == "Rule":
                item.update(self._rule_summary(n))
            else:
                item.update(name=d.get("name") or d.get("path"))
            results.append(item)
        results.sort(key=lambda r: -r["score"])
        return results[:limit]

    def get_attribute(self, text: str) -> dict:
        aid = self._attr_id(text)
        if not aid:
            return {"found": False, "suggestions": self.suggest(text)}
        d = self.g.nodes[aid]
        concluded_by = [dict(self._rule_summary(u), value=e.get("value"))
                        for u, _, e in self._edges(aid, "CONCLUDES", out=False)]
        used_by = [dict(self._rule_summary(u), negated=e.get("negated"), operator=e.get("operator"),
                        value=e.get("value"), function=e.get("function"))
                   for u, _, e in self._edges(aid, "USES", out=False)]
        return {"found": True, "text": d.get("text"), "entity": d.get("entity"), "type": d.get("type"),
                "public_name": d.get("public_name"), "negative_text": d.get("negative_text"),
                "source": d.get("source"),
                "is_base_attribute": not concluded_by,
                "concluded_by": concluded_by, "used_by": used_by}

    def get_rule(self, rule_id: str) -> dict:
        rid = f"rule:{rule_id}"
        if rid not in self.g:
            cands = [d["id"] for n, d in self.g.nodes(data=True)
                     if d.get("label") == "Rule" and rule_id.lower() in d["id"].lower()]
            if len(cands) == 1:
                rid = f"rule:{cands[0]}"
            else:
                return {"found": False, "candidates": cands[:20]}
        d = self.g.nodes[rid]
        return {"found": True, **{k: d.get(k) for k in ("id", "document", "kind", "name", "section",
                                                          "location", "conclusion", "text")},
                "concludes": [self.g.nodes[v]["text"] for _, v, _ in self._edges(rid, "CONCLUDES")],
                "uses": [{"attribute": self.g.nodes[v]["text"], "negated": e.get("negated"),
                          "operator": e.get("operator"), "value": e.get("value"),
                          "function": e.get("function")} for _, v, e in self._edges(rid, "USES")],
                "relationships": [self.g.nodes[v]["text"] for _, v, _ in self._edges(rid, "TRAVERSES")],
                "functions": [self.g.nodes[v]["name"] for _, v, _ in self._edges(rid, "CALLS")]}

    def _walk(self, aid, direction, depth):
        seen, out = {aid: 0}, []
        dq = deque([aid])
        while dq:
            cur = dq.popleft()
            if seen[cur] >= depth:
                continue
            edges = self._edges(cur, "DEPENDS_ON", out=(direction == "up"))
            for u, v, e in edges:
                nxt = v if direction == "up" else u
                if nxt not in seen:
                    seen[nxt] = seen[cur] + 1
                    out.append({"attribute": self.g.nodes[nxt]["text"], "depth": seen[nxt],
                                "via_rule": e.get("rule"),
                                "is_base_attribute": not self._edges(nxt, "CONCLUDES", out=False)})
                    dq.append(nxt)
        return out

    def upstream(self, text: str, depth: int = 10) -> dict:
        """Everything the attribute depends on (its inputs, transitively)."""
        aid = self._attr_id(text)
        if not aid:
            return {"found": False, "suggestions": self.suggest(text)}
        items = self._walk(aid, "up", depth)
        return {"found": True, "attribute": self.g.nodes[aid]["text"], "dependencies": items,
                "base_inputs": sorted({i["attribute"] for i in items if i["is_base_attribute"]})}

    def downstream(self, text: str, depth: int = 10) -> dict:
        """Impact analysis: every attribute (and rule) affected if this attribute changes."""
        aid = self._attr_id(text)
        if not aid:
            return {"found": False, "suggestions": self.suggest(text)}
        items = self._walk(aid, "down", depth)
        affected_attrs = {aid} | {self._attr_id(i["attribute"]) for i in items}
        rules = set()
        for a in affected_attrs:
            for u, _, _ in self._edges(a, "USES", out=False):
                rules.add(self.g.nodes[u]["id"])
        return {"found": True, "attribute": self.g.nodes[aid]["text"], "affected_attributes": items,
                "affected_rules": sorted(rules)}

    def rules_in_document(self, document: str) -> list[dict]:
        out = []
        for n, d in self.g.nodes(data=True):
            if d.get("label") == "Rule" and document.lower() in (d.get("document") or "").lower():
                out.append(self._rule_summary(n))
        return out

    def entity(self, name: str) -> dict:
        eid = f"entity:{name}"
        if eid not in self.g:
            names = [d["name"] for n, d in self.g.nodes(data=True) if d.get("label") == "Entity"]
            return {"found": False, "entities": names}
        attrs = [{"text": self.g.nodes[v]["text"], "type": self.g.nodes[v].get("type")}
                 for _, v, _ in self._edges(eid, "HAS_ATTRIBUTE")]
        rels = [{"name": e.get("name"), "target": self.g.nodes[v]["name"], "type": e.get("rel_type")}
                for _, v, e in self._edges(eid, "RELATES_TO")]
        return {"found": True, "name": name, "attributes": attrs, "relationships": rels}

    def list_entities(self) -> list[dict]:
        return [{"name": d["name"], "attributes": len(self._edges(n, "HAS_ATTRIBUTE"))}
                for n, d in self.g.nodes(data=True) if d.get("label") == "Entity"]

    def base_attributes(self, limit: int = 200) -> list[dict]:
        """Attributes never concluded by a rule: interview / data-mapped inputs."""
        out = []
        for n, d in self.g.nodes(data=True):
            if d.get("label") == "Attribute" and not self._edges(n, "CONCLUDES", out=False) \
                    and self._edges(n, "USES", out=False):
                out.append({"text": d["text"], "entity": d.get("entity"), "type": d.get("type")})
        return out[:limit]

    def diagnostics(self) -> dict:
        """Rulebase health: multiply-proven attributes, cycles, unused and unresolved attributes."""
        multi = []
        for n, d in self.g.nodes(data=True):
            if d.get("label") == "Attribute":
                rs = [self.g.nodes[u]["id"] for u, _, _ in self._edges(n, "CONCLUDES", out=False)]
                if len(rs) > 1:
                    multi.append({"attribute": d["text"], "rules": rs})
        dep = nx.DiGraph()
        for u, v, e in self.g.edges(data=True):
            if e.get("type") == "DEPENDS_ON":
                dep.add_edge(u, v)
        cycles = [[self.g.nodes[x]["text"] for x in c] for c in list(nx.simple_cycles(dep))[:20]]
        unused = [d["text"] for n, d in self.g.nodes(data=True)
                  if d.get("label") == "Attribute" and d.get("source") != "inferred"
                  and not self._edges(n, "USES", out=False) and not self._edges(n, "CONCLUDES", out=False)]
        inferred = [d["text"] for n, d in self.g.nodes(data=True)
                    if d.get("label") == "Attribute" and d.get("source") == "inferred"]
        has_model = any(d.get("label") == "Attribute" and d.get("source") not in (None, "inferred")
                        for _, d in self.g.nodes(data=True))
        return {"attributes_proven_by_multiple_rules": multi, "dependency_cycles": cycles,
                "defined_but_unused_attributes": unused[:200],
                "attributes_not_in_data_model": inferred[:200] if has_model else
                "no data model loaded - all attributes were inferred from rule text"}

    def suggest(self, text: str, n: int = 5) -> list[str]:
        k = norm(text)
        keys = [d["key"] for _, d in self.g.nodes(data=True) if d.get("label") == "Attribute"]
        close = difflib.get_close_matches(k, keys, n=n, cutoff=0.6)
        if len(close) < n:
            for r in self.search(text, kind="attribute", limit=n):
                if norm(r["text"]) not in close:
                    close.append(norm(r["text"]))
        return [self.g.nodes[f"attr:{c}"]["text"] for c in close[:n]]

    def attribute_keys(self) -> set[str]:
        return {d["key"] for _, d in self.g.nodes(data=True) if d.get("label") == "Attribute"}

    def depends_on_closure(self, text: str) -> set[str]:
        aid = self._attr_id(text)
        if not aid:
            return set()
        return {norm(i["attribute"]) for i in self._walk(aid, "up", 50)}
