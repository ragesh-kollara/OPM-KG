"""Authoring guide and workflow prompt served by the MCP server."""

AUTHORING_GUIDE = """\
# Writing Intelligent Advisor (12.2) rules with opm-kg

## Rule text format used by the tools
Plain text, one statement per line, 2 spaces of indentation per level.

    the applicant meets the residency requirement if
      the applicant is a citizen or
      both
        the applicant is a permanent resident and
        the applicant's years of residence >= 2

* Conclusion line: unindented. Boolean: "<attribute> if". Value: "<attribute> = <expression> if".
  A calculation with no conditions: "<attribute> = <expression>" (no "if").
* Conditions: one per line, ending in "and" or "or" when another condition follows at the same level.
  Do not mix "and" and "or" at one level - wrap one side in a group.
* Groups: "both" / "all" (joined by and), "either" / "any" (joined by or), children indented one
  level. A group's own connector goes on the last line inside the group.
* Negation: prefer the attribute's negative form ("the applicant is not a citizen", or the data
  model's negative text). "it is not the case that ..." is also accepted by the tools.
* Comparisons: =  <>  <  >  <=  >= . Text values in double quotes. Dates: Date(2026, 4, 1).
* Several outcomes for one value attribute: write one conclusion line per outcome, most specific
  first, and finish with "<attribute> = <default> otherwise". Export writes this as a Word
  rule table (value | conditions | ... | otherwise).
* Entity reasoning: ForAll(<relationship>, <statement>), Exists(...), InstanceCount(<relationship>),
  InstanceSum(<relationship>, <attribute>), InstanceCountIf(<relationship>, <statement>).

## Attribute naming
* Always reuse existing attribute text exactly (analyze_requirement / search / get_attribute).
* New attributes follow the rulebase's style: "the <entity> <verb phrase>" for booleans
  ("the applicant qualifies for the hardship top-up"), "the <entity>'s <noun>" for values
  ("the applicant's weekly top-up amount").
* One rule (or rule table) proves each attribute. To change behaviour, modify that rule
  (replacing_rule_id); never add a second rule for the same conclusion.
* Split complex logic into intermediate boolean attributes; it keeps rules readable and testable.

## Workflow
1. analyze_requirement - relevant attributes, rules, thresholds already in the rulebase, problems.
2. For each business rule statement, decide: modify an existing rule, add a new one, or both.
3. Draft rule text. Reuse attribute text; add intermediate attributes where it helps.
4. validate_rule_text (with replacing_rule_id for modifications) until there are no errors.
5. Turn the requirement's worked examples into [{inputs, expected}] and run check_rule_examples.
   If the requirement has no examples, write 2-4 from its wording (typical case, each threshold edge,
   each exclusion).
6. generate_test_cases - read the scenarios; branches_never_reached means overlapping conditions.
7. impact_analysis on every modified conclusion; mention affected rules to the user.
8. export_change_package with all changes (status must be READY), then report the files.

State assumptions explicitly (e.g. "below 15,000" read as < 15000; "aged 21 to 66" as >= 21 and <= 66).
If the requirement is ambiguous in a way that changes the logic, ask before exporting.
"""

WORKFLOW_PROMPT = """\
You are an Oracle Intelligent Advisor (Policy Modeling 12.2) rule author working against the
knowledge graph of an existing rulebase through the opm-kg tools.

Business requirement:
---
{requirement}
---

Follow this procedure exactly:
1. Call analyze_requirement with the full requirement. Read relevant_attributes, relevant_rules
   (especially contains_requirement_numbers) and existing_problems_in_scope.
2. Break the requirement into numbered business rule statements. For each one decide whether it
   MODIFIES an existing rule (note its id), ADDS a new rule, or both. Use get_rule / get_attribute /
   trace_dependencies when you need more detail.
3. Draft each rule in the plain-text format of the authoring guide (resource opm://authoring-guide),
   reusing existing attribute text exactly.
4. validate_rule_text every draft (replacing_rule_id for modifications). Fix every error; explain
   any warning you accept.
5. Build examples from the requirement (typical case, every threshold boundary, every exclusion)
   and run check_rule_examples. All must pass. Then run generate_test_cases and make sure no
   branch is unreachable.
6. Run impact_analysis for modified conclusions.
7. Call export_change_package with every change (rule_text, name, change_id, requirement_ref,
   rationale, replacing_rule_id, examples). Status must be READY.
8. Reply with: the rules (as text), assumptions made, impact, and the three files produced.
"""
