"""Parse OPM natural-language rule text into attribute references.

Handles the Intelligent Advisor 12.2 Word rule grammar:
  conclusion line ("... if" / "x = expr" / "... otherwise"),
  condition lines ending in "and" / "or",
  group lines ("both", "either", "all", "any"),
  negation ("not", "it is not the case that"),
  comparisons (=, <>, <, >, <=, >=), arithmetic and functions like
  InstanceSum(the incomes, the income amount) or ForAll(the children, the child is a dependant).
"""
from __future__ import annotations

import re
from typing import Iterable, Optional

from .model import AttrRef

CONNECTORS = ("and", "or")
GROUP_WORDS = {"both", "either", "all", "any", "all of", "any of", "both of", "either of",
               "all of the following", "any of the following"}
COMPARISON_RE = re.compile(r"\s(<=|>=|<>|=|<|>)\s")
ARITH_RE = re.compile(r"\s[+\-*/]\s")
FUNC_RE = re.compile(r"\b([A-Z][A-Za-z]*)\s*\(")
NEG_PREFIX_RE = re.compile(r"^(it is not the case that|not)\s+", re.I)
STATUS_SUFFIX_RE = re.compile(r"\s+is\s+(unknown|known|uncertain|certain)$", re.I)
LITERAL_RE = re.compile(
    r"""^(
        -?\d[\d,]*(\.\d+)?%? |                 # numbers
        "[^"]*" | '[^']*' |                    # quoted text
        true|false|null|uncertain|unknown |    # constants
        \d{4}-\d{2}-\d{2}                      # ISO dates
    )$""", re.I | re.X)

# Functions whose first argument is an entity collection / relationship, not an attribute
ENTITY_FUNCTIONS = {
    "forall", "exists", "for", "instancecount", "instancesum", "instancemaximum",
    "instanceminimum", "instanceaverage", "instanceconcat", "instancevaluewhen",
    "instancemaximumif", "instanceminimumif", "instancesumif", "instancecountif",
    "forscope", "isamemberof", "firstinstance", "lastinstance",
}


def split_connector(line: str) -> tuple[str, Optional[str]]:
    """Strip a trailing 'and' / 'or' connector from a condition line."""
    s = line.strip()
    for c in CONNECTORS:
        if s.lower().endswith(" " + c):
            return s[: -len(c) - 1].rstrip(), c
    return s, None


def is_group_line(line: str) -> bool:
    return split_connector(line)[0].strip().lower().rstrip(":") in GROUP_WORDS


def split_args(s: str) -> list[str]:
    """Split function arguments on top-level commas."""
    out, depth, cur, quote = [], 0, [], None
    for ch in s:
        if quote:
            cur.append(ch)
            if ch == quote:
                quote = None
            continue
        if ch in "\"":
            quote = ch
        elif ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        if ch == "," and depth == 0:
            out.append("".join(cur).strip())
            cur = []
        else:
            cur.append(ch)
    if "".join(cur).strip():
        out.append("".join(cur).strip())
    return out


def _find_matching(s: str, open_idx: int) -> int:
    depth = 0
    for i in range(open_idx, len(s)):
        if s[i] == "(":
            depth += 1
        elif s[i] == ")":
            depth -= 1
            if depth == 0:
                return i
    return len(s) - 1


def is_literal(s: str) -> bool:
    return bool(LITERAL_RE.match(s.strip()))


def extract_refs(expr: str, role: str = "condition", negated: bool = False,
                 function: Optional[str] = None, functions: Optional[list] = None) -> list[AttrRef]:
    """Extract attribute references from one expression / statement."""
    functions = functions if functions is not None else []
    s = expr.strip().rstrip(".")
    if not s:
        return []

    m = NEG_PREFIX_RE.match(s)
    if m:
        negated = not negated
        s = s[m.end():]

    s = STATUS_SUFFIX_RE.sub("", s)

    # Strip wrapping parentheses
    while s.startswith("(") and _find_matching(s, 0) == len(s) - 1:
        s = s[1:-1].strip()

    refs: list[AttrRef] = []

    # Pull out function calls first, recursing into their arguments
    fm = FUNC_RE.search(s)
    while fm:
        fname = fm.group(1)
        open_idx = fm.end() - 1
        close_idx = _find_matching(s, open_idx)
        args = split_args(s[open_idx + 1: close_idx])
        functions.append(fname)
        for i, a in enumerate(args):
            if i == 0 and fname.lower() in ENTITY_FUNCTIONS:
                # relationship / entity collection - record as relationship reference
                refs.append(AttrRef(text=a, role="relationship", function=fname))
                continue
            refs.extend(extract_refs(a, role, False, fname, functions))
        s = (s[: fm.start()] + " __F__ " + s[close_idx + 1:]).strip()
        fm = FUNC_RE.search(s)

    # Comparisons
    cm = COMPARISON_RE.search(s)
    if cm:
        lhs, op, rhs = s[: cm.start()], cm.group(1), s[cm.end():]
        for side, other in ((lhs, rhs), (rhs, lhs)):
            for part in ARITH_RE.split(side):
                part = part.strip().strip("()").strip()
                if not part or part == "__F__" or is_literal(part):
                    continue
                refs.append(AttrRef(text=part, role=role, negated=negated, operator=op,
                                    value=other.strip() if other.strip() != "__F__" else None,
                                    function=function))
        return refs

    # Arithmetic without comparison
    parts = [p.strip().strip("()").strip() for p in ARITH_RE.split(s)]
    for part in parts:
        if not part or part == "__F__" or is_literal(part):
            continue
        refs.append(AttrRef(text=part, role=role, negated=negated, function=function))
    return refs


def parse_conclusion(line: str) -> tuple[str, Optional[str], bool]:
    """Return (attribute text, value expression, has_conditions)."""
    s = line.strip().rstrip(".")
    has_if = False
    low = s.lower()
    if low.endswith(" if"):
        s, has_if = s[:-3].rstrip(), True
    elif low.endswith(" otherwise"):
        s = s[:-10].rstrip()
    m = re.match(r"^(.*?)\s=\s(.*)$", s)
    if m:
        return m.group(1).strip(), m.group(2).strip(), has_if
    return s, None, has_if


def refs_from_lines(lines: Iterable[tuple[int, str]]) -> tuple[list[AttrRef], list[str]]:
    """Given [(level, text), ...] where level 0 lines are conclusions, return refs + functions."""
    refs: list[AttrRef] = []
    functions: list[str] = []
    for level, text in lines:
        if not text.strip():
            continue
        if level == 0:
            attr, value, _ = parse_conclusion(text)
            if attr:
                refs.append(AttrRef(text=attr, role="conclusion", value=value))
                if value:
                    refs.extend(extract_refs(value, "condition", functions=functions))
            continue
        body, _ = split_connector(text)
        if is_group_line(body) or body.lower() in ("otherwise",):
            continue
        refs.extend(extract_refs(body, "condition", functions=functions))
    return refs, functions


def parse_indented(text: str, indent: int = 2) -> list[tuple[int, str]]:
    """Parse plain-text rules (tabs or N spaces per level) into (level, text) pairs."""
    out = []
    for raw in text.splitlines():
        if not raw.strip():
            continue
        expanded = raw.replace("\t", " " * indent)
        lead = len(expanded) - len(expanded.lstrip(" "))
        out.append((lead // indent, expanded.strip()))
    return out
