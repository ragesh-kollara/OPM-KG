"""Parse OPM natural-language rule text into attribute references.

Handles the Intelligent Advisor 12.2 Word rule grammar:
  conclusion line ("... if" / "x = expr" / "x = expr if" / "... otherwise"),
  condition lines ending in "and" / "or",
  group lines ("both", "either", "all", "any", "any of the following are true", ...),
  negation ("not", "not(...)", "it is not the case that"),
  status tests ("x is known / unknown / uncertain / certain"),
  comparisons (=, <>, <, >, <=, >=, with or without spaces),
  arithmetic, quoted text, and functions such as
  InstanceSum(the incomes, the income amount) or ForAll(the children, the child's age < 18 and ...).
"""
from __future__ import annotations

import re
from typing import Iterable, Optional

from .model import AttrRef

CONNECTORS = ("and", "or")
GROUP_RE = re.compile(
    r"^(both|either|all|any|none|one or more|at least one)"
    r"(\s+of)?(\s+the\s+following)?(\s+(is|are)\s+true)?\s*:?$", re.I)
COMPARISON_OPS = ("<=", ">=", "<>", "=", "<", ">")
FUNC_RE = re.compile(r"(?<![A-Za-z0-9_'’])([A-Z][A-Za-z0-9]*|not)\s*\(")
NEG_PREFIX_RE = re.compile(r"^(it is not the case that|not)\s+", re.I)
STATUS_SUFFIX_RE = re.compile(r"\s+is\s+(unknown|known|uncertain|certain)$", re.I)
NUMBER_RE = re.compile(r"^[-+]?[$€£₹]?\d[\d,]*(\.\d+)?([eE][-+]?\d+)?%?$")
LITERAL_WORDS = {"true", "false", "null", "uncertain", "unknown", "__f__"}
QUOTE_PH = re.compile(r"^__Q\d+__$")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}(T[\d:]+)?$|^\d{1,2}/\d{1,2}/\d{2,4}$")

# Functions whose first argument is an entity collection / relationship, not an attribute
ENTITY_FUNCTIONS = {
    "forall", "exists", "for", "instancecount", "instancesum", "instancemaximum",
    "instanceminimum", "instanceaverage", "instanceconcat", "instancevaluewhen",
    "instancemaximumif", "instanceminimumif", "instancesumif", "instancecountif",
    "forscope", "isamemberof", "firstinstance", "lastinstance", "instancefirst", "instancelast",
}
# Arguments (0-based) that are boolean statements; all other arguments are value expressions
BOOL_ARGS = {
    "forall": {1}, "exists": {1}, "for": set(), "if": {0}, "instancecountif": {1},
    "instancesumif": {2}, "instancemaximumif": {2}, "instanceminimumif": {2},
    "instancevaluewhen": {2}, "temporalwhen": {0}, "isuncertain": set(), "isunknown": set(),
    "alwaysbetween": {2}, "sometimesbetween": {2},
}
NATURAL_FORALL_RE = re.compile(
    r"^for\s+(all|each|any|at least one)(\s+of)?\s+(the\s+.+?)\s*,\s*(.+)$", re.I)


# ----------------------------------------------------------------------------------------------
# low-level helpers
# ----------------------------------------------------------------------------------------------
def _clean(s: str) -> str:
    s = s.replace("“", '"').replace("”", '"').replace(" ", " ")
    return re.sub(r"\s+", " ", s).strip()


def _mask_quotes(s: str) -> tuple[str, list[str]]:
    quotes: list[str] = []

    def rep(m):
        quotes.append(m.group(0))
        return f"__Q{len(quotes) - 1}__"
    return re.sub(r'"[^"]*"', rep, s), quotes


def split_connector(line: str) -> tuple[str, Optional[str]]:
    """Strip a trailing 'and' / 'or' connector from a condition line."""
    s = line.strip()
    low = s.lower()
    for c in CONNECTORS:
        if low.endswith(" " + c) or low == c:
            return s[: -len(c)].rstrip(), c
    return s, None


def is_group_line(line: str) -> bool:
    return bool(GROUP_RE.match(split_connector(line)[0].strip()))


def _depth_map(s: str) -> list[int]:
    d, out = 0, []
    for ch in s:
        if ch == "(":
            d += 1
            out.append(d)
            continue
        out.append(d)
        if ch == ")":
            d = max(0, d - 1)
    return out


def _find_matching(s: str, open_idx: int) -> int:
    depth = 0
    for i in range(open_idx, len(s)):
        if s[i] == "(":
            depth += 1
        elif s[i] == ")":
            depth -= 1
            if depth == 0:
                return i
    return len(s) - 1


def split_args(s: str) -> list[str]:
    """Split function arguments on top-level commas (quotes are already masked)."""
    out, depth, cur = [], 0, []
    for ch in s:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        if ch == "," and depth == 0:
            out.append("".join(cur).strip())
            cur = []
        else:
            cur.append(ch)
    if "".join(cur).strip():
        out.append("".join(cur).strip())
    return out


def _strip_parens(s: str) -> str:
    s = s.strip()
    while s.startswith("(") and _find_matching(s, 0) == len(s) - 1:
        s = s[1:-1].strip()
    return s


def _top_level_find(s: str, pattern: re.Pattern) -> list[re.Match]:
    dm = _depth_map(s)
    return [m for m in pattern.finditer(s) if dm[m.start()] == 0]


_CMP_RE = re.compile(r"\s*(<=|>=|<>|=|<|>)\s*")
_ARITH_RE = re.compile(r"\s[+\-*/]\s|(?<=[\w)])\s*[+*]\s*(?=[\w(])")
_BOOL_SPLIT_RE = re.compile(r"\s+(and|or)\s+", re.I)


def is_literal(s: str) -> bool:
    s = s.strip().rstrip(".").strip()
    return (not s or bool(NUMBER_RE.match(s)) or s.lower() in LITERAL_WORDS
            or bool(QUOTE_PH.match(s)) or bool(DATE_RE.match(s)))


def _looks_like_statement(s: str) -> bool:
    s = s.strip().lower()
    if not s:
        return False
    return (s.startswith(("the ", "it is not the case", "not ", "not(", "a ", "an ", "any ", "all ",
                          "this ", "that ", "each "))
            or bool(FUNC_RE.match(s.strip())) or bool(re.match(r"^[A-Z][A-Za-z0-9]*\s*\(", s))
            or any(op in s for op in COMPARISON_OPS))


# ----------------------------------------------------------------------------------------------
# expression parser
# ----------------------------------------------------------------------------------------------
class _Ctx:
    def __init__(self, role: str, functions: list):
        self.role = role
        self.functions = functions
        self.refs: list[AttrRef] = []


def _terms(s: str, ctx: _Ctx, negated=False, operator=None, value=None, function=None,
           usage="value"):
    """A value expression: attributes, literals, arithmetic and function calls."""
    s = _strip_parens(s.strip().rstrip("."))
    if is_literal(s):
        return
    parts = [p for p in (_split_top(s, _ARITH_RE)) if p.strip()]
    if len(parts) > 1:
        for p in parts:
            _terms(p, ctx, negated, operator, value, function, "value")
        return
    m = FUNC_RE.match(s)
    if m and _find_matching(s, m.end() - 1) == len(s) - 1:
        _function(s, m, ctx, negated, function)
        return
    if "(" in s:  # function call embedded in other text: pull it out
        m = FUNC_RE.search(s)
        if m:
            close = _find_matching(s, m.end() - 1)
            _function(s[m.start():close + 1], FUNC_RE.match(s[m.start():]), ctx, negated, function)
            rest = (s[:m.start()] + " " + s[close + 1:]).strip()
            if rest and not is_literal(rest):
                _terms(rest, ctx, negated, operator, value, function, usage)
            return
    ctx.refs.append(AttrRef(text=s, role=ctx.role, negated=negated, operator=operator,
                            value=value, function=function, usage=usage))


def _split_top(s: str, pat: re.Pattern) -> list[str]:
    ms = _top_level_find(s, pat)
    if not ms:
        return [s]
    out, last = [], 0
    for m in ms:
        out.append(s[last:m.start()])
        last = m.end()
    out.append(s[last:])
    return [o.strip() for o in out]


def _function(s: str, m: re.Match, ctx: _Ctx, negated: bool, outer_fn: Optional[str]):
    fname = m.group(1)
    open_idx = m.end() - 1
    close = _find_matching(s, open_idx)
    inner = s[open_idx + 1: close]
    if fname.lower() == "not":
        _statement(inner, ctx, not negated, outer_fn)
        return
    ctx.functions.append(fname)
    args = split_args(inner)
    bool_args = BOOL_ARGS.get(fname.lower())
    for i, a in enumerate(args):
        if i == 0 and fname.lower() in ENTITY_FUNCTIONS:
            ctx.refs.append(AttrRef(text=_strip_parens(a), role="relationship", function=fname,
                                    usage="relationship"))
            continue
        if bool_args is None:  # unknown function: statement if it looks boolean, else value
            if _top_level_find(a, _CMP_RE) or _split_top(a, _BOOL_SPLIT_RE)[1:]:
                _statement(a, ctx, False, fname)
            else:
                _terms(a, ctx, False, None, None, fname, "value")
        elif i in bool_args:
            _statement(a, ctx, False, fname)
        else:
            _terms(a, ctx, False, None, None, fname, "value")


def _statement(s: str, ctx: _Ctx, negated: bool = False, function: Optional[str] = None):
    """A boolean statement: negation, and/or, comparison, status test, or a boolean attribute."""
    s = _strip_parens(s.strip().rstrip("."))
    if not s or is_literal(s):
        return

    # negation
    m = NEG_PREFIX_RE.match(s)
    if m and not s.lower().startswith("not("):
        _statement(s[m.end():], ctx, not negated, function)
        return
    fm = FUNC_RE.match(s)
    if fm and fm.group(1) == "not" and _find_matching(s, fm.end() - 1) == len(s) - 1:
        _statement(s[fm.end():-1], ctx, not negated, function)
        return

    # natural-language entity quantifier: "for all of the children, the child is a dependant"
    nm = NATURAL_FORALL_RE.match(s)
    if nm:
        ctx.functions.append("ForAll" if nm.group(1).lower() in ("all", "each") else "Exists")
        ctx.refs.append(AttrRef(text=nm.group(3), role="relationship", function=ctx.functions[-1]))
        _statement(nm.group(4), ctx, negated, ctx.functions[-1])
        return

    # inline and / or (only when every side is itself a statement)
    parts = _split_top(s, _BOOL_SPLIT_RE)
    if len(parts) > 1 and all(_looks_like_statement(p) for p in parts):
        for p in parts:
            _statement(p, ctx, negated, function)
        return

    # status tests
    sm = STATUS_SUFFIX_RE.search(s)
    if sm and not _top_level_find(s, _CMP_RE):
        _terms(s[: sm.start()], ctx, negated, f"is {sm.group(1).lower()}", None, function, "value")
        return

    # comparison
    cms = _top_level_find(s, _CMP_RE)
    if cms:
        cm = cms[0]
        lhs, op, rhs = s[: cm.start()], cm.group(1), s[cm.end():]
        _terms(lhs, ctx, negated, op, _display(rhs, ctx), function, "value")
        _terms(rhs, ctx, negated, op, _display(lhs, ctx), function, "value")
        return

    # a boolean-valued function or a plain boolean attribute
    _terms(s, ctx, negated, None, None, function, "boolean")


def _display(s: str, ctx) -> Optional[str]:
    s = s.strip()
    return s if s and len(s) <= 120 else None


def _unmask(refs: list[AttrRef], quotes: list[str]) -> None:
    def un(t):
        if t is None:
            return t
        return re.sub(r"__Q(\d+)__", lambda m: quotes[int(m.group(1))], t)
    for r in refs:
        r.text = un(r.text)
        r.value = un(r.value)


def extract_refs(expr: str, role: str = "condition", negated: bool = False,
                 function: Optional[str] = None, functions: Optional[list] = None) -> list[AttrRef]:
    """Extract attribute references from one condition statement."""
    functions = functions if functions is not None else []
    masked, quotes = _mask_quotes(_clean(expr))
    ctx = _Ctx(role, functions)
    _statement(masked, ctx, negated, function)
    _unmask(ctx.refs, quotes)
    return ctx.refs


def extract_value_refs(expr: str, functions: Optional[list] = None) -> list[AttrRef]:
    """Extract references from a value expression (right-hand side of a conclusion)."""
    functions = functions if functions is not None else []
    masked, quotes = _mask_quotes(_clean(expr))
    ctx = _Ctx("condition", functions)
    if _top_level_find(masked, _CMP_RE) or _split_top(masked, _BOOL_SPLIT_RE)[1:]:
        _statement(masked, ctx)          # boolean-valued expression
    else:
        _terms(masked, ctx, usage="value")
    _unmask(ctx.refs, quotes)
    return ctx.refs


# ----------------------------------------------------------------------------------------------
# rule level
# ----------------------------------------------------------------------------------------------
def parse_conclusion(line: str) -> tuple[str, Optional[str], bool]:
    """Return (attribute text, value expression, has_conditions)."""
    s = _clean(line).rstrip(".").rstrip(":").strip()
    has_if = False
    low = s.lower()
    if low.endswith(" if"):
        s, has_if = s[:-3].rstrip(), True
    elif low.endswith(" otherwise"):
        s = s[:-10].rstrip()
    masked, quotes = _mask_quotes(s)
    m = re.match(r"^(.*?)\s*=\s*(.*)$", masked)
    if m and not re.search(r"[<>]$", m.group(1)):
        attr = re.sub(r"__Q(\d+)__", lambda x: quotes[int(x.group(1))], m.group(1)).strip()
        val = re.sub(r"__Q(\d+)__", lambda x: quotes[int(x.group(1))], m.group(2)).strip()
        return attr, val, has_if
    return s, None, has_if


def refs_from_lines(lines: Iterable[tuple[int, str]]) -> tuple[list[AttrRef], list[str]]:
    """Given [(level, text), ...] where level 0 lines are conclusions, return refs + functions."""
    refs: list[AttrRef] = []
    functions: list[str] = []
    for level, text in lines:
        if not text.strip():
            continue
        if level == 0:
            attr, value, _ = parse_conclusion(text)
            if attr:
                refs.append(AttrRef(text=attr, role="conclusion", value=value))
                if value:
                    refs.extend(extract_value_refs(value, functions))
            continue
        body, _ = split_connector(text)
        if not body or is_group_line(body) or body.lower() == "otherwise":
            continue
        refs.extend(extract_refs(body, "condition", functions=functions))
    return refs, functions


def parse_indented(text: str, indent: int = 2) -> list[tuple[int, str]]:
    """Parse plain-text rules (tabs or N spaces per level) into (level, text) pairs.

    Indentation is normalised relative to the distinct indent widths actually used, so both
    2- and 4-space indentation work.
    """
    raw = []
    for line in text.splitlines():
        if not line.strip():
            continue
        expanded = line.replace("\t", " " * indent).replace(" ", " ")
        raw.append((len(expanded) - len(expanded.lstrip(" ")), expanded.strip()))
    if not raw:
        return []
    widths = sorted({w for w, _ in raw})
    base = widths[0]
    steps = [w - base for w in widths if w > base]
    unit = min(steps) if steps else indent
    unit = unit if unit in (1, 2, 3, 4) else indent
    return [((w - base) // unit, t) for w, t in raw]
