"""Evaluate OPM rule text against test facts.

Used to check that a generated rule does what the business requirement says, before it goes into
Policy Modeling.  Supports:
  * conclusion / "if" / "otherwise" branches (first matching branch wins)
  * condition trees: and / or, both / all / either / any groups, nesting
  * negation (negative forms, "not", "it is not the case that", "not(...)")
  * comparisons, arithmetic (+ - * /, precedence, parentheses), numbers, "text", true/false,
    dates (YYYY-MM-DD), "is known" / "is unknown"
  * functions: If, Maximum, Minimum, Round, RoundUp, RoundDown, Abs, Trunc, Date, CurrentDate,
    YearDifference, MonthDifference, DayDifference, AddDays, AddMonths, AddYears, Default
  * three-valued logic: a missing fact is unknown (None) and propagates as Intelligent Advisor does
  * optional chaining: attributes missing from the facts are inferred from the rulebase's own rules

Entity functions (ForAll, InstanceSum, ...) and temporal functions are reported as unsupported.
"""
from __future__ import annotations

import datetime as dt
import math
import re
from typing import Any, Optional

from .model import norm, positive_candidates
from .rule_text import (_CMP_RE, _BOOL_SPLIT_RE, NEG_PREFIX_RE, STATUS_SUFFIX_RE, _find_matching,
                        _mask_quotes, _split_top, _strip_parens, _top_level_find, is_group_line,
                        parse_conclusion, parse_indented, split_args, split_connector, _clean)


class Unsupported(Exception):
    pass


UNKNOWN = None


# ----------------------------------------------------------------------------------------------
# rule structure
# ----------------------------------------------------------------------------------------------
def _tree(lines):
    """[(level, text)] -> list of branches: {"attr", "value", "otherwise", "cond": node|None}."""
    nodes = []
    for i, (lvl, txt) in enumerate(lines):
        body, conn = split_connector(txt)
        nodes.append({"lvl": lvl, "body": body, "conn": conn, "children": [], "parent": None,
                      "group": lvl > 0 and is_group_line(body), "attached": None})
    stack = []
    for n in nodes:
        while stack and stack[-1]["lvl"] >= n["lvl"]:
            stack.pop()
        if stack:
            n["parent"] = stack[-1]
            stack[-1]["children"].append(n)
        stack.append(n)

    def next_sib(n):
        p = n["parent"]
        if not p:
            return None
        k = p["children"].index(n)
        return p["children"][k + 1] if k + 1 < len(p["children"]) else None

    for n in nodes:
        if n["conn"] and n["lvl"] > 0:
            cur = n
            while cur and cur["lvl"] > 0 and next_sib(cur) is None:
                cur = cur["parent"]
            if cur and cur["lvl"] > 0:
                cur["attached"] = n["conn"]

    branches = []
    for n in nodes:
        if n["lvl"] != 0:
            continue
        text = n["body"] if not n["conn"] else n["body"] + " " + n["conn"]
        attr, value, _ = parse_conclusion(text)
        low = _clean(text).lower().rstrip(".")
        branches.append({"attr": attr, "value": value, "otherwise": low.endswith(" otherwise"),
                         "cond": n if n["children"] else None})
    return branches


def _group_op(node) -> str:
    word = node["body"].lower() if node["lvl"] > 0 else ""
    if word.startswith(("either", "any", "one or more", "at least one")):
        return "or"
    if word.startswith(("both", "all")):
        return "and"
    conns = {c["attached"] for c in node["children"][:-1] if c["attached"]}
    return conns.pop() if len(conns) == 1 else "and"


# ----------------------------------------------------------------------------------------------
# evaluator
# ----------------------------------------------------------------------------------------------
def _k_and(vals):
    if any(v is False for v in vals):
        return False
    if any(v is None for v in vals):
        return None
    return True


def _k_or(vals):
    if any(v is True for v in vals):
        return True
    if any(v is None for v in vals):
        return None
    return False


def _to_date(v):
    if isinstance(v, dt.date):
        return v
    if isinstance(v, str) and re.match(r"^\d{4}-\d{2}-\d{2}$", v.strip().strip('"')):
        return dt.date.fromisoformat(v.strip().strip('"'))
    return v


def _num(v):
    if isinstance(v, bool):
        raise Unsupported("boolean used as a number")
    if isinstance(v, (int, float)):
        return v
    if isinstance(v, str):
        s = v.replace(",", "").replace("$", "").strip()
        try:
            return float(s) if "." in s or "e" in s.lower() else int(s)
        except ValueError:
            pass
    return v


def _years_between(a, b):
    a, b = _to_date(a), _to_date(b)
    y = b.year - a.year - ((b.month, b.day) < (a.month, a.day))
    return y


def _months_between(a, b):
    a, b = _to_date(a), _to_date(b)
    m = (b.year - a.year) * 12 + (b.month - a.month) - (b.day < a.day)
    return m


def _add_months(d, n):
    d = _to_date(d)
    m = d.month - 1 + int(n)
    y, m = d.year + m // 12, m % 12 + 1
    last = [31, 29 if y % 4 == 0 and (y % 100 or y % 400 == 0) else 28, 31, 30, 31, 30, 31, 31,
            30, 31, 30, 31][m - 1]
    return dt.date(y, m, min(d.day, last))


class Evaluator:
    def __init__(self, facts: dict, store=None, today: Optional[str] = None, max_depth: int = 25,
                 drafts: Optional[list] = None):
        self.facts = {norm(k): self._coerce(v) for k, v in (facts or {}).items()}
        self.drafts = {}
        for d in drafts or []:
            b = _tree(parse_indented(d))
            if b and b[0]["attr"]:
                self.drafts[norm(b[0]["attr"])] = d
        self.store = store
        self.today = _to_date(today) if today else dt.date.today()
        self.max_depth = max_depth
        self.trace: list[str] = []
        self.unsupported: list[str] = []
        self._stack: list[str] = []
        self._cache: dict[str, Any] = {}

    @staticmethod
    def _coerce(v):
        if isinstance(v, str):
            s = v.strip()
            if s.lower() in ("true", "yes"):
                return True
            if s.lower() in ("false", "no"):
                return False
            if s.lower() in ("unknown", "null", ""):
                return None
            if re.match(r"^\d{4}-\d{2}-\d{2}$", s):
                return dt.date.fromisoformat(s)
            n = _num(s)
            return n if not isinstance(n, str) else s.strip('"')
        return v

    # -- attribute lookup ----------------------------------------------------------------------
    def attr(self, text: str):
        k = norm(text)
        if k in self.facts:
            return self.facts[k]
        for pos in positive_candidates(k):          # negative form
            if pos in self.facts:
                v = self.facts[pos]
                return None if v is None else (not v)
        if k in self._cache:
            return self._cache[k]
        for cand, neg in [(k, False)] + [(p, True) for p in positive_candidates(k)]:
            if cand in self.drafts and cand not in self._stack and len(self._stack) < self.max_depth:
                self._stack.append(cand)
                try:
                    val = self.eval_rule(self.drafts[cand], _inner=True)["value"]
                finally:
                    self._stack.pop()
                self._cache[cand] = val
                self.trace.append(f"{cand} = {val!r}  (inferred by draft rule)")
                return (None if val is None else (not val)) if neg else val
        if self.store is None:
            return None
        a = self.store.get_attribute(text)
        if not a.get("found") or not a.get("concluded_by"):
            return None
        negate = norm(a["text"]) != k
        if norm(a["text"]) in self._stack or len(self._stack) >= self.max_depth:
            return None
        rule = self.store.get_rule(a["concluded_by"][0]["id"])
        if not rule.get("found"):
            return None
        self._stack.append(norm(a["text"]))
        try:
            val = self.eval_rule(rule["text"], _inner=True)["value"]
        finally:
            self._stack.pop()
        self.trace.append(f"{a['text']} = {val!r}  (inferred by {rule['id']})")
        self._cache[norm(a["text"])] = val
        if negate:
            return None if val is None else (not val)
        return val

    # -- values ----------------------------------------------------------------------------
    def value(self, expr: str):
        masked, quotes = _mask_quotes(_clean(expr))
        return self._value(masked, quotes)

    def _value(self, s, quotes):
        s = _strip_parens(s.strip().rstrip("."))
        if not s:
            return None
        q = re.match(r"^__Q(\d+)__$", s)
        if q:
            return quotes[int(q.group(1))][1:-1]
        low = s.lower()
        if low in ("true", "false"):
            return low == "true"
        if low in ("unknown", "uncertain", "null"):
            return None
        if re.match(r"^\d{4}-\d{2}-\d{2}$", s):
            return dt.date.fromisoformat(s)
        n = _num(s)
        if not isinstance(n, str):
            return n
        for ops in ((" + ", " - "), (" * ", " / ")):
            pat = re.compile("|".join(re.escape(o) for o in ops))
            ms = _top_level_find(s, pat)
            if ms:
                m = ms[-1]
                left, right = self._value(s[:m.start()], quotes), self._value(s[m.end():], quotes)
                return self._arith(left, m.group(0).strip(), right)
        fm = re.match(r"^([A-Za-z][A-Za-z0-9]*)\s*\(", s)
        if fm and _find_matching(s, fm.end() - 1) == len(s) - 1:
            args = split_args(s[fm.end(): -1])
            return self._func(fm.group(1), args, quotes)
        if s.startswith("-"):
            v = self._value(s[1:], quotes)
            return None if v is None else -_num(v)
        return self.attr(re.sub(r"__Q(\d+)__", lambda m: quotes[int(m.group(1))], s))

    def _arith(self, a, op, b):
        if a is None or b is None:
            return None
        if isinstance(_to_date(a), dt.date) and op in "+-" and not isinstance(_to_date(b), dt.date):
            return _to_date(a) + dt.timedelta(days=_num(b) * (1 if op == "+" else -1))
        a, b = _num(a), _num(b)
        if op == "+":
            return a + b
        if op == "-":
            return a - b
        if op == "*":
            return a * b
        if op == "/":
            return None if b == 0 else a / b
        raise Unsupported(op)

    def _func(self, name, args, quotes):
        f = name.lower()
        v = lambda i: self._value(args[i], quotes)  # noqa: E731
        if f == "if":
            c = self._statement(args[0], quotes)
            return None if c is None else (v(1) if c else v(2))
        if f == "default":
            x = v(0)
            return v(1) if x is None else x
        if f in ("maximum", "minimum"):
            vals = [v(i) for i in range(len(args))]
            if any(x is None for x in vals):
                return None
            return (max if f == "maximum" else min)(_num(x) if not isinstance(x, dt.date) else x for x in vals)
        if f in ("round", "roundup", "rounddown", "trunc"):
            x = v(0)
            places = int(_num(v(1))) if len(args) > 1 else 0
            if x is None:
                return None
            m = 10 ** places
            x = _num(x) * m
            r = {"round": lambda y: math.floor(y + 0.5) if y >= 0 else -math.floor(-y + 0.5),
                 "roundup": lambda y: math.ceil(y) if y >= 0 else math.floor(y),
                 "rounddown": lambda y: math.floor(y) if y >= 0 else math.ceil(y),
                 "trunc": math.trunc}[f](x) / m
            return int(r) if places == 0 else r
        if f == "abs":
            x = v(0)
            return None if x is None else abs(_num(x))
        if f == "currentdate":
            return self.today
        if f == "date":
            if len(args) == 1:
                x = v(0)
                return _to_date(x)
            y, m, d = (v(i) for i in range(3))
            return None if None in (y, m, d) else dt.date(int(y), int(m), int(d))
        if f in ("yeardifference", "monthdifference", "daydifference", "weekdifference"):
            a, b = v(0), v(1)
            if a is None or b is None:
                return None
            if f == "yeardifference":
                return _years_between(a, b)
            if f == "monthdifference":
                return _months_between(a, b)
            days = (_to_date(b) - _to_date(a)).days
            return days if f == "daydifference" else days // 7
        if f in ("adddays", "addweeks", "addmonths", "addyears"):
            d, n = v(0), v(1)
            if d is None or n is None:
                return None
            if f == "adddays":
                return _to_date(d) + dt.timedelta(days=int(n))
            if f == "addweeks":
                return _to_date(d) + dt.timedelta(weeks=int(n))
            return _add_months(d, int(n) * (12 if f == "addyears" else 1))
        self.unsupported.append(name)
        raise Unsupported(f"function {name} is not supported by the evaluator")

    # -- statements ------------------------------------------------------------------------
    def statement(self, text):
        masked, quotes = _mask_quotes(_clean(text))
        return self._statement(masked, quotes)

    def _statement(self, s, quotes):
        s = _strip_parens(s.strip().rstrip("."))
        m = NEG_PREFIX_RE.match(s)
        if m and not s.lower().startswith("not("):
            r = self._statement(s[m.end():], quotes)
            return None if r is None else (not r)
        fm = re.match(r"^not\s*\(", s)
        if fm and _find_matching(s, fm.end() - 1) == len(s) - 1:
            r = self._statement(s[fm.end():-1], quotes)
            return None if r is None else (not r)
        parts = _top_level_find(s, _BOOL_SPLIT_RE)
        if parts:
            ops = {p.group(1).lower() for p in parts}
            pieces = _split_top(s, _BOOL_SPLIT_RE)
            from .rule_text import _looks_like_statement
            if all(_looks_like_statement(p) for p in pieces) and len(ops) == 1:
                vals = [self._statement(p, quotes) for p in pieces]
                return _k_and(vals) if ops == {"and"} else _k_or(vals)
        sm = STATUS_SUFFIX_RE.search(s)
        if sm and not _top_level_find(s, _CMP_RE):
            x = self._value(s[:sm.start()], quotes)
            kind = sm.group(1).lower()
            return (x is not None) if kind in ("known", "certain") else (x is None)
        cms = _top_level_find(s, _CMP_RE)
        if cms:
            cm = cms[0]
            a = self._value(s[:cm.start()], quotes)
            b = self._value(s[cm.end():], quotes)
            if a is None or b is None:
                return None
            a, b = _to_date(a), _to_date(b)
            if not isinstance(a, dt.date):
                a = _num(a) if not isinstance(a, bool) else a
            if not isinstance(b, dt.date):
                b = _num(b) if not isinstance(b, bool) else b
            if isinstance(a, str) and isinstance(b, str):
                a, b = a.lower(), b.lower()   # Intelligent Advisor text comparison is case-insensitive
            op = cm.group(1)
            try:
                return {"=": a == b, "<>": a != b, "<": a < b, ">": a > b,
                        "<=": a <= b, ">=": a >= b}[op]
            except TypeError:
                raise Unsupported(f"cannot compare {a!r} {op} {b!r}")
        v = self._value(s, quotes)
        if v is None or isinstance(v, bool):
            return v
        raise Unsupported(f"'{s}' is not a true/false statement (value {v!r})")

    def _node(self, node):
        if not node["children"]:
            return self.statement(node["body"])
        vals = [self._node(c) for c in node["children"]]
        return _k_and(vals) if _group_op(node) == "and" else _k_or(vals)

    # -- rule --------------------------------------------------------------------------------
    def eval_rule(self, rule_text: str, _inner: bool = False) -> dict:
        branches = _tree(parse_indented(rule_text))
        if not branches:
            return {"value": None, "branch": None}
        attr = branches[0]["attr"]
        unknown_seen = False
        for i, b in enumerate(branches):
            if b["otherwise"]:
                if unknown_seen:
                    return {"attribute": attr, "value": None, "branch": None}
                return {"attribute": attr, "value": self.value(b["value"]) if b["value"] else False,
                        "branch": i + 1}
            ok = True if b["cond"] is None else self._node(b["cond"])
            if ok is True:
                if b["value"] is None:
                    return {"attribute": attr, "value": True, "branch": i + 1}
                return {"attribute": attr, "value": self.value(b["value"]), "branch": i + 1}
            if ok is None:
                unknown_seen = True
        if len(branches) == 1 and branches[0]["value"] is None and not unknown_seen:
            return {"attribute": attr, "value": False, "branch": None}   # boolean rule not met
        return {"attribute": attr, "value": None, "branch": None}


def evaluate_rule(rule_text: str, facts: dict, store=None, today: Optional[str] = None,
                  supporting_rules: Optional[list] = None) -> dict:
    """supporting_rules: other draft rules used to infer attributes missing from facts."""
    ev = Evaluator(facts, store, today, drafts=supporting_rules)
    try:
        res = ev.eval_rule(rule_text)
        out = {"attribute": res.get("attribute"), "value": _jsonable(res.get("value")),
               "branch": res.get("branch")}
    except Unsupported as e:
        out = {"attribute": None, "value": None, "branch": None, "unsupported": str(e)}
    if ev.trace:
        out["inferred"] = ev.trace
    return out


def _jsonable(v):
    if isinstance(v, dt.date):
        return v.isoformat()
    if isinstance(v, float) and v.is_integer():
        return int(v)
    return v
