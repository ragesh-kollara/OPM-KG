"""Core data structures for the OPM / Intelligent Advisor knowledge graph."""
from __future__ import annotations

import re
from dataclasses import dataclass, field, asdict
from typing import Optional


def norm(text: str) -> str:
    """Normalise attribute text so the same attribute matches wherever it is written."""
    t = text.strip().lower()
    t = t.replace("’", "'").replace("‘", "'").replace("“", '"').replace("”", '"')
    t = re.sub(r"\s+", " ", t)
    return t.rstrip(" .;:")


@dataclass
class AttrRef:
    """A reference to an attribute inside a rule."""
    text: str                      # attribute text as written
    role: str                      # "conclusion" | "condition"
    negated: bool = False
    operator: Optional[str] = None  # =, <>, <, >, <=, >= when it appears in a comparison
    value: Optional[str] = None     # comparison value / conclusion value
    function: Optional[str] = None  # enclosing function, e.g. InstanceSum

    @property
    def key(self) -> str:
        return norm(self.text)


@dataclass
class Rule:
    id: str
    document: str
    kind: str                       # "word" | "table" | "excel" | "xml"
    conclusion: str                 # conclusion line / heading
    text: str                       # full rule text, indented
    name: Optional[str] = None      # "OPM - rule name" if present
    section: Optional[str] = None   # nearest heading
    location: Optional[str] = None  # sheet name / paragraph index
    refs: list[AttrRef] = field(default_factory=list)
    functions: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        d = asdict(self)
        return d


@dataclass
class AttributeDef:
    text: str
    entity: str = "global"
    type: Optional[str] = None
    name: Optional[str] = None       # public / integration name
    negative_text: Optional[str] = None
    question_text: Optional[str] = None
    source: Optional[str] = None

    @property
    def key(self) -> str:
        return norm(self.text)


@dataclass
class EntityDef:
    name: str
    text: Optional[str] = None
    parent: Optional[str] = None
    relationships: list[dict] = field(default_factory=list)  # {name, target, type}


@dataclass
class RuleBase:
    name: str
    rules: list[Rule] = field(default_factory=list)
    attributes: dict[str, AttributeDef] = field(default_factory=dict)
    entities: dict[str, EntityDef] = field(default_factory=dict)
    documents: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
