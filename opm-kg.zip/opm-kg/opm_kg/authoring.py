"""Rule authoring support: validate a new / modified rule against the knowledge graph
and write it out as an OPM-styled Word document ready to paste into Policy Modeling.

Rule text format (plain text, 2 spaces or a tab per level):

    the applicant is eligible for the benefit if
      the applicant's age >= 18 and
      either
        the applicant is a resident or
        the applicant is a citizen
"""
from __future__ import annotations

import re
from typing import Optional

from .model import norm, positive_candidates
from .rule_text import parse_indented, refs_from_lines, split_connector, is_group_line, parse_conclusion

_KNOWN_FUNCTIONS = {
    # common Intelligent Advisor 12.2 functions (non-exhaustive)
    "forall", "exists", "for", "forscope", "instancecount", "instancesum", "instancemaximum",
    "instanceminimum", "instanceaverage", "instanceconcat", "instancecountif", "instancesumif",
    "instancemaximumif", "instanceminimumif", "instancevaluewhen", "isamemberof",
    "date", "datetime", "currentdate", "currentdatetime", "dayDifference".lower(), "weekdifference",
    "monthdifference", "yeardifference", "adddays", "addweeks", "addmonths", "addyears",
    "extractday", "extractmonth", "extractyear", "dayofweek", "lastdayofthemonth",
    "if", "default", "maximum", "minimum", "round", "roundup", "rounddown", "trunc", "abs",
    "sqrt", "exp", "ln", "log", "power", "number", "text", "length", "substring", "contains",
    "startswith", "endswith", "concatenate", "isnumber", "istext", "upper", "lower", "trim",
    "textoffset", "replace", "isuncertain", "isunknown", "certain", "known", "cantbeknown",
    "whenknown", "temporalvalue", "temporalvalueon", "temporalsum", "temporalwhen",
    "temporalfromstartdate", "temporalfromenddate", "temporalfromrange", "temporalbefore",
    "temporalafter", "temporalonorbefore", "temporalonorafter", "temporalbeforedate",
    "valueat", "withinlastdays", "withinnextdays", "alwaysbetween", "sometimesbetween",
    "temporalyearlycount", "temporaldailysum", "temporalyearlysum", "temporalmonthlycount",
    "time", "timeofday", "timedifferenceinseconds", "timedifferenceinminutes", "timedifferenceinhours",
}


_AND_GROUPS = ("both", "all")
_OR_GROUPS = ("either", "any", "one or more", "at least one")


def check_structure(lines: list[tuple[int, str]]) -> tuple[list[str], list[str]]:
    """Check if / and / or / group structure of a rule given as [(level, text)].

    A connector ('and'/'or') at the end of a line joins the condition - or, on the last line of a
    group, the whole group - to the next condition at the same level.
    """
    errors, warnings = [], []
    if not lines:
        return ["empty rule text"], []
    if lines[0][0] != 0:
        errors.append("line 1: the conclusion must not be indented")

    # nodes
    nodes = []
    for i, (lvl, txt) in enumerate(lines):
        body, conn = split_connector(txt)
        nodes.append({"i": i, "lvl": lvl, "txt": txt, "body": body, "conn": conn,
                      "group": lvl > 0 and is_group_line(body), "children": [], "parent": None,
                      "attached": None})
    # tree + indentation jumps
    stack = []
    for n in nodes:
        while stack and stack[-1]["lvl"] >= n["lvl"]:
            stack.pop()
        if stack:
            if n["lvl"] > stack[-1]["lvl"] + 1:
                errors.append(f"line {n['i'] + 1}: indented {n['lvl'] - stack[-1]['lvl']} levels "
                              f"deeper than the line above - indent one level at a time")
            n["parent"] = stack[-1]
            stack[-1]["children"].append(n)
        elif n["lvl"] > 0:
            errors.append(f"line {n['i'] + 1}: condition without a conclusion above it")
        stack.append(n)

    roots = [n for n in nodes if n["lvl"] == 0]
    # conclusion lines
    concl_attrs = set()
    for k, r in enumerate(roots):
        low = r["txt"].lower().rstrip(". ")
        attr = parse_conclusion(r["txt"])[0]
        concl_attrs.add(norm(attr))
        if low.endswith(" otherwise"):
            if r["children"]:
                errors.append(f"line {r['i'] + 1}: an 'otherwise' conclusion cannot have conditions")
            if k == 0:
                errors.append(f"line {r['i'] + 1}: 'otherwise' must follow at least one conditional "
                              f"conclusion")
            elif k != len(roots) - 1:
                errors.append(f"line {r['i'] + 1}: 'otherwise' must be the last conclusion")
        elif r["children"] and not low.endswith(" if"):
            errors.append(f"line {r['i'] + 1}: conclusion has conditions but does not end with 'if'")
        elif not r["children"] and low.endswith(" if"):
            errors.append(f"line {r['i'] + 1}: conclusion ends with 'if' but has no conditions")
    if len(concl_attrs) > 1:
        errors.append("the text contains conclusions for different attributes - write them as "
                      "separate rules: " + "; ".join(sorted(concl_attrs)))

    # group / leaf shape
    for n in nodes:
        if n["lvl"] == 0:
            continue
        if n["group"] and not n["children"]:
            errors.append(f"line {n['i'] + 1}: group '{n['body']}' has no indented conditions under it")
        if not n["group"] and n["children"]:
            errors.append(f"line {n['i'] + 1}: '{n['body']}' has indented lines under it but is not "
                          f"a group - start the group with 'both' / 'either' / 'all' / 'any'")

    def next_sibling(n):
        p = n["parent"]
        if p is None:
            return None
        sib = p["children"]
        k = sib.index(n)
        return sib[k + 1] if k + 1 < len(sib) else None

    # attach connectors
    for n in nodes:
        if not n["conn"] or n["lvl"] == 0:
            continue
        cur = n
        while cur is not None and cur["lvl"] > 0 and next_sibling(cur) is None:
            cur = cur["parent"]
        if cur is None or cur["lvl"] == 0:
            warnings.append(f"line {n['i'] + 1}: trailing '{n['conn']}' - nothing follows it")
        elif cur["attached"] and cur["attached"] != n["conn"]:
            errors.append(f"line {n['i'] + 1}: conflicting connectors '{cur['attached']}' and "
                          f"'{n['conn']}'")
        else:
            cur["attached"] = n["conn"]

    # every condition followed by a sibling needs a connector; one kind per group
    for parent in nodes:
        kids = parent["children"]
        conns = set()
        for a, b in zip(kids, kids[1:]):
            if not a["attached"]:
                last = a
                while last["children"]:
                    last = last["children"][-1]
                errors.append(f"line {last['i'] + 1}: missing 'and' / 'or' before line {b['i'] + 1}")
            else:
                conns.add(a["attached"])
        if len(conns) > 1:
            where = f"group on line {parent['i'] + 1}" if parent["lvl"] else "the top level"
            errors.append(f"{where} mixes 'and' and 'or' - wrap one side in 'both' / 'either'")
        if parent["group"] and len(conns) == 1:
            word = parent["body"].lower()
            c = next(iter(conns))
            if word.startswith(_AND_GROUPS) and c == "or":
                warnings.append(f"line {parent['i'] + 1}: '{parent['body']}' group joined with 'or' - "
                                f"did you mean 'either'?")
            if word.startswith(_OR_GROUPS) and c == "and":
                warnings.append(f"line {parent['i'] + 1}: '{parent['body']}' group joined with 'and' - "
                                f"did you mean 'both'?")
    return errors, warnings


def _ids(x) -> list[str]:
    if not x:
        return []
    if isinstance(x, str):
        return [i.strip() for i in x.split("|") if i.strip()]
    return [str(i) for i in x]


def _draft_map(drafts) -> dict:
    """conclusion key -> set of condition keys, for the other draft rules in the same change."""
    out = {}
    for d in drafts or []:
        refs, _ = refs_from_lines(parse_indented(d))
        concl = [r.key for r in refs if r.role == "conclusion"]
        if concl:
            out.setdefault(concl[0], set()).update(r.key for r in refs if r.role == "condition")
    return out


def validate_rule(store, rule_text: str, replacing_rule_id=None, other_drafts=None) -> dict:
    """Check a proposed rule against the graph.

    other_drafts: the other rules in the same change - attributes they conclude count as defined,
    and they are included in duplicate and circularity checks.

    Returns issues (errors/warnings), the attributes it references (existing vs new),
    and the downstream impact of changing its conclusion.
    """
    drafts = _draft_map(other_drafts)
    lines = parse_indented(rule_text)
    errors, warnings, info = [], [], []
    if not lines:
        return {"valid": False, "errors": ["empty rule text"]}
    refs, functions = refs_from_lines(lines)
    conclusions = [r for r in refs if r.role == "conclusion"]
    conditions = [r for r in refs if r.role == "condition"]

    # --- structural checks ---------------------------------------------------------------------
    s_err, s_warn = check_structure(lines)
    errors += s_err
    warnings += s_warn

    for fn in functions:
        if fn.lower() not in _KNOWN_FUNCTIONS:
            warnings.append(f"function '{fn}' is not in the known Intelligent Advisor function list - "
                            f"check spelling")

    # --- graph checks --------------------------------------------------------------------------
    concl_report = []
    for c in {r.key: r for r in conclusions}.values():
        a = store.get_attribute(c.text)
        entry = {"attribute": c.text, "exists": a.get("found", False)}
        if a.get("found"):
            other = [r["id"] for r in a["concluded_by"] if r["id"] not in _ids(replacing_rule_id)]
            entry["currently_concluded_by"] = other
            entry["used_by_rules"] = [r["id"] for r in a["used_by"]]
            if other:
                errors.append(f"'{c.text}' is already proven by {', '.join(other)}. Intelligent Advisor "
                              f"allows one rule (or rule table) per attribute - modify that rule instead, "
                              f"or pass replacing_rule_id.")
            if a.get("is_base_attribute") and a["used_by"]:
                warnings.append(f"'{c.text}' is currently a base (input) attribute - concluding it will "
                                f"stop it being collected on screens / from data mapping")
        else:
            entry["suggestions"] = store.suggest(c.text)
            info.append(f"'{c.text}' is a new attribute - add it to the data model if it needs a "
                        f"type / public name")
        if c.key in drafts:
            errors.append(f"'{c.text}' is also concluded by another rule in this change - "
                          f"combine them into one rule")
        t = (a.get("type") or "").lower() if a.get("found") and a.get("source") != "inferred" else ""
        if t == "boolean" and c.value is not None:
            errors.append(f"'{c.text}' is a boolean attribute but the rule assigns it a value "
                          f"('= {c.value}') - write '{c.text} if'")
        elif t and t != "boolean" and c.value is None:
            errors.append(f"'{c.text}' is a {t} attribute - the conclusion needs '= <value>'")
        concl_report.append(entry)

    cond_report, seen = [], set()
    for c in conditions:
        if c.key in seen:
            continue
        seen.add(c.key)
        a = store.get_attribute(c.text)
        entry = {"attribute": c.text, "exists": a.get("found", False)}
        if a.get("found"):
            entry["type"] = a.get("type")
            entry["is_base_attribute"] = a.get("is_base_attribute")
            if norm(a["text"]) != c.key:
                entry["resolved_to"] = a["text"]
            t = (a.get("type") or "").lower() if a.get("source") != "inferred" else ""
            uses = [r for r in conditions if r.key == c.key]
            if t == "boolean" and any(r.operator in ("<", ">", "<=", ">=") for r in uses):
                errors.append(f"'{c.text}' is boolean but is compared with <, >, <= or >=")
            if t in ("number", "currency", "date", "datetime", "text", "time") and \
                    any(r.usage == "boolean" and r.operator is None and not r.function for r in uses):
                errors.append(f"'{c.text}' is a {t} attribute used as a true/false condition - "
                              f"compare it with a value (e.g. '{c.text} > 0')")
        elif c.key in drafts or any(p in drafts for p in positive_candidates(c.key)):
            entry["defined_in_this_change"] = True
        else:
            entry["suggestions"] = store.suggest(c.text)
            warnings.append(f"condition attribute not found in rulebase: '{c.text}'"
                            + (f" - did you mean '{entry['suggestions'][0]}'?" if entry["suggestions"] else
                               " (it will become a new base attribute)"))
        cond_report.append(entry)

    # --- circularity ---------------------------------------------------------------------------
    def resolved(text):
        a = store.get_attribute(text)
        return norm(a["text"]) if a.get("found") else norm(text)

    _closure_cache: dict = {}

    def closure(text):
        """Everything text depends on, through the rulebase and the other drafts.

        The rulebase closure is already transitive, so it is fetched once per starting key;
        only draft-rule dependencies need further expansion."""
        start = resolved(text)
        if start in _closure_cache:
            return _closure_cache[start]
        seen, todo, expanded = set(), [start], set()
        while todo:
            k = todo.pop()
            if k in expanded:
                continue
            expanded.add(k)
            nxt = set(drafts.get(k, set()))
            if k == start or k in drafts or any(k in d for d in drafts.values()):
                nxt |= store.depends_on_closure(k)
            for n in nxt - seen:
                seen.add(n)
                todo.append(n)
        _closure_cache[start] = seen
        return seen

    for c in {r.key: r for r in conclusions}.values():
        ck = resolved(c.text)
        for cond in {r.key: r for r in conditions}.values():
            if resolved(cond.text) == ck:
                errors.append(f"rule uses its own conclusion '{c.text}' as a condition")
                continue
            if ck in closure(cond.text):
                errors.append(f"circular dependency: '{cond.text}' already depends on '{c.text}'")

    impact = {}
    for c in {r.key: r for r in conclusions}.values():
        d = store.downstream(c.text)
        if d.get("found"):
            impact[c.text] = {"affected_attributes": [x["attribute"] for x in d["affected_attributes"]],
                              "affected_rules": d["affected_rules"]}

    return {"valid": not errors, "errors": errors, "warnings": warnings, "info": info,
            "conclusions": concl_report, "conditions": cond_report,
            "functions": sorted(set(functions)), "impact": impact}


# ----------------------------------------------------------------------------------------------
# Word output
# ----------------------------------------------------------------------------------------------
def _ensure_styles(doc):
    from docx.enum.style import WD_STYLE_TYPE
    from docx.shared import Pt, Cm
    styles = doc.styles
    names = {s.name for s in styles}

    def add(name, indent_cm, bold=False):
        if name in names:
            return
        st = styles.add_style(name, WD_STYLE_TYPE.PARAGRAPH)
        st.base_style = styles["Normal"]
        st.font.name = "Calibri"
        st.font.size = Pt(11)
        st.font.bold = bold
        st.paragraph_format.left_indent = Cm(indent_cm)
        st.paragraph_format.space_after = Pt(2)

    add("OPM - rule name", 0, bold=True)
    add("OPM - conclusion", 0, bold=True)
    for lvl in range(1, 10):
        add(f"OPM - level {lvl}", 1.0 * lvl)
    add("OPM - heading 1", 0, bold=True)
    add("OPM - comment", 0)


def is_multi_branch(rule_text: str) -> bool:
    return sum(1 for lvl, _ in parse_indented(rule_text) if lvl == 0) > 1


def write_rule(doc, rule_text: str, name: Optional[str] = None, comment: Optional[str] = None) -> None:
    """Append one rule to a python-docx Document using OPM styles.

    Single-conclusion rules are written as OPM paragraphs. Rules with several conclusion lines
    (value = x if ..., value = y if ..., value = z otherwise) are written as a Word rule table:
    header row = conclusion attribute; each row = value | conditions; last row 'otherwise'.
    """
    _ensure_styles(doc)
    if comment:
        doc.add_paragraph(comment, style="OPM - comment")
    if name:
        doc.add_paragraph(name, style="OPM - rule name")
    lines = parse_indented(rule_text)
    if not is_multi_branch(rule_text):
        for lvl, txt in lines:
            style = "OPM - conclusion" if lvl == 0 else f"OPM - level {min(lvl, 9)}"
            doc.add_paragraph(txt, style=style)
        return
    branches = []
    for lvl, txt in lines:
        if lvl == 0:
            attr, value, _ = parse_conclusion(txt)
            other = txt.lower().rstrip(". ").endswith(" otherwise")
            branches.append({"attr": attr, "value": value, "otherwise": other, "conds": []})
        else:
            branches[-1]["conds"].append((lvl, txt))
    table = doc.add_table(rows=1 + len(branches), cols=2)
    table.style = doc.styles["Table Grid"] if "Table Grid" in [s.name for s in doc.styles] else None
    hdr = table.cell(0, 0).paragraphs[0]
    hdr.text = branches[0]["attr"]
    hdr.style = doc.styles["OPM - conclusion"]
    for r, b in enumerate(branches, start=1):
        c0 = table.cell(r, 0).paragraphs[0]
        c0.text = b["value"] if b["value"] is not None else "true"
        c0.style = doc.styles["OPM - conclusion"]
        cell = table.cell(r, 1)
        if b["otherwise"] or not b["conds"]:
            p = cell.paragraphs[0]
            p.text = "otherwise"
            p.style = doc.styles["OPM - level 1"]
            continue
        first = True
        for lvl, txt in b["conds"]:
            p = cell.paragraphs[0] if first else cell.add_paragraph()
            first = False
            p.text = txt
            p.style = doc.styles[f"OPM - level {min(lvl, 9)}"]


def rules_to_docx(rules: list[dict], path: str, title: Optional[str] = None) -> str:
    """rules: [{"text": <indented rule text>, "name": optional, "comment": optional}]"""
    import docx
    doc = docx.Document()
    _ensure_styles(doc)
    if title:
        doc.add_paragraph(title, style="OPM - heading 1")
    for r in rules:
        write_rule(doc, r["text"], r.get("name"), r.get("comment"))
        doc.add_paragraph("")
    doc.save(path)
    return path


def format_rule(rule_text: str, indent: str = "  ") -> str:
    """Normalise indentation / whitespace of rule text."""
    return "\n".join(indent * lvl + re.sub(r"\s+", " ", t) for lvl, t in parse_indented(rule_text))
