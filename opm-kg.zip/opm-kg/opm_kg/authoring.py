"""Rule authoring support: validate a new / modified rule against the knowledge graph
and write it out as an OPM-styled Word document ready to paste into Policy Modeling.

Rule text format (plain text, 2 spaces or a tab per level):

    the applicant is eligible for the benefit if
      the applicant's age >= 18 and
      either
        the applicant is a resident or
        the applicant is a citizen
"""
from __future__ import annotations

import re
from typing import Optional

from .model import norm
from .rule_text import parse_indented, refs_from_lines, split_connector, is_group_line

_KNOWN_FUNCTIONS = {
    # common Intelligent Advisor 12.2 functions (non-exhaustive)
    "forall", "exists", "for", "forscope", "instancecount", "instancesum", "instancemaximum",
    "instanceminimum", "instanceaverage", "instanceconcat", "instancecountif", "instancesumif",
    "instancemaximumif", "instanceminimumif", "instancevaluewhen", "isamemberof",
    "date", "datetime", "currentdate", "currentdatetime", "dayDifference".lower(), "weekdifference",
    "monthdifference", "yeardifference", "adddays", "addweeks", "addmonths", "addyears",
    "extractday", "extractmonth", "extractyear", "dayofweek", "lastdayofthemonth",
    "if", "default", "maximum", "minimum", "round", "roundup", "rounddown", "trunc", "abs",
    "sqrt", "exp", "ln", "log", "power", "number", "text", "length", "substring", "contains",
    "startswith", "endswith", "concatenate", "isnumber", "istext", "upper", "lower", "trim",
    "textoffset", "replace", "isuncertain", "isunknown", "certain", "known", "cantbeknown",
    "whenknown", "temporalvalue", "temporalvalueon", "temporalsum", "temporalwhen",
    "temporalfromstartdate", "temporalfromenddate", "temporalfromrange", "temporalbefore",
    "temporalafter", "temporalonorbefore", "temporalonorafter", "temporalbeforedate",
    "valueat", "withinlastdays", "withinnextdays", "alwaysbetween", "sometimesbetween",
    "temporalyearlycount", "temporaldailysum", "temporalyearlysum", "temporalmonthlycount",
    "time", "timeofday", "timedifferenceinseconds", "timedifferenceinminutes", "timedifferenceinhours",
}


def validate_rule(store, rule_text: str, replacing_rule_id: Optional[str] = None) -> dict:
    """Check a proposed rule against the graph.

    Returns issues (errors/warnings), the attributes it references (existing vs new),
    and the downstream impact of changing its conclusion.
    """
    lines = parse_indented(rule_text)
    errors, warnings, info = [], [], []
    if not lines:
        return {"valid": False, "errors": ["empty rule text"]}
    if lines[0][0] != 0:
        errors.append("first line must be the conclusion (no indentation)")

    refs, functions = refs_from_lines(lines)
    conclusions = [r for r in refs if r.role == "conclusion"]
    conditions = [r for r in refs if r.role == "condition"]

    # --- structural checks ---------------------------------------------------------------------
    first = lines[0][1].rstrip(".")
    has_conditions = any(lvl > 0 for lvl, _ in lines)
    if has_conditions and not first.lower().endswith(" if"):
        errors.append("conclusion has conditions but does not end with 'if'")
    for i, (lvl, txt) in enumerate(lines[1:], start=1):
        body, conn = split_connector(txt)
        nxt = lines[i + 1] if i + 1 < len(lines) else None
        grp = is_group_line(body)
        if lvl == 0:
            continue
        if nxt and nxt[0] == lvl and not grp and conn is None:
            errors.append(f"line {i + 1}: sibling condition follows without 'and'/'or': '{txt}'")
        if nxt and nxt[0] > lvl and not grp:
            errors.append(f"line {i + 1}: indented lines follow a condition that is not a group "
                          f"('both'/'either'/'all'/'any'): '{txt}'")
        if grp and not (nxt and nxt[0] == lvl + 1):
            errors.append(f"line {i + 1}: group '{body}' has no indented conditions under it")
        if conn and (nxt is None or nxt[0] < lvl):
            warnings.append(f"line {i + 1}: trailing '{conn}' on the last condition of a group")
    # mixed connectors at one level of one group
    groups: dict[tuple, set] = {}
    parent_at: dict[int, int] = {}
    for i, (lvl, txt) in enumerate(lines):
        parent_at[lvl] = i
        _, conn = split_connector(txt)
        if conn and lvl > 0:
            groups.setdefault((parent_at.get(lvl - 1, 0), lvl), set()).add(conn)
    for (p, lvl), conns in groups.items():
        if len(conns) > 1:
            errors.append(f"level {lvl} under line {p + 1}: mixes 'and' and 'or' - wrap one side in "
                          f"'both'/'either'")

    for fn in functions:
        if fn.lower() not in _KNOWN_FUNCTIONS:
            warnings.append(f"function '{fn}' is not in the known Intelligent Advisor function list - "
                            f"check spelling")

    # --- graph checks --------------------------------------------------------------------------
    concl_report = []
    for c in {r.key: r for r in conclusions}.values():
        a = store.get_attribute(c.text)
        entry = {"attribute": c.text, "exists": a.get("found", False)}
        if a.get("found"):
            other = [r["id"] for r in a["concluded_by"] if r["id"] != replacing_rule_id]
            entry["currently_concluded_by"] = other
            entry["used_by_rules"] = [r["id"] for r in a["used_by"]]
            if other:
                errors.append(f"'{c.text}' is already proven by {', '.join(other)}. Intelligent Advisor "
                              f"allows one rule (or rule table) per attribute - modify that rule instead, "
                              f"or pass replacing_rule_id.")
            if a.get("is_base_attribute") and a["used_by"]:
                warnings.append(f"'{c.text}' is currently a base (input) attribute - concluding it will "
                                f"stop it being collected on screens / from data mapping")
        else:
            entry["suggestions"] = store.suggest(c.text)
            info.append(f"'{c.text}' is a new attribute - add it to the data model if it needs a "
                        f"type / public name")
        concl_report.append(entry)

    cond_report, seen = [], set()
    for c in conditions:
        if c.key in seen:
            continue
        seen.add(c.key)
        a = store.get_attribute(c.text)
        entry = {"attribute": c.text, "exists": a.get("found", False)}
        if a.get("found"):
            entry["type"] = a.get("type")
            entry["is_base_attribute"] = a.get("is_base_attribute")
            if norm(a["text"]) != c.key:
                entry["resolved_to"] = a["text"]
        else:
            entry["suggestions"] = store.suggest(c.text)
            warnings.append(f"condition attribute not found in rulebase: '{c.text}'"
                            + (f" - did you mean '{entry['suggestions'][0]}'?" if entry["suggestions"] else
                               " (it will become a new base attribute)"))
        cond_report.append(entry)

    # --- circularity ---------------------------------------------------------------------------
    def resolved(text):
        a = store.get_attribute(text)
        return norm(a["text"]) if a.get("found") else norm(text)

    for c in conclusions:
        ck = resolved(c.text)
        for cond in conditions:
            if resolved(cond.text) == ck:
                errors.append(f"rule uses its own conclusion '{c.text}' as a condition")
                continue
            if ck in store.depends_on_closure(cond.text):
                errors.append(f"circular dependency: '{cond.text}' already depends on '{c.text}'")

    impact = {}
    for c in {r.key: r for r in conclusions}.values():
        d = store.downstream(c.text)
        if d.get("found"):
            impact[c.text] = {"affected_attributes": [x["attribute"] for x in d["affected_attributes"]],
                              "affected_rules": d["affected_rules"]}

    return {"valid": not errors, "errors": errors, "warnings": warnings, "info": info,
            "conclusions": concl_report, "conditions": cond_report,
            "functions": sorted(set(functions)), "impact": impact}


# ----------------------------------------------------------------------------------------------
# Word output
# ----------------------------------------------------------------------------------------------
def _ensure_styles(doc):
    from docx.enum.style import WD_STYLE_TYPE
    from docx.shared import Pt, Cm
    styles = doc.styles
    names = {s.name for s in styles}

    def add(name, indent_cm, bold=False):
        if name in names:
            return
        st = styles.add_style(name, WD_STYLE_TYPE.PARAGRAPH)
        st.base_style = styles["Normal"]
        st.font.name = "Calibri"
        st.font.size = Pt(11)
        st.font.bold = bold
        st.paragraph_format.left_indent = Cm(indent_cm)
        st.paragraph_format.space_after = Pt(2)

    add("OPM - rule name", 0, bold=True)
    add("OPM - conclusion", 0, bold=True)
    for lvl in range(1, 10):
        add(f"OPM - level {lvl}", 1.0 * lvl)
    add("OPM - heading 1", 0, bold=True)
    add("OPM - comment", 0)


def rules_to_docx(rules: list[dict], path: str, title: Optional[str] = None) -> str:
    """rules: [{"text": <indented rule text>, "name": optional, "comment": optional}]"""
    import docx
    doc = docx.Document()
    _ensure_styles(doc)
    if title:
        doc.add_paragraph(title, style="OPM - heading 1")
    for r in rules:
        if r.get("comment"):
            doc.add_paragraph(r["comment"], style="OPM - comment")
        if r.get("name"):
            doc.add_paragraph(r["name"], style="OPM - rule name")
        for lvl, txt in parse_indented(r["text"]):
            style = "OPM - conclusion" if lvl == 0 else f"OPM - level {min(lvl, 9)}"
            doc.add_paragraph(txt, style=style)
        doc.add_paragraph("")
    doc.save(path)
    return path


def format_rule(rule_text: str, indent: str = "  ") -> str:
    """Normalise indentation / whitespace of rule text."""
    return "\n".join(indent * lvl + re.sub(r"\s+", " ", t) for lvl, t in parse_indented(rule_text))
