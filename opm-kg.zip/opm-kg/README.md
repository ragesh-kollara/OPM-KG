# opm-kg: knowledge graph and MCP server for Oracle Intelligent Advisor rulebases

> Full architecture and VS Code setup guide: [docs/SETUP_AND_ARCHITECTURE.md](docs/SETUP_AND_ARCHITECTURE.md)

This tool parses an Intelligent Advisor 12.2 rulebase into a graph of rules, attributes, entities and dependencies, and loads that graph into Neo4j. A FastMCP server lets Claude search the graph, trace lineage, run impact analysis, validate new or modified rules, and write them back out as a Word document that uses OPM styles.

## 1. Install (on your machine)

```bash
pip install -r requirements.txt          # mcp, networkx, lxml, python-docx, openpyxl, neo4j
```

## 2. Build the graph from your export

```bash
python -m opm_kg.cli inspect  MyProject.zip                 # optional: list the files and XML structure found
python -m opm_kg.cli build    MyProject.zip -o graph.json --cypher graph.cypher
```

Supported input:

| Input | What is extracted |
|---|---|
| `Rules/*.docx` | Rules written in the `OPM - conclusion`, `OPM - level N` and `OPM - rule name` styles, headings, and Word rule tables |
| `Rules/*.xlsx` | Excel rule tables. Columns come from the `OPM - conclusion heading` and `OPM - condition heading` styles; without those styles, the first column is taken as the conclusion. |
| `*.xml`, `*.xprj` | Entities, attributes (text, type, public name, negative text), relationships and rule elements |
| `.zip` (nested zips included) or a folder | Every supported file inside |
| `.txt` | Plain-text rules, only when passed directly (a `.txt` inside an export is ignored) |

The parser skips these: Word lock files (`~$...`), ordinary Word tables without OPM styles (version history, for example), and Excel sheets with no rule table. Corrupt files are reported as warnings and don't stop the build. When two documents share a file name, rule IDs include enough of the folder path to tell them apart (`Rules/Eligibility.docx#rule 1` versus `Sub/Eligibility.docx#rule 1`).

Attributes that appear in rules but are missing from the data model are still added, flagged `source = inferred`.

## 3. Load into Neo4j

Choose one of these two options:

```bash
# (a) Python driver - replaces existing OPM nodes, so reloading never duplicates relationships
python -m opm_kg.cli neo4j graph.json --uri bolt://localhost:7687 --user neo4j --password <pw>
# (b) no Python driver needed
cypher-shell -u neo4j -p <pw> -f graph.cypher
```

### Graph schema

```
(:RuleBase)-[:HAS_DOCUMENT]->(:Document)-[:CONTAINS]->(:Rule)
(:Rule)-[:CONCLUDES {value}]->(:Attribute)
(:Rule)-[:USES {negated, operator, value, function}]->(:Attribute)
(:Rule)-[:TRAVERSES {function}]->(:Relationship)      e.g. InstanceSum(the applicant's household members, ...)
(:Entity)-[:OWNS]->(:Relationship)-[:TARGETS]->(:Entity)   when the data model declares the relationship
(:Rule)-[:CALLS]->(:Function)
(:Entity)-[:HAS_ATTRIBUTE]->(:Attribute)
(:Entity)-[:RELATES_TO]->(:Entity)
(:Attribute)-[:DEPENDS_ON {rule}]->(:Attribute)        derived: conclusion -> each condition
```

A full-text index named `opm_text` covers attribute text and rule text.

Example Cypher queries:

```cypher
// everything that feeds eligibility
MATCH p=(:Attribute {key:'the applicant is eligible for the housing benefit'})-[:DEPENDS_ON*]->(b) RETURN p;
// attributes proven by more than one rule
MATCH (r:Rule)-[:CONCLUDES]->(a) WITH a, collect(r.id) AS rs WHERE size(rs) > 1 RETURN a.text, rs;
// input attributes (asked on screens or mapped in)
MATCH (a:Attribute) WHERE NOT ()-[:CONCLUDES]->(a) AND ()-[:USES]->(a) RETURN a.text, a.entity;
```

## 4. Register the MCP server

Add this to the Claude desktop config (`claude_desktop_config.json`) or to `.mcp.json` for Claude Code:

```json
{
  "mcpServers": {
    "opm-kg": {
      "command": "python",
      "args": ["C:/path/to/opm-kg/server.py"],
      "env": {
        "OPM_KG_BACKEND": "neo4j",
        "NEO4J_URI": "bolt://localhost:7687",
        "NEO4J_USER": "neo4j",
        "NEO4J_PASSWORD": "<pw>",
        "OPM_KG_OUTPUT_DIR": "C:/path/to/opm-kg/output"
      }
    }
  }
}
```

To run without Neo4j, set `"OPM_KG_BACKEND": "json"` and `"OPM_KG_GRAPH": "C:/path/to/graph.json"`.

### Tools

| Tool | Purpose |
|---|---|
| `rulebase_overview` | Counts of rules, attributes, entities and inputs |
| `search` | Keyword search across attributes, rules, entities and documents |
| `get_attribute` | Type, entity, the rule that proves the attribute, and the rules that use it. Negative forms resolve to the positive attribute. |
| `get_rule` | Full rule text with its conclusions, conditions, functions and relationships |
| `trace_dependencies` | Upstream lineage down to the base inputs |
| `impact_analysis` | The attributes and rules downstream of a change |
| `list_rules_in_document`, `list_entities`, `get_entity`, `list_base_attributes` | Browse the rulebase |
| `rulebase_diagnostics` | Attributes proven more than once, dependency cycles, and attributes that are unused or missing from the data model |
| `validate_rule_text` | Checks a draft rule for structure errors, unknown attributes (with suggestions), duplicate proofs and cycles, and reports its impact |
| `export_rules_docx` | Writes rules to a .docx in OPM styles, ready to paste into a Policy Modeling rule document |
| `reload_graph` | Picks up a rebuilt graph without restarting the server |
| `analyze_requirement`, `evaluate_rule`, `check_rule_examples`, `generate_test_cases`, `export_change_package` | Rule generation from requirements (section 6) |

If a tool fails (the graph file is missing, Neo4j can't be reached, or a parameter is wrong), it returns `{"error": ..., "kind": ...}` instead of crashing, so Claude can report the problem clearly.

## 5. Rule-authoring workflow

1. Run `search` and `get_attribute` to find the exact existing attribute text, so the new rule doesn't create near-duplicate attributes.
2. Run `get_rule` on the rule you're changing, and `impact_analysis` on its conclusion.
3. Draft the rule as plain text, using 2 spaces per indentation level:
   ```
   the applicant meets the residency requirement if
     either
       the applicant is a citizen or
       both
         the applicant is a permanent resident and
         the applicant's years of residence >= 2
   ```
4. Run `validate_rule_text`, passing `replacing_rule_id` when you're modifying a rule. Repeat until `errors` is empty. The validator checks:
   - structure: `if`, `and`/`or` on every condition that is followed by a sibling (a group's connector goes on its last line), no mixing of `and` and `or` in one group, groups that have children, one level of indentation at a time, and `otherwise` last
   - one conclusion attribute per rule, not already proven by another rule
   - types from the data model: a boolean isn't given a value, a number, text or date attribute isn't used as a true/false condition, and a boolean isn't compared with `<` or `>`
   - unknown attributes, with "did you mean" suggestions, and unknown function names
   - circular dependencies, including through negative wording
   - downstream impact
5. Run `export_rules_docx` and paste the result into the rule document in Policy Modeling.
6. Rebuild the graph so it reflects the change.

## 6. Generate rules from a business requirement

Claude writes the rules, and the tools give it the facts and check the result. In VS Code chat (Agent mode), either:

* type `/` and pick **mcp.opm-kg.rules_from_requirement**, then paste the requirement, or
* just ask: *"Using opm-kg, write the rules for this requirement: ..."*

The prompt runs this loop:

| Step | Tool | What it does |
|---|---|---|
| 1 | `analyze_requirement` | Finds the existing attributes and rules the requirement touches, with full rule text. It also finds current rules that contain the requirement's thresholds (e.g. the rule with `>= 18` when the minimum age is "raised from 18 to 21"), and reports the requirement's intent (add, modify or remove) and existing problems in scope, such as an attribute proven twice. |
| 2 | `get_rule`, `get_attribute`, `trace_dependencies` | Pulls more detail where needed |
| 3 | (Claude) | Drafts rules in the plain-text format of the authoring guide (resource `opm://authoring-guide`), reusing existing attribute text exactly |
| 4 | `validate_rule_text` | Checks structure, types, duplicate proofs and cycles. `other_draft_rules` makes attributes defined by sibling drafts count as known. For `replacing_rule_id`, `A|B` merges two rules that prove the same attribute. |
| 5 | `check_rule_examples` | Runs the requirement's worked examples through the draft. `supporting_rules` lets an end-to-end example such as "earning 12,000 with 2 children gets 40" flow through the whole new chain of rules. |
| 6 | `generate_test_cases` | Generates boundary and combination scenarios with expected results, and flags branches no input can reach (overlapping conditions) |
| 7 | `impact_analysis` | Lists the rules downstream of each modified conclusion that need retesting |
| 8 | `export_change_package` | Writes three files and reports READY or NEEDS WORK (see below) |

`export_change_package` writes:

* `<name>.docx`: a review document with the requirement, a summary table and, for each change, the current rule, proposed rule, validation, impact, example results and test scenarios
* `<name>_rules.docx`: the rules in OPM styles, ready to paste into Policy Modeling. Value rules with several outcomes are written as Word rule tables.
* `<name>_tests.xlsx`: test scenarios with expected results, one sheet per change, plus the example checks

`evaluate_rule` runs any rule on facts. With `use_rulebase=True`, missing attributes are inferred from your existing rules.

**Evaluator scope:** the evaluator handles boolean logic with unknowns, groups, negation, comparisons, arithmetic, text, dates, and these functions: `If`, `Default`, `Maximum`/`Minimum`, the `Round` family, date differences and the `Add*` date functions. Entity functions (`ForAll`, `InstanceCount`, ...) and temporal functions are reported as "not simulated". Test those rules in Policy Modeling.

**Demo:** `python examples/run_demo.py` runs the whole loop through the MCP server on the dummy rulebase. The sample requirement raises the minimum age from 18 to 21, adds a hardship top-up in bands, and excludes flagged applicants. The run produces `output/demo/CR-2027-01*.docx/.xlsx`.

## Tests

```bash
python tests/run_tests.py          # no extra packages needed
python -m pytest -q tests          # same tests, if pytest is installed
```

| Suite | What it proves |
|---|---|
| `test_accuracy.py` | Parses an awkward dummy export (`tests/fixtures/make_dummy.py`) and checks every rule's conclusion, conditions, negation and relationships against hand-written ground truth. The export includes curly apostrophes, Word rule tables and a non-rule table, Excel tables with title rows and no styles, a nested zip, a corrupt file, a lock file, a README, a duplicate file name, a duplicate proof and a dependency cycle. |
| `test_validator.py` | Structure errors and warnings, type checks, duplicate proofs, cycles, suggestions, and a docx round trip |
| `test_neo4j_glue.py` | Parity between the Neo4j backend's traversal and the in-memory backend, Cypher literal escaping, and the structure of the `.cypher` export |
| `test_mcp_server.py` | Starts `server.py` over stdio with a real MCP client and calls every tool, including the error paths |
| `test_robustness.py` | 1,500 random malformed rules must never crash the parser or validator, and a synthetic 3,000-rule rulebase must build and answer queries within time limits |
| `test_generation.py` | Evaluator semantics; requirement retrieval (thresholds, requirement IDs ignored, duplicate-proof problems); boundary tests; unreachable branches; examples catching a wrong draft; end-to-end examples through draft chains; draft-aware validation; the change package (READY, NEEDS WORK, rules docx round trip) |
| `test_e2e.py` | The small HousingBenefit sample |

The Neo4j Cypher itself (in `neo4j_store.py`) has been reviewed but not run against a live database. After loading your graph, compare `rulebase_overview` on the `json` and `neo4j` backends; the counts should match.
