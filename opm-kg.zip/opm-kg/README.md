# opm-kg: knowledge graph and MCP server for Oracle Intelligent Advisor rulebases

This tool parses an Intelligent Advisor 12.2 rulebase into a graph of rules, attributes, entities and dependencies, and loads that graph into Neo4j. A FastMCP server lets Claude search the graph, trace lineage, run impact analysis, validate new or modified rules, and write them back out as a Word document that uses OPM styles.

## 1. Install (on your machine)

```bash
pip install -r requirements.txt          # mcp, networkx, lxml, python-docx, openpyxl, neo4j
```

## 2. Build the graph from your export

```bash
python -m opm_kg.cli inspect  MyProject.zip                 # optional: list the files and XML structure found
python -m opm_kg.cli build    MyProject.zip -o graph.json --cypher graph.cypher
```

Supported input:

| Input | What is extracted |
|---|---|
| `Rules/*.docx` | Rules written in the `OPM - conclusion`, `OPM - level N` and `OPM - rule name` styles, headings, and Word rule tables |
| `Rules/*.xlsx` | Excel rule tables. Columns come from the `OPM - conclusion heading` and `OPM - condition heading` styles; without those styles, the first column is taken as the conclusion. |
| `*.xml`, `*.xprj` | Entities, attributes (text, type, public name, negative text), relationships and rule elements |
| `.zip` (nested zips included) or a folder | Every supported file inside |

Attributes that appear in rules but are missing from the data model are still added, flagged `source = inferred`.

## 3. Load into Neo4j

Choose one of these two options:

```bash
# (a) Python driver
python -m opm_kg.cli neo4j graph.json --uri bolt://localhost:7687 --user neo4j --password <pw> --wipe
# (b) no Python driver needed
cypher-shell -u neo4j -p <pw> -f graph.cypher
```

### Graph schema

```
(:RuleBase)-[:HAS_DOCUMENT]->(:Document)-[:CONTAINS]->(:Rule)
(:Rule)-[:CONCLUDES {value}]->(:Attribute)
(:Rule)-[:USES {negated, operator, value, function}]->(:Attribute)
(:Rule)-[:TRAVERSES {function}]->(:Relationship)      e.g. InstanceSum(the applicant's household members, ...)
(:Rule)-[:CALLS]->(:Function)
(:Entity)-[:HAS_ATTRIBUTE]->(:Attribute)
(:Entity)-[:RELATES_TO]->(:Entity)
(:Attribute)-[:DEPENDS_ON {rule}]->(:Attribute)        derived: conclusion -> each condition
```

A full-text index named `opm_text` covers attribute text and rule text.

Example Cypher queries:

```cypher
// everything that feeds eligibility
MATCH p=(:Attribute {key:'the applicant is eligible for the housing benefit'})-[:DEPENDS_ON*]->(b) RETURN p;
// attributes proven by more than one rule
MATCH (r:Rule)-[:CONCLUDES]->(a) WITH a, collect(r.id) AS rs WHERE size(rs) > 1 RETURN a.text, rs;
// input attributes (asked on screens or mapped in)
MATCH (a:Attribute) WHERE NOT ()-[:CONCLUDES]->(a) AND ()-[:USES]->(a) RETURN a.text, a.entity;
```

## 4. Register the MCP server

Add this to the Claude desktop config (`claude_desktop_config.json`) or to `.mcp.json` for Claude Code:

```json
{
  "mcpServers": {
    "opm-kg": {
      "command": "python",
      "args": ["C:/path/to/opm-kg/server.py"],
      "env": {
        "OPM_KG_BACKEND": "neo4j",
        "NEO4J_URI": "bolt://localhost:7687",
        "NEO4J_USER": "neo4j",
        "NEO4J_PASSWORD": "<pw>",
        "OPM_KG_OUTPUT_DIR": "C:/path/to/opm-kg/output"
      }
    }
  }
}
```

To run without Neo4j, set `"OPM_KG_BACKEND": "json"` and `"OPM_KG_GRAPH": "C:/path/to/graph.json"`.

### Tools

| Tool | Purpose |
|---|---|
| `rulebase_overview` | Counts of rules, attributes, entities and inputs |
| `search` | Keyword search across attributes, rules, entities and documents |
| `get_attribute` | Type, entity, the rule that proves the attribute, and the rules that use it. Negative forms resolve to the positive attribute. |
| `get_rule` | Full rule text with its conclusions, conditions, functions and relationships |
| `trace_dependencies` | Upstream lineage down to the base inputs |
| `impact_analysis` | The attributes and rules downstream of a change |
| `list_rules_in_document`, `list_entities`, `get_entity`, `list_base_attributes` | Browse the rulebase |
| `rulebase_diagnostics` | Attributes proven more than once, dependency cycles, and attributes that are unused or missing from the data model |
| `validate_rule_text` | Checks a draft rule for structure errors, unknown attributes (with suggestions), duplicate proofs and cycles, and reports its impact |
| `export_rules_docx` | Writes rules to a .docx in OPM styles, ready to paste into a Policy Modeling rule document |

## 5. Rule-authoring workflow

1. Run `search` and `get_attribute` to find the exact existing attribute text, so the new rule doesn't create near-duplicate attributes.
2. Run `get_rule` on the rule you're changing, and `impact_analysis` on its conclusion.
3. Draft the rule as plain text, using 2 spaces per indentation level:
   ```
   the applicant meets the residency requirement if
     either
       the applicant is a citizen or
       both
         the applicant is a permanent resident and
         the applicant's years of residence >= 2
   ```
4. Run `validate_rule_text`, passing `replacing_rule_id` when you're modifying a rule. Repeat until `errors` is empty.
5. Run `export_rules_docx` and paste the result into the rule document in Policy Modeling.
6. Rebuild the graph so it reflects the change.

## Tests

```bash
python sample/make_sample.py && python -m pytest -q tests
```
