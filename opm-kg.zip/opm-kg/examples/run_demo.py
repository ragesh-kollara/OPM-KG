"""Demo: business requirement -> validated, tested rules -> change package, driven through the MCP
server exactly as Claude does it in VS Code.   Run from the project root:  python examples/run_demo.py
Output: output/demo/CR-2027-01.docx, CR-2027-01_rules.docx, CR-2027-01_tests.xlsx"""
import asyncio, json, os, subprocess, sys
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "output", "demo")
GRAPH = os.path.join(OUT, "socialsupport_graph.json")
REQ = """BR-101: The minimum age for social support is raised from 18 to 21. The upper age limit (under 67) is unchanged.
BR-102: Introduce a weekly hardship top-up. Applicants who are eligible for support and whose annual income is below 15,000 receive 60 per week if they have 3 or more children, 40 per week if they have 1 or 2 children, and nothing otherwise.
BR-103: Applicants who are flagged for review must not receive the hardship top-up.
Example: an eligible applicant earning 12,000 with 2 children gets 40. The same applicant with 4 children gets 60. An eligible applicant earning exactly 15,000 gets nothing."""
A, E, F = "the applicant's age", "the applicant is eligible for support", "the applicant is flagged for review"
INC, KIDS, Q = "the applicant's annual income", "the applicant's number of children", "the applicant qualifies for the hardship top-up"
CHANGES = [
 {"change_id": "C1", "requirement_ref": "BR-101", "name": "Age test",
  "replacing_rule_id": "Rules/Eligibility.docx#rule 2|Sub/Eligibility.docx#rule 1",
  "rationale": "Minimum age raised from 18 to 21; the upper limit (under 67) is kept. The age test was proven by two rules "
               "(Rules/Eligibility.docx and Sub/Eligibility.docx, which already used 21 with no upper limit); they are merged into one.",
  "rule_text": f"the applicant meets the age test if\n  {A} >= 21 and\n  {A} < 67",
  "examples": [{"name": "age 20", "inputs": {A: 20}, "expected": False}, {"name": "age 21", "inputs": {A: 21}, "expected": True},
               {"name": "age 66", "inputs": {A: 66}, "expected": True}, {"name": "age 67", "inputs": {A: 67}, "expected": False}]},
 {"change_id": "C2", "requirement_ref": "BR-102, BR-103", "name": "Hardship top-up qualification",
  "rationale": "'Below 15,000' is read as strictly less than 15000. Flagged applicants are excluded (BR-103).",
  "rule_text": f"{Q} if\n  {E} and\n  {INC} < 15000 and\n  the applicant is not flagged for review",
  "examples": [{"name": "typical", "inputs": {E: True, INC: 12000, F: False}, "expected": True},
               {"name": "income exactly 15,000", "inputs": {E: True, INC: 15000, F: False}, "expected": False},
               {"name": "flagged", "inputs": {E: True, INC: 12000, F: True}, "expected": False},
               {"name": "not eligible", "inputs": {E: False, INC: 12000, F: False}, "expected": False}]},
 {"change_id": "C3", "requirement_ref": "BR-102", "name": "Number of children",
  "rationale": "Counts the applicant's children through the existing relationship.",
  "rule_text": f"{KIDS} = InstanceCount(the applicant's children)"},
 {"change_id": "C4", "requirement_ref": "BR-102", "name": "Weekly hardship top-up",
  "rationale": "Most specific band first; 0 when the applicant does not qualify or has no children.",
  "rule_text": (f"the applicant's weekly hardship top-up = 60 if\n  {Q} and\n  {KIDS} >= 3\n"
                f"the applicant's weekly hardship top-up = 40 if\n  {Q} and\n  {KIDS} >= 1\n"
                f"the applicant's weekly hardship top-up = 0 otherwise"),
  "examples": [  # the requirement's own worked examples, checked end-to-end through C2
      {"name": "earning 12,000 with 2 children", "inputs": {E: True, INC: 12000, F: False, KIDS: 2}, "expected": 40},
      {"name": "same applicant with 4 children", "inputs": {E: True, INC: 12000, F: False, KIDS: 4}, "expected": 60},
      {"name": "earning exactly 15,000", "inputs": {E: True, INC: 15000, F: False, KIDS: 2}, "expected": 0},
      {"name": "flagged for review", "inputs": {E: True, INC: 12000, F: True, KIDS: 3}, "expected": 0},
      {"name": "no children", "inputs": {E: True, INC: 12000, F: False, KIDS: 0}, "expected": 0}]},
]
async def call(s, name, args):
    r = await s.call_tool(name, args); return json.loads(r.content[0].text)
async def main():
    os.makedirs(OUT, exist_ok=True)
    sys.path.insert(0, os.path.join(ROOT, "tests", "fixtures"))
    import make_dummy
    subprocess.check_call([sys.executable, "-m", "opm_kg.cli", "build", make_dummy.build(), "-o", GRAPH],
                          cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    p = StdioServerParameters(command=sys.executable, args=[os.path.join(ROOT, "server.py")],
        env={**os.environ, "OPM_KG_GRAPH": GRAPH, "OPM_KG_OUTPUT_DIR": OUT})
    async with stdio_client(p) as (r, w):
        async with ClientSession(r, w) as s:
            await s.initialize()
            others = lambda c: [x["rule_text"] for x in CHANGES if x is not c]
            ctx = await call(s, "analyze_requirement", {"requirement": REQ})
            print("analyze_requirement ->", [r["id"] for r in ctx["relevant_rules"][:4]],
                  "problems:", ctx["existing_problems_in_scope"])
            for c in CHANGES:
                v = await call(s, "validate_rule_text", {"rule_text": c["rule_text"], "replacing_rule_id": c.get("replacing_rule_id"), "other_draft_rules": others(c)})
                print(f"== {c['change_id']} valid={v['valid']} errors={v['errors']} warnings={v['warnings']} info={v['info']}")
                if c.get("examples"):
                    ex = await call(s, "check_rule_examples", {"rule_text": c["rule_text"], "examples": c["examples"], "supporting_rules": others(c)})
                    print(f"   examples {ex['passed']}/{ex['passed']+ex['failed']}", [ (x['example'],x['actual']) for x in ex['results'] if not x['pass']])
                t = await call(s, "generate_test_cases", {"rule_text": c["rule_text"]})
                print(f"   tests {len(t['cases'])} unreachable={t['branches_never_reached']}")
                if v.get("impact"): print("   impact", {k: v2["affected_rules"] for k, v2 in v["impact"].items()})
            pkg = await call(s, "export_change_package", {"title": "CR-2027-01 Age limit and hardship top-up", "requirement": REQ,
                                                          "changes": CHANGES, "file_name": "CR-2027-01", "author": "opm-kg demo"})
            print(json.dumps(pkg, indent=1))
asyncio.run(main())
