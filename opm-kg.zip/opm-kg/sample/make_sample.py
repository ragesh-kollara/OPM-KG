"""Generate a small sample Intelligent Advisor project export (for testing opm-kg)."""
import os
import zipfile

import docx
import openpyxl
from openpyxl.styles import NamedStyle, Font

HERE = os.path.dirname(os.path.abspath(__file__))
from opm_kg.authoring import _ensure_styles  # noqa: E402

ELIGIBILITY = [
    ("heading", "Eligibility"),
    ("rule_name", "Benefit eligibility"),
    ("c", "the applicant is eligible for the housing benefit if"),
    (1, "the applicant meets the age requirement and"),
    (1, "the applicant meets the residency requirement and"),
    (1, "the applicant's total household income < 30000 and"),
    (1, "it is not the case that the applicant is in full-time education"),
    ("c", "the applicant meets the age requirement if"),
    (1, "the applicant's age >= 18"),
    ("c", "the applicant's age = YearDifference(the applicant's date of birth, CurrentDate())"),
    ("c", "the applicant meets the residency requirement if"),
    (1, "either"),
    (2, "the applicant is a citizen or"),
    (2, "both"),
    (3, "the applicant is a permanent resident and"),
    (3, "the applicant's years of residence >= 2"),
    ("heading", "Income"),
    ("c", "the applicant's total household income = the applicant's income + InstanceSum(the applicant's household members, the household member's income)"),
    ("c", "the household member is a dependant if"),
    (1, "the household member's age < 18"),
    ("c", "the number of dependants = InstanceCountIf(the applicant's household members, the household member is a dependant)"),
]

PAYMENT_TABLE_HEADER = ["the weekly benefit amount", "the number of dependants", "the applicant is eligible for the housing benefit"]
PAYMENT_ROWS = [
    [0, None, "false"],
    [150, "0", "true"],
    [220, "1", "true"],
    [290, ">= 2", "true"],
]

DATA_MODEL = """<?xml version="1.0" encoding="utf-8"?>
<data-model>
  <entity name="global">
    <attribute text="the applicant is eligible for the housing benefit" type="boolean" public-name="is_eligible"
               negative-text="the applicant is not eligible for the housing benefit"/>
    <attribute text="the applicant is a citizen" type="boolean" public-name="is_citizen"
               negative-text="the applicant is not a citizen"/>
    <attribute text="the applicant is a permanent resident" type="boolean" public-name="is_pr"/>
    <attribute text="the applicant's date of birth" type="date" public-name="dob"/>
    <attribute text="the applicant's age" type="number" public-name="age"/>
    <attribute text="the applicant's income" type="currency" public-name="income"/>
    <attribute text="the applicant's years of residence" type="number" public-name="years_residence"/>
    <attribute text="the weekly benefit amount" type="currency" public-name="weekly_amount"/>
    <attribute text="the applicant's preferred contact method" type="text" public-name="contact_method"/>
    <relationship text="the applicant's household members" target="household member" type="one-to-many"/>
  </entity>
  <entity name="household member">
    <attribute text="the household member's income" type="currency" public-name="hm_income"/>
    <attribute text="the household member's age" type="number" public-name="hm_age"/>
    <attribute text="the household member is a dependant" type="boolean" public-name="hm_dependant"/>
  </entity>
</data-model>
"""


def make_docx(path):
    d = docx.Document()
    _ensure_styles(d)
    for kind, text in ELIGIBILITY:
        style = {"heading": "OPM - heading 1", "rule_name": "OPM - rule name",
                 "c": "OPM - conclusion"}.get(kind) or f"OPM - level {kind}"
        d.add_paragraph(text, style=style)
    d.save(path)


def make_xlsx(path):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Payment rates"
    ch = NamedStyle(name="OPM - conclusion heading", font=Font(bold=True))
    co = NamedStyle(name="OPM - condition heading", font=Font(bold=True))
    wb.add_named_style(ch)
    wb.add_named_style(co)
    ws.append(PAYMENT_TABLE_HEADER)
    ws["A1"].style = ch
    ws["B1"].style = co
    ws["C1"].style = co
    for r in PAYMENT_ROWS:
        ws.append(r)
    wb.save(path)


if __name__ == "__main__":
    out = os.path.join(HERE, "HousingBenefit")
    os.makedirs(os.path.join(out, "Rules"), exist_ok=True)
    make_docx(os.path.join(out, "Rules", "Eligibility.docx"))
    make_xlsx(os.path.join(out, "Rules", "PaymentRates.xlsx"))
    with open(os.path.join(out, "DataModel.xml"), "w") as fh:
        fh.write(DATA_MODEL)
    zp = os.path.join(HERE, "HousingBenefit.zip")
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as zf:
        for dp, _, fs in os.walk(out):
            for f in fs:
                full = os.path.join(dp, f)
                zf.write(full, os.path.relpath(full, HERE))
    print("wrote", zp)
