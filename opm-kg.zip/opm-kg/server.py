"""FastMCP server exposing the OPM / Intelligent Advisor knowledge graph.

Backend selection (environment variables):
  OPM_KG_BACKEND=neo4j   -> NEO4J_URI, NEO4J_USER, NEO4J_PASSWORD, [NEO4J_DATABASE]
  OPM_KG_BACKEND=json    -> OPM_KG_GRAPH=path/to/graph.json   (default; no database needed)
  OPM_KG_OUTPUT_DIR      -> where export_rules_docx writes files (default ./output)

Run:  python server.py            (stdio transport, for Claude desktop / Claude Code)
"""
from __future__ import annotations

import os
import sys
from typing import Optional

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from mcp.server.fastmcp import FastMCP  # noqa: E402

from opm_kg.authoring import format_rule, rules_to_docx, validate_rule  # noqa: E402

mcp = FastMCP(
    "opm-knowledge-graph",
    instructions=(
        "Knowledge graph of an Oracle Intelligent Advisor (OPM 12.2) rulebase. "
        "Before writing or modifying a rule: search for the attributes involved, reuse existing "
        "attribute text exactly, check who concludes/uses them (get_attribute), check impact "
        "(impact_analysis), then run validate_rule on the draft until it has no errors. "
        "Rule text is plain text with 2-space indentation per level; the conclusion is unindented "
        "and ends in 'if' when it has conditions; conditions end with 'and'/'or'; groups use "
        "'both'/'either'/'all'/'any'."
    ),
)

_store = None


def store():
    global _store
    if _store is None:
        backend = os.environ.get("OPM_KG_BACKEND", "json").lower()
        if backend == "neo4j":
            from opm_kg.neo4j_store import Neo4jStore
            _store = Neo4jStore(os.environ.get("NEO4J_URI", "bolt://localhost:7687"),
                                os.environ.get("NEO4J_USER", "neo4j"),
                                os.environ["NEO4J_PASSWORD"],
                                os.environ.get("NEO4J_DATABASE"))
        else:
            from opm_kg.graph import GraphStore
            _store = GraphStore.from_file(os.environ.get("OPM_KG_GRAPH", "graph.json"))
    return _store


@mcp.tool()
def rulebase_overview() -> dict:
    """Counts of rules, attributes, entities, documents and base (input) attributes."""
    return store().stats()


@mcp.tool()
def search(query: str, kind: str = "all", limit: int = 20) -> list[dict]:
    """Search attributes, rules, entities and documents by keywords.

    kind: all | attribute | rule | entity | document | function
    """
    return store().search(query, kind, limit)


@mcp.tool()
def get_attribute(text: str) -> dict:
    """Full detail on one attribute: entity, type, the rule(s) that prove it and every rule that
    uses it. Accepts positive or negative text ("the applicant is not a resident")."""
    return store().get_attribute(text)


@mcp.tool()
def get_rule(rule_id: str) -> dict:
    """Full rule text plus the attributes it concludes and uses. rule_id may be a partial id."""
    return store().get_rule(rule_id)


@mcp.tool()
def trace_dependencies(attribute: str, depth: int = 10) -> dict:
    """Upstream lineage: everything the attribute is derived from, down to base inputs."""
    return store().upstream(attribute, depth)


@mcp.tool()
def impact_analysis(attribute: str, depth: int = 10) -> dict:
    """Downstream impact: attributes and rules affected if this attribute or its rule changes."""
    return store().downstream(attribute, depth)


@mcp.tool()
def list_rules_in_document(document: str) -> list[dict]:
    """Rules in a Word / Excel rule document (partial file name match)."""
    return store().rules_in_document(document)


@mcp.tool()
def list_entities() -> list[dict]:
    """Entities in the data model with attribute counts."""
    return store().list_entities()


@mcp.tool()
def get_entity(name: str) -> dict:
    """Attributes and relationships of one entity."""
    return store().entity(name)


@mcp.tool()
def list_base_attributes(limit: int = 200) -> list[dict]:
    """Attributes used by rules but never concluded (collected on screens or mapped in)."""
    return store().base_attributes(limit)


@mcp.tool()
def rulebase_diagnostics() -> dict:
    """Attributes proven by more than one rule, dependency cycles, unused and undeclared attributes."""
    return store().diagnostics()


@mcp.tool()
def validate_rule_text(rule_text: str, replacing_rule_id: Optional[str] = None) -> dict:
    """Validate a new or modified rule against the rulebase before it is written.

    Checks structure (if / and / or / groups), unknown attributes (with suggestions), attributes
    already proven elsewhere, circular dependencies, and reports downstream impact.
    Pass replacing_rule_id when modifying an existing rule so it is not flagged as a duplicate.
    """
    return validate_rule(store(), rule_text, replacing_rule_id)


@mcp.tool()
def export_rules_docx(rules: list[dict], file_name: str = "new_rules.docx",
                      title: Optional[str] = None) -> dict:
    """Write rules to a Word document with the 'OPM - conclusion' / 'OPM - level N' styles so they
    can be pasted into a Policy Modeling rule document.

    rules: [{"text": "<indented rule text>", "name": "<optional rule name>", "comment": "<optional>"}]
    """
    out_dir = os.environ.get("OPM_KG_OUTPUT_DIR", os.path.join(os.getcwd(), "output"))
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, os.path.basename(file_name))
    for r in rules:
        r["text"] = format_rule(r["text"])
    rules_to_docx(rules, path, title)
    return {"written": path, "rules": len(rules)}


if __name__ == "__main__":
    mcp.run()
