"""FastMCP server exposing the OPM / Intelligent Advisor knowledge graph.

Backend selection (environment variables):
  OPM_KG_BACKEND=neo4j   -> NEO4J_URI, NEO4J_USER, NEO4J_PASSWORD, [NEO4J_DATABASE]
  OPM_KG_BACKEND=json    -> OPM_KG_GRAPH=path/to/graph.json   (default; no database needed)
  OPM_KG_OUTPUT_DIR      -> where export_rules_docx writes files (default ./output)

Run:  python server.py            (stdio transport, for Claude desktop / Claude Code)
"""
from __future__ import annotations

import functools
import os
import sys
from typing import Optional

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from mcp.server.fastmcp import FastMCP  # noqa: E402

from opm_kg.authoring import format_rule, rules_to_docx, validate_rule  # noqa: E402
from opm_kg.evaluator import evaluate_rule as _evaluate_rule  # noqa: E402
from opm_kg.guide import AUTHORING_GUIDE, WORKFLOW_PROMPT  # noqa: E402
from opm_kg.package import export_change_package as _export_package  # noqa: E402
from opm_kg.requirements import check_examples, generate_test_cases as _gen_tests  # noqa: E402
from opm_kg.requirements import requirement_context  # noqa: E402

mcp = FastMCP(
    "opm-knowledge-graph",
    instructions=(
        "Knowledge graph of an Oracle Intelligent Advisor (OPM 12.2) rulebase. "
        "To turn a business requirement into rules use the 'rules_from_requirement' prompt or start "
        "with analyze_requirement; the authoring guide is resource opm://authoring-guide. "
        "Before writing or modifying a rule: search for the attributes involved, reuse existing "
        "attribute text exactly, check who concludes/uses them (get_attribute), check impact "
        "(impact_analysis), then run validate_rule on the draft until it has no errors. "
        "Rule text is plain text with 2-space indentation per level; the conclusion is unindented "
        "and ends in 'if' when it has conditions; conditions end with 'and'/'or'; groups use "
        "'both'/'either'/'all'/'any'."
    ),
)

_store = None


class ConfigError(RuntimeError):
    pass


def store():
    global _store
    if _store is None:
        backend = os.environ.get("OPM_KG_BACKEND", "json").lower()
        if backend == "neo4j":
            try:
                from opm_kg.neo4j_store import Neo4jStore
            except ImportError as e:
                raise ConfigError("OPM_KG_BACKEND=neo4j but the 'neo4j' Python package is not "
                                  "installed (pip install neo4j)") from e
            if not os.environ.get("NEO4J_PASSWORD"):
                raise ConfigError("NEO4J_PASSWORD is not set")
            st = Neo4jStore(os.environ.get("NEO4J_URI", "bolt://localhost:7687"),
                            os.environ.get("NEO4J_USER", "neo4j"),
                            os.environ["NEO4J_PASSWORD"],
                            os.environ.get("NEO4J_DATABASE"))
            try:
                st.driver.verify_connectivity()
            except Exception as e:
                raise ConfigError(f"cannot connect to Neo4j at {os.environ.get('NEO4J_URI')}: {e}") from e
            _store = st
        elif backend == "json":
            from opm_kg.graph import GraphStore
            path = os.environ.get("OPM_KG_GRAPH", "graph.json")
            if not os.path.exists(path):
                raise ConfigError(f"graph file not found: {os.path.abspath(path)} - build it with "
                                  f"`python -m opm_kg.cli build <export.zip> -o graph.json` or set "
                                  f"OPM_KG_GRAPH")
            _store = GraphStore.from_file(path)
        else:
            raise ConfigError(f"unknown OPM_KG_BACKEND '{backend}' (use 'json' or 'neo4j')")
    return _store


def safe(fn):
    """Return errors to the model as data instead of failing the tool call."""
    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except ConfigError as e:
            return {"error": str(e), "kind": "configuration"}
        except Exception as e:  # pragma: no cover - defensive
            return {"error": f"{type(e).__name__}: {e}", "kind": "internal"}
    return wrapper


@mcp.tool()
@safe
def rulebase_overview() -> dict:
    """Counts of rules, attributes, entities, documents and base (input) attributes."""
    return store().stats()


@mcp.tool()
@safe
def search(query: str, kind: str = "all", limit: int = 20) -> list[dict]:
    """Search attributes, rules, entities and documents by keywords.

    kind: all | attribute | rule | entity | document | function
    """
    kinds = ("all", "attribute", "rule", "entity", "document", "function")
    if kind.lower() not in kinds:
        return [{"error": f"kind must be one of {kinds}"}]
    return store().search(query, kind.lower(), max(1, min(int(limit), 200)))


@mcp.tool()
@safe
def get_attribute(text: str) -> dict:
    """Full detail on one attribute: entity, type, the rule(s) that prove it and every rule that
    uses it. Accepts positive or negative text ("the applicant is not a resident")."""
    return store().get_attribute(text)


@mcp.tool()
@safe
def get_rule(rule_id: str) -> dict:
    """Full rule text plus the attributes it concludes and uses. rule_id may be a partial id."""
    return store().get_rule(rule_id)


@mcp.tool()
@safe
def trace_dependencies(attribute: str, depth: int = 10) -> dict:
    """Upstream lineage: everything the attribute is derived from, down to base inputs."""
    return store().upstream(attribute, depth)


@mcp.tool()
@safe
def impact_analysis(attribute: str, depth: int = 10) -> dict:
    """Downstream impact: attributes and rules affected if this attribute or its rule changes."""
    return store().downstream(attribute, depth)


@mcp.tool()
@safe
def list_rules_in_document(document: str) -> list[dict]:
    """Rules in a Word / Excel rule document (partial file name match)."""
    return store().rules_in_document(document)


@mcp.tool()
@safe
def list_entities() -> list[dict]:
    """Entities in the data model with attribute counts."""
    return store().list_entities()


@mcp.tool()
@safe
def get_entity(name: str) -> dict:
    """Attributes and relationships of one entity."""
    return store().entity(name)


@mcp.tool()
@safe
def list_base_attributes(limit: int = 200) -> list[dict]:
    """Attributes used by rules but never concluded (collected on screens or mapped in)."""
    return store().base_attributes(limit)


@mcp.tool()
@safe
def rulebase_diagnostics() -> dict:
    """Attributes proven by more than one rule, dependency cycles, unused and undeclared attributes."""
    return store().diagnostics()


@mcp.tool()
@safe
def validate_rule_text(rule_text: str, replacing_rule_id: Optional[str] = None,
                       other_draft_rules: Optional[list[str]] = None) -> dict:
    """Validate a new or modified rule against the rulebase before it is written.

    Checks structure (if / and / or / groups), unknown attributes (with suggestions), attributes
    already proven elsewhere, circular dependencies, and reports downstream impact.
    Pass replacing_rule_id when modifying an existing rule so it is not flagged as a duplicate.
    To merge several rules that prove the same attribute, separate their ids with '|'.
    other_draft_rules: the other new rules you are writing for the same requirement, so attributes
    they define are not reported as unknown and cycles across drafts are caught.
    """
    return validate_rule(store(), rule_text, replacing_rule_id, other_draft_rules)


@mcp.tool()
@safe
def export_rules_docx(rules: list[dict], file_name: str = "new_rules.docx",
                      title: Optional[str] = None) -> dict:
    """Write rules to a Word document with the 'OPM - conclusion' / 'OPM - level N' styles so they
    can be pasted into a Policy Modeling rule document.

    rules: [{"text": "<indented rule text>", "name": "<optional rule name>", "comment": "<optional>"}]
    """
    if not rules or not all(isinstance(r, dict) and r.get("text", "").strip() for r in rules):
        return {"error": "rules must be a non-empty list of {\"text\": ...} objects"}
    out_dir = _out_dir()
    name = os.path.basename(file_name).strip() or "new_rules.docx"
    if not name.lower().endswith(".docx"):
        name += ".docx"
    path = os.path.join(out_dir, name)
    rules = [dict(r, text=format_rule(r["text"])) for r in rules]
    rules_to_docx(rules, path, title)
    return {"written": path, "rules": len(rules)}


def _out_dir():
    d = os.environ.get("OPM_KG_OUTPUT_DIR", os.path.join(os.getcwd(), "output"))
    os.makedirs(d, exist_ok=True)
    return d


@mcp.tool()
@safe
def analyze_requirement(requirement: str) -> dict:
    """Step 1 of rule generation. Given a business requirement, return the existing attributes and
    rules it touches (with full rule text), thresholds from the requirement found in current
    rules, detected intent (add / modify / remove), known problems in scope, and phrasing examples."""
    return requirement_context(store(), requirement)


@mcp.tool()
@safe
def evaluate_rule(rule_text: str, facts: dict, use_rulebase: bool = False,
                  today: Optional[str] = None, supporting_rules: Optional[list[str]] = None) -> dict:
    """Run a rule on test facts ({attribute text: value}; dates as YYYY-MM-DD; missing = unknown).
    supporting_rules: other draft rules used to infer missing attributes (checked first);
    use_rulebase=True also infers them from the rulebase's existing rules."""
    return _evaluate_rule(rule_text, facts, store() if use_rulebase else None, today, supporting_rules)


@mcp.tool()
@safe
def check_rule_examples(rule_text: str, examples: list[dict], use_rulebase: bool = False,
                        today: Optional[str] = None, supporting_rules: Optional[list[str]] = None) -> dict:
    """Check a draft rule against worked examples from the requirement.
    examples: [{"name": "...", "inputs": {attribute: value}, "expected": value}]
    supporting_rules: the other draft rules, so end-to-end examples ("earning 12,000 with 2 children
    gets 40") can be checked through the whole new chain."""
    return check_examples(rule_text, examples, store() if use_rulebase else None, today, supporting_rules)


@mcp.tool()
@safe
def generate_test_cases(rule_text: str, max_cases: int = 32, fixed_inputs: Optional[dict] = None,
                        today: Optional[str] = None) -> dict:
    """Boundary-value / combination scenarios for a rule with expected outcomes, plus any conclusion
    branches that no scenario reaches (a sign of overlapping or contradictory conditions)."""
    return _gen_tests(rule_text, max(1, min(int(max_cases), 256)), fixed=fixed_inputs, today=today)


@mcp.tool()
@safe
def export_change_package(title: str, requirement: str, changes: list[dict],
                          file_name: Optional[str] = None, author: Optional[str] = None) -> dict:
    """Final step of rule generation. Validates, tests and writes three files:
    <name>.docx (review document), <name>_rules.docx (OPM-styled rules to paste into Policy
    Modeling) and <name>_tests.xlsx (test scenarios).
    changes: [{"rule_text", "name", "change_id", "requirement_ref", "rationale",
               "replacing_rule_id" (id, or ids separated by '|', or a list),
               "examples": [{"name", "inputs", "expected"}]}]"""
    if not changes or not all(isinstance(c, dict) and c.get("rule_text", "").strip() for c in changes):
        return {"error": "changes must be a non-empty list of objects with rule_text"}
    return _export_package(store(), title, requirement, changes, _out_dir(), file_name, author)


@mcp.resource("opm://authoring-guide")
def authoring_guide() -> str:
    """Rule syntax, naming conventions and the requirement-to-rules workflow."""
    return AUTHORING_GUIDE


@mcp.prompt()
def rules_from_requirement(requirement: str) -> str:
    """Generate or modify Intelligent Advisor rules from a business requirement, validated, tested
    against examples and exported as a change package."""
    return WORKFLOW_PROMPT.format(requirement=requirement) + "\n\n" + AUTHORING_GUIDE


@mcp.tool()
@safe
def reload_graph() -> dict:
    """Reload the knowledge graph after it has been rebuilt (json) or reloaded into Neo4j."""
    global _store
    _store = None
    return {"reloaded": True, **store().stats()}


if __name__ == "__main__":
    mcp.run()
