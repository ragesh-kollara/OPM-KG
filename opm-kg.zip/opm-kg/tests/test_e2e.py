"""End-to-end tests on the sample Housing Benefit project.  Run: python -m pytest -q tests"""
import json
import os
import subprocess
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from opm_kg.authoring import rules_to_docx, validate_rule  # noqa: E402
from opm_kg.graph import GraphStore, build_graph, graph_from_json, graph_to_json  # noqa: E402
from opm_kg.parsers import load_rulebase  # noqa: E402

SAMPLE = os.path.join(ROOT, "sample", "HousingBenefit.zip")


@pytest.fixture(scope="module")
def store():
    if not os.path.exists(SAMPLE):
        subprocess.check_call([sys.executable, os.path.join(ROOT, "sample", "make_sample.py")],
                              env={**os.environ, "PYTHONPATH": ROOT})
    g = build_graph(load_rulebase(SAMPLE))
    return GraphStore(graph_from_json(json.loads(json.dumps(graph_to_json(g)))))


def test_stats(store):
    st = store.stats()
    assert st["Rule"] == 8 and st["Entity"] == 2


def test_search(store):
    r = store.search("household income")
    assert r[0]["type"] == "Attribute" and "household income" in r[0]["text"]


def test_negative_form_resolves(store):
    a = store.get_attribute("the applicant is not a citizen")
    assert a["found"] and a["text"] == "the applicant is a citizen"


def test_attribute_links(store):
    a = store.get_attribute("the number of dependants")
    assert [r["id"] for r in a["concluded_by"]] == ["Eligibility.docx#rule 7"]
    assert any("PaymentRates" in r["id"] for r in a["used_by"])


def test_upstream(store):
    up = store.upstream("the weekly benefit amount")
    assert "the applicant's date of birth" in up["base_inputs"]
    assert "the household member's age" in up["base_inputs"]


def test_downstream(store):
    d = store.downstream("the household member's age")
    names = [x["attribute"] for x in d["affected_attributes"]]
    assert "the weekly benefit amount" in names


def test_diagnostics(store):
    d = store.diagnostics()
    assert d["dependency_cycles"] == []
    assert "the applicant's preferred contact method" in d["defined_but_unused_attributes"]
    assert "the applicant is in full-time education" in d["attributes_not_in_data_model"]


def test_validate_good_new_rule(store):
    v = validate_rule(store, """the applicant qualifies for the rent supplement if
  the applicant is eligible for the housing benefit and
  the weekly benefit amount < 200""")
    assert v["valid"], v["errors"]
    assert all(c["exists"] for c in v["conditions"])


def test_validate_catches_duplicate_conclusion(store):
    v = validate_rule(store, """the applicant meets the age requirement if
  the applicant's age >= 21""")
    assert not v["valid"] and "already proven" in v["errors"][0]
    v2 = validate_rule(store, """the applicant meets the age requirement if
  the applicant's age >= 21""", replacing_rule_id="Eligibility.docx#rule 2")
    assert v2["valid"]
    assert "the applicant is eligible for the housing benefit" in \
        v2["impact"]["the applicant meets the age requirement"]["affected_attributes"]


def test_validate_catches_cycle_and_typos(store):
    v = validate_rule(store, """the applicant's date of birth = Date(2000, 1, 1) if
  the applicant is eligble for the housing benefit""")
    assert any("did you mean" in w for w in v["warnings"])
    v = validate_rule(store, """the household member is not a dependant if
  the weekly benefit amount > 100""", replacing_rule_id="Eligibility.docx#rule 6")
    assert any("circular" in e for e in v["errors"])


def test_validate_structure(store):
    v = validate_rule(store, """the applicant is ok
  the applicant is a citizen
  the applicant is a permanent resident and
  the applicant's age > 1 or
  the applicant's income > 2""")
    errs = " ".join(v["errors"])
    assert "does not end with 'if'" in errs and "without 'and'/'or'" in errs and "mixes" in errs


def test_docx_roundtrip(tmp_path, store):
    p = str(tmp_path / "new.docx")
    rules_to_docx([{"name": "Rent supplement", "text": """the applicant qualifies for the rent supplement if
  either
    the applicant is a citizen or
    the applicant is a permanent resident"""}], p)
    rb = load_rulebase(p)
    assert rb.rules[0].name == "Rent supplement"
    assert {r.text for r in rb.rules[0].refs if r.role == "condition"} == \
        {"the applicant is a citizen", "the applicant is a permanent resident"}
