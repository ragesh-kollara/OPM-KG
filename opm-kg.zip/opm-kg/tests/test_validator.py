"""Validator tests: structure, data-model types, duplicates, cycles, suggestions, round trip."""
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "tests"))

from opm_kg.authoring import check_structure, format_rule, rules_to_docx, validate_rule  # noqa: E402
from opm_kg.parsers import load_rulebase  # noqa: E402
from opm_kg.rule_text import parse_indented  # noqa: E402
from test_accuracy import store as dummy_store  # noqa: E402


def S(text):
    return check_structure(parse_indented(text))


def test_structure_valid_shapes():
    for text in [
        "x if\n  a and\n  b",
        "x if\n  a and\n  either\n    b or\n    c and\n  d",
        "x if\n  either\n    both\n      a and\n      b or\n    c",
        "the r = 1 if\n  a\nthe r = 2 if\n  b\nthe r = 0 otherwise",
        "the r = the a + the b",
        "x if\n    a and\n    b",            # 4-space indentation
        "x if\n\ta or\n\tb",                  # tabs
    ]:
        assert S(text) == ([], []), (text, S(text))


def test_structure_errors():
    cases = {
        "x if\n  a\n  b": "missing 'and' / 'or'",
        "x if\n  either\n    a or\n    b\n  c": "missing 'and' / 'or' before line 5",
        "x if\n  a and\n  b or\n  c": "mixes 'and' and 'or'",
        "x\n  a": "does not end with 'if'",
        "x if": "ends with 'if' but has no conditions",
        "x if\n  a and\n    b": "is not a group",
        "x if\n  either\n      a or\n      b": "one level at a time",
        "x if\n  either": "has no indented conditions",
        "the r = 0 otherwise": "must follow at least one",
        "the r = 0 otherwise\nthe r = 1 if\n  a": "must follow at least one",
        "x if\n  a\ny if\n  b": "separate rules",
        "  x if\n  a": "has no conditions",   # indentation is relative, so both lines are conclusions
    }
    for text, expect in cases.items():
        errs, _ = S(text)
        assert any(expect in e for e in errs), (text, errs)


def test_structure_warnings():
    _, w = S("x if\n  both\n    a or\n    b")
    assert any("did you mean 'either'" in x for x in w)
    _, w = S("x if\n  a and")
    assert any("trailing" in x for x in w)


def test_type_checks_against_data_model():
    _, s = dummy_store()
    v = validate_rule(s, "the applicant is a citizen = 5")
    assert any("boolean attribute but the rule assigns" in e for e in v["errors"])
    v = validate_rule(s, "the partner's income if\n  the applicant has a partner")
    assert any("needs '= <value>'" in e for e in v["errors"])
    v = validate_rule(s, "the applicant qualifies if\n  the applicant is a citizen > 3")
    assert any("compared with" in e for e in v["errors"])
    v = validate_rule(s, "the applicant qualifies if\n  the partner's income")
    assert any("used as a true/false condition" in e for e in v["errors"])


def test_new_rule_with_existing_attributes_is_valid():
    _, s = dummy_store()
    v = validate_rule(s, """the applicant qualifies for a top-up if
  the applicant is eligible for support and
  either
    the applicant is single or
    the partner's income < 5000 and
  the weekly payment > 0""")
    assert v["valid"], v["errors"]
    assert not v["warnings"], v["warnings"]


def test_duplicate_and_replacement():
    _, s = dummy_store()
    v = validate_rule(s, "the child is immunised if\n  the child has a medical exemption")
    assert not v["valid"] and any("already proven" in e for e in v["errors"])
    v = validate_rule(s, "the child is immunised if\n  the child has a medical exemption",
                      replacing_rule_id="Rules/Eligibility.docx#rule 7")
    assert v["valid"], v["errors"]
    impact = v["impact"]["the child is immunised"]["affected_attributes"]
    assert "the applicant is eligible for support" in impact


def test_cycle_detected_through_negative_form():
    _, s = dummy_store()
    v = validate_rule(s, "the applicant is not a citizen if\n  the weekly payment > 100")
    assert any("circular" in e for e in v["errors"]), v["errors"]


def test_unknown_attribute_suggestion():
    _, s = dummy_store()
    v = validate_rule(s, "the applicant qualifies if\n  the applicant is elegible for support")
    assert any("did you mean 'the applicant is eligible for support'" in w for w in v["warnings"])


def test_unknown_function_warning():
    _, s = dummy_store()
    v = validate_rule(s, "the x = YearDiff(the applicant's date of birth, the assessment date)")
    assert any("YearDiff" in w for w in v["warnings"])


def test_docx_round_trip_preserves_structure(tmp_path):
    text = """the applicant qualifies for a top-up if
  the applicant is eligible for support and
  either
    the applicant is single or
    the partner's income < 5000"""
    p = str(tmp_path / "out.docx")
    rules_to_docx([{"name": "Top-up", "text": text}], p)
    rb = load_rulebase(p)
    assert len(rb.rules) == 1
    assert format_rule(rb.rules[0].text) == format_rule(text)
    assert rb.rules[0].name == "Top-up"
