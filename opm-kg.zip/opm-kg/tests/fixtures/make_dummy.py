"""Build a deliberately awkward dummy Intelligent Advisor export for accuracy testing.

Output: tests/fixtures/SocialSupport.zip
Ground truth lives in tests/test_accuracy.py.
"""
import io
import os
import sys
import zipfile

import docx
import openpyxl
from openpyxl.styles import Font, NamedStyle

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(HERE)))
from opm_kg.authoring import _ensure_styles  # noqa: E402

A = "’"  # curly apostrophe, as Word autocorrects it


def _doc_with_styles(capitalised=True):
    d = docx.Document()
    _ensure_styles(d)
    if capitalised:  # Policy Modeling templates capitalise some style names
        for st in d.styles:
            if st.name.startswith("OPM - level"):
                st.name = st.name.replace("level", "Level")
            if st.name == "OPM - conclusion":
                st.name = "OPM - Conclusion"
    return d


def _p(d, text, style):
    d.add_paragraph(text, style=style)


def eligibility_docx() -> bytes:
    d = _doc_with_styles()
    C, L1, L2, L3 = "OPM - Conclusion", "OPM - Level 1", "OPM - Level 2", "OPM - Level 3"
    d.add_paragraph("Social support eligibility rules", style="Title")
    # a non-rule table (version history) - must be ignored
    t = d.add_table(rows=3, cols=3)
    for r, row in enumerate([["Version", "Date", "Author"], ["1.0", "2026-01-01", "RK"], ["1.1", "2026-03-01", "RK"]]):
        for c, v in enumerate(row):
            t.cell(r, c).text = v
    d.add_paragraph("Eligibility", style="Heading 1")
    d.add_paragraph("This section explains who can get support.", style="Normal")
    _p(d, "Overall eligibility", "OPM - rule name")
    _p(d, "the applicant is eligible for support if", C)
    _p(d, "the applicant meets the age test and", L1)
    _p(d, f"the applicant{A}s annual income <= the income threshold and", L1)
    _p(d, f"ForAll(the applicant{A}s children, the child is immunised) and", L1)
    _p(d, "either", L1)
    _p(d, "the applicant is a citizen or", L2)
    _p(d, "it is not the case that the applicant is a temporary visa holder", L2)
    d.add_paragraph("", style="Normal")
    _p(d, "the applicant meets the age test if", C)
    _p(d, "the applicant's age >= 18 and", L1)
    _p(d, "the applicant's age < 67", L1)
    _p(d, "the applicant's age = YearDifference(the applicant's date of birth, the assessment date)", C)
    _p(d, "the income threshold = 25000 + 5000 * InstanceCount(the applicant's children)", C)
    # Word rule table (cells use OPM styles)
    d.add_paragraph("Rates", style="Heading 1")
    t = d.add_table(rows=4, cols=2)
    rows = [("the support rate", ""), ("150", ["the applicant is single"]),
            ("250", ["the applicant has a partner and", "the partner's income < 10000"]),
            ("100", ["otherwise"])]
    for r, (concl, conds) in enumerate(rows):
        t.cell(r, 0).paragraphs[0].text = concl
        t.cell(r, 0).paragraphs[0].style = d.styles[C]
        if conds:
            t.cell(r, 1).paragraphs[0].text = conds[0]
            t.cell(r, 1).paragraphs[0].style = d.styles[L1]
            for extra in conds[1:]:
                t.cell(r, 1).add_paragraph(extra, style=L1)
    _p(d, "the applicant is flagged for review if", C)
    _p(d, "the applicant is not a citizen and", L1)
    _p(d, "the applicant's annual income is unknown", L1)
    d.add_paragraph("Children", style="Heading 1")
    _p(d, "the child is immunised if", C)
    _p(d, 'the child\'s vaccination status = "complete" or', L1)
    _p(d, "the child has a medical exemption", L1)
    _p(d, "the child's care allowance = 50 if", C)
    _p(d, "the child's age < 5", L1)
    _p(d, "the child's care allowance = 0 otherwise", C)
    _p(d, "the child's age = YearDifference(the child's date of birth, the assessment date)", C)
    b = io.BytesIO()
    d.save(b)
    return b.getvalue()


def sub_eligibility_docx() -> bytes:
    """Same file name in another folder: duplicate proof + a dependency cycle."""
    d = _doc_with_styles(capitalised=False)
    _p(d, "the applicant meets the age test if", "OPM - conclusion")
    _p(d, "the applicant's age >= 21", "OPM - level 1")
    _p(d, "the applicant's annual income = the applicant's declared income if", "OPM - conclusion")
    _p(d, "the applicant is eligible for support", "OPM - level 1")
    b = io.BytesIO()
    d.save(b)
    return b.getvalue()


def extra_docx() -> bytes:
    d = _doc_with_styles(capitalised=False)
    _p(d, "the applicant is a veteran if", "OPM - conclusion")
    _p(d, "the applicant has a service record", "OPM - level 1")
    b = io.BytesIO()
    d.save(b)
    return b.getvalue()


def payments_xlsx() -> bytes:
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Rates"
    ch = NamedStyle(name="OPM - conclusion heading", font=Font(bold=True))
    co = NamedStyle(name="OPM - condition heading", font=Font(bold=True))
    wb.add_named_style(ch)
    wb.add_named_style(co)
    ws.append(["Payment rates"])                                    # title row
    ws.append(["the weekly payment", "the payment frequency",
               "the applicant is eligible for support", "the support rate"])
    for c in "AB":
        ws[f"{c}2"].style = ch
    for c in "CD":
        ws[f"{c}2"].style = co
    ws.append([0, '"none"', "false", None])
    ws.append([120, '"weekly"', "true", "=150"])
    ws.append([200, '"fortnightly"', "true", ">=250"])
    ws.append([90, '"weekly"', "otherwise", None])
    ws["D4"].data_type = "s"  # keep "=150" as text, not an Excel formula
    notes = wb.create_sheet("Notes")
    for line in ["Rates reviewed annually.", "Contact: policy team"]:
        notes.append([line])
    bonus = wb.create_sheet("Bonus")                                # no OPM styles
    bonus.append(["the bonus amount", "the applicant's age"])
    bonus.append([100, "< 25"])
    bonus.append([0, "otherwise"])
    b = io.BytesIO()
    wb.save(b)
    return b.getvalue()


DATA_MODEL = """<?xml version="1.0" encoding="utf-8"?>
<model xmlns="http://example.com/opa/datamodel">
  <entities>
    <entity name="global">
      <attribute><text>the applicant is eligible for support</text><type>boolean</type><public-name>eligible</public-name></attribute>
      <attribute text="the applicant is a citizen" type="boolean" public-name="citizen" negative-text="the applicant is not a citizen"/>
      <attribute text="the applicant is a temporary visa holder" type="boolean" public-name="tvh"/>
      <attribute text="the applicant&#8217;s annual income" type="currency" public-name="annual_income"/>
      <attribute text="the applicant's date of birth" type="date" public-name="dob"/>
      <attribute text="the assessment date" type="date" public-name="assess_date"/>
      <attribute text="the applicant is single" type="boolean"/>
      <attribute text="the applicant has a partner" type="boolean"/>
      <attribute text="the partner's income" type="currency"/>
      <attribute text="the applicant's marital status" type="text" public-name="marital"/>
      <relationship text="the applicant's children" target="child" type="one-to-many"/>
    </entity>
    <entity name="child">
      <attribute text="the child's date of birth" type="date"/>
      <attribute text="the child's vaccination status" type="text"/>
      <attribute text="the child has a medical exemption" type="boolean"/>
    </entity>
  </entities>
</model>
"""


def build(path=os.path.join(HERE, "SocialSupport.zip")):
    inner = io.BytesIO()
    with zipfile.ZipFile(inner, "w") as z:
        z.writestr("Extra.docx", extra_docx())
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("SocialSupport/Rules/Eligibility.docx", eligibility_docx())
        z.writestr("SocialSupport/Rules/Sub/Eligibility.docx", sub_eligibility_docx())
        z.writestr("SocialSupport/Rules/Payments.xlsx", payments_xlsx())
        z.writestr("SocialSupport/Rules/~$Eligibility.docx", b"lock file garbage")
        z.writestr("SocialSupport/Rules/Broken.docx", b"this is not a zip")
        z.writestr("SocialSupport/README.txt", "Project notes - not rules.\n\nDo not parse me.")
        z.writestr("SocialSupport/DataModel.xml", DATA_MODEL)
        z.writestr("SocialSupport/Legacy/old_rules.zip", inner.getvalue())
    return path


if __name__ == "__main__":
    print(build())
