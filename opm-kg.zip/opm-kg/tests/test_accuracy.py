"""Accuracy tests: parse the awkward SocialSupport dummy export and compare every rule with
hand-written ground truth."""
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "tests", "fixtures"))

import make_dummy  # noqa: E402
from opm_kg.graph import GraphStore, build_graph, graph_from_json, graph_to_json  # noqa: E402
from opm_kg.model import norm  # noqa: E402
from opm_kg.parsers import load_rulebase  # noqa: E402

A = "the applicant"
# conclusion -> (set of (used attribute, negated)), set of relationships
TRUTH = {
    "Rules/Eligibility.docx#rule 1": ("the applicant is eligible for support", {
        (f"{A} meets the age test", False), (f"{A}'s annual income", False),
        ("the income threshold", False), ("the child is immunised", False),
        (f"{A} is a citizen", False), (f"{A} is a temporary visa holder", True)},
        {f"{A}'s children"}),
    "Rules/Eligibility.docx#rule 2": (f"{A} meets the age test", {(f"{A}'s age", False)}, set()),
    "Rules/Eligibility.docx#rule 3": (f"{A}'s age", {(f"{A}'s date of birth", False),
                                                      ("the assessment date", False)}, set()),
    "Rules/Eligibility.docx#rule 4": ("the income threshold", set(), {f"{A}'s children"}),
    "Rules/Eligibility.docx#table 5": ("the support rate", {
        (f"{A} is single", False), (f"{A} has a partner", False), ("the partner's income", False)}, set()),
    "Rules/Eligibility.docx#rule 6": (f"{A} is flagged for review", {
        (f"{A} is a citizen", True), (f"{A}'s annual income", False)}, set()),
    "Rules/Eligibility.docx#rule 7": ("the child is immunised", {
        ("the child's vaccination status", False), ("the child has a medical exemption", False)}, set()),
    "Rules/Eligibility.docx#rule 8": ("the child's care allowance", {("the child's age", False)}, set()),
    "Rules/Eligibility.docx#rule 9": ("the child's age", {("the child's date of birth", False),
                                                          ("the assessment date", False)}, set()),
    "Sub/Eligibility.docx#rule 1": (f"{A} meets the age test", {(f"{A}'s age", False)}, set()),
    "Sub/Eligibility.docx#rule 2": (f"{A}'s annual income", {
        (f"{A}'s declared income", False), (f"{A} is eligible for support", False)}, set()),
    "Payments.xlsx#sheet 'Rates' col 1": ("the weekly payment", {
        (f"{A} is eligible for support", True), (f"{A} is eligible for support", False),
        ("the support rate", False)}, set()),
    "Payments.xlsx#sheet 'Rates' col 2": ("the payment frequency", {
        (f"{A} is eligible for support", True), (f"{A} is eligible for support", False),
        ("the support rate", False)}, set()),
    "Payments.xlsx#sheet 'Bonus' col 1": ("the bonus amount", {(f"{A}'s age", False)}, set()),
    "Extra.docx#rule 1": (f"{A} is a veteran", {(f"{A} has a service record", False)}, set()),
}

EXPECTED_TYPES = {
    f"{A} meets the age test": "boolean", f"{A}'s age": "number", "the income threshold": "number",
    "the support rate": "number", "the payment frequency": "text", "the child's age": "number",
    f"{A}'s declared income": "value", f"{A} has a service record": "boolean",
    f"{A}'s annual income": "currency",  # from data model (curly apostrophe there)
}

_store = None


def store():
    global _store
    if _store is None:
        path = make_dummy.build()
        rb = load_rulebase(path)
        g = build_graph(rb)
        _store = (rb, GraphStore(graph_from_json(json.loads(json.dumps(graph_to_json(g))))))
    return _store


def test_rule_set_exact():
    rb, s = store()
    got = sorted(r.id for r in rb.rules)
    assert got == sorted(TRUTH), f"\nextra: {set(got) - set(TRUTH)}\nmissing: {set(TRUTH) - set(got)}"


def test_every_rule_matches_ground_truth():
    _, s = store()
    problems = []
    for rid, (concl, uses, rels) in TRUTH.items():
        r = s.get_rule(rid)
        if not r["found"]:
            problems.append(f"{rid}: not found")
            continue
        if [norm(c) for c in r["concludes"]] != [norm(concl)]:
            problems.append(f"{rid}: concludes {r['concludes']} expected {concl}")
        got = {(norm(u["attribute"]), bool(u["negated"])) for u in r["uses"]}
        exp = {(norm(a), n) for a, n in uses}
        if got != exp:
            problems.append(f"{rid}: uses\n   extra   {got - exp}\n   missing {exp - got}")
        if {norm(x) for x in r["relationships"]} != {norm(x) for x in rels}:
            problems.append(f"{rid}: relationships {r['relationships']} expected {rels}")
    assert not problems, "\n".join(problems)


def test_ignored_files_and_tables():
    rb, s = store()
    texts = {norm(a.text) for a in rb.attributes.values()}
    for junk in ("version", "2026-01-01 rk", "project notes - not rules", "do not parse me"):
        assert junk not in texts, junk
    assert any("Broken.docx" in w for w in rb.warnings)
    assert not any("~$" in d for d in rb.documents)


def test_types():
    rb, _ = store()
    for text, typ in EXPECTED_TYPES.items():
        assert rb.attributes[norm(text)].type == typ, (text, rb.attributes[norm(text)].type, typ)


def test_curly_apostrophes_merge():
    _, s = store()
    a = s.get_attribute("the applicant’s annual income")
    b = s.get_attribute("the applicant's annual income")
    assert a["found"] and a["text"] == b["text"]
    assert len(a["used_by"]) >= 2


def test_negative_text_from_data_model():
    _, s = store()
    a = s.get_attribute("the applicant is not a citizen")
    assert a["found"] and a["text"] == "the applicant is a citizen"
    neg = [u for u in a["used_by"] if u["id"] == "Rules/Eligibility.docx#rule 6"]
    assert neg and neg[0]["negated"] is True


def test_relationship_linked_to_entity():
    _, s = store()
    g = s.g
    rel = "rel:" + norm("the applicant's children")
    targets = [g.nodes[v]["name"] for _, v, d in g.out_edges(rel, data=True) if d["type"] == "TARGETS"]
    assert targets == ["child"]


def test_entities():
    _, s = store()
    e = s.entity("child")
    texts = {a["text"] for a in e["attributes"]}
    assert "the child is immunised" in texts and "the child's age" in texts


def test_diagnostics():
    _, s = store()
    d = s.diagnostics()
    multi = {m["attribute"]: sorted(m["rules"]) for m in d["attributes_proven_by_multiple_rules"]}
    assert multi == {f"{A} meets the age test": ["Rules/Eligibility.docx#rule 2",
                                                 "Sub/Eligibility.docx#rule 1"]}
    cyc = [set(norm(x) for x in c) for c in d["dependency_cycles"]]
    assert {norm(f"{A} is eligible for support"), norm(f"{A}'s annual income")} in cyc
    assert f"{A}'s marital status" in d["defined_but_unused_attributes"]
    assert f"{A}'s declared income" in d["attributes_not_in_data_model"]


def test_lineage():
    _, s = store()
    up = s.upstream("the weekly payment")
    assert set(up["base_inputs"]) >= {f"{A}'s date of birth", "the assessment date",
                                      "the child's vaccination status", "the partner's income"}
    down = s.downstream("the child's date of birth")
    names = {x["attribute"] for x in down["affected_attributes"]}
    # child dob -> child's age -> care allowance only (not the applicant's age)
    assert names == {"the child's age", "the child's care allowance"}


def test_search_ranking():
    _, s = store()
    r = s.search("vaccination")
    assert r[0]["type"] == "Attribute" and r[0]["text"] == "the child's vaccination status"
    r = s.search("overall eligibility", kind="rule")
    assert r[0]["id"] == "Rules/Eligibility.docx#rule 1"


def test_partial_rule_id_lookup():
    _, s = store()
    assert s.get_rule("Sub/Eligibility.docx#rule 2")["found"]
    amb = s.get_rule("Eligibility.docx#rule 1")
    assert amb["found"] is False and len(amb["candidates"]) >= 2
