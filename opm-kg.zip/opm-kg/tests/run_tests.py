"""Minimal test runner (no pytest needed):  python tests/run_tests.py
With pytest installed, `python -m pytest -q tests` runs the same tests."""
import importlib.util
import inspect
import os
import sys
import tempfile
import traceback
import types
from pathlib import Path

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))

if "pytest" not in sys.modules:
    try:
        import pytest  # noqa: F401
    except ImportError:
        shim = types.ModuleType("pytest")
        shim.fixture = lambda *a, **k: (a[0] if a and callable(a[0]) else (lambda f: f))
        sys.modules["pytest"] = shim


def main():
    passed = failed = 0
    for fname in sorted(os.listdir(HERE)):
        if not (fname.startswith("test_") and fname.endswith(".py")):
            continue
        spec = importlib.util.spec_from_file_location(fname[:-3], os.path.join(HERE, fname))
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        fixtures = {}
        for name, fn in inspect.getmembers(mod, inspect.isfunction):
            if not name.startswith("test_"):
                continue
            kwargs = {}
            for p in inspect.signature(fn).parameters:
                if p == "tmp_path":
                    kwargs[p] = Path(tempfile.mkdtemp())
                else:
                    if p not in fixtures:
                        fixtures[p] = getattr(mod, p)()
                    kwargs[p] = fixtures[p]
            try:
                fn(**kwargs)
                passed += 1
            except Exception:
                failed += 1
                print(f"FAIL {fname}::{name}")
                traceback.print_exc()
    print(f"\n{passed} passed, {failed} failed")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
