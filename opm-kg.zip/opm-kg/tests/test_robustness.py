"""Robustness: random malformed input never raises; large rulebases stay fast."""
import io
import os
import random
import sys
import time
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "tests"))

from opm_kg.authoring import validate_rule  # noqa: E402
from opm_kg.graph import GraphStore, build_graph  # noqa: E402
from opm_kg.parsers import load_rulebase  # noqa: E402
from opm_kg.rule_text import extract_refs, parse_indented, refs_from_lines  # noqa: E402
from test_accuracy import store as dummy_store  # noqa: E402

PIECES = ["the applicant", "'s", " age", " is", " not", " (", ")", " ,", " and", " or", " if",
          " = ", " <", " >=", '"', " ForAll(", " InstanceSum(", " either", " both", "\t", "\n  ",
          " otherwise", " 18", " -", " +", " *", "’", " it is not the case that", " Date(",
          "  ", ".", ":", " ", " the child"]


def test_fuzz_parser_and_validator_never_raise():
    rnd = random.Random(1234)
    _, s = dummy_store()
    for _ in range(1500):
        text = "".join(rnd.choice(PIECES) for _ in range(rnd.randint(1, 40)))
        extract_refs(text)
        refs_from_lines(parse_indented(text))
        validate_rule(s, text)


def _big_project(n_rules=3000):
    import docx
    from opm_kg.authoring import _ensure_styles
    docs = []
    per_doc = 500
    k = 0
    for d_i in range(n_rules // per_doc):
        d = docx.Document()
        _ensure_styles(d)
        for _ in range(per_doc):
            # a layered dependency chain with fan-in, like real rulebases
            d.add_paragraph(f"the level {k} result is met if", style="OPM - conclusion")
            deps = [f"the level {j} result is met" for j in (k - 1, k - 7, k - 31) if j >= 0]
            deps.append(f"the input {k % 97} value > {k % 13}")
            for i, t in enumerate(deps):
                d.add_paragraph(t + (" and" if i < len(deps) - 1 else ""), style="OPM - level 1")
            k += 1
        b = io.BytesIO()
        d.save(b)
        docs.append((f"Rules/Chain{d_i}.docx", b.getvalue()))
    zb = io.BytesIO()
    with zipfile.ZipFile(zb, "w") as z:
        for name, data in docs:
            z.writestr(name, data)
    return zb.getvalue()


def test_scale(tmp_path):
    zp = tmp_path / "big.zip"
    zp.write_bytes(_big_project())
    t0 = time.time()
    rb = load_rulebase(str(zp))
    s = GraphStore(build_graph(rb))
    t_build = time.time() - t0
    assert len(rb.rules) == 3000
    t0 = time.time()
    up = s.upstream("the level 2999 result is met", depth=50)
    down = s.downstream("the input 0 value", depth=50)
    s.search("level 1500 result")
    s.diagnostics()
    v = validate_rule(s, "the level 0 result is met if\n  the level 2999 result is met",
                      replacing_rule_id="Chain0.docx#rule 1")
    t_query = time.time() - t0
    assert any("circular" in e for e in v["errors"])
    assert len(up["dependencies"]) > 1000 and down["affected_rules"]
    print(f"   scale: build {t_build:.1f}s, queries+validate {t_query:.1f}s")
    assert t_build < 60 and t_query < 30, (t_build, t_query)
