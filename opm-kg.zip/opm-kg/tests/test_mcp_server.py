"""Start server.py over stdio with a real MCP client and call every tool."""
import asyncio
import json
import os
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "tests", "fixtures"))


def _graph(tmp):
    import make_dummy
    zp = make_dummy.build()
    out = os.path.join(tmp, "graph.json")
    subprocess.check_call([sys.executable, "-m", "opm_kg.cli", "build", zp, "-o", out], cwd=ROOT,
                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return out


async def _run(env, calls):
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client
    params = StdioServerParameters(command=sys.executable, args=[os.path.join(ROOT, "server.py")],
                                   env={**os.environ, **env})
    out = {}
    async with stdio_client(params) as (r, w):
        async with ClientSession(r, w) as s:
            await s.initialize()
            out["_tools"] = sorted(t.name for t in (await s.list_tools()).tools)
            out["_prompts"] = sorted(p.name for p in (await s.list_prompts()).prompts)
            out["_resources"] = sorted(str(r.uri) for r in (await s.list_resources()).resources)
            pr = await s.get_prompt("rules_from_requirement", {"requirement": "raise the age to 21"})
            assert "raise the age to 21" in pr.messages[0].content.text
            for name, args in calls:
                res = await s.call_tool(name, args)
                assert not res.isError, (name, res.content)
                text = res.content[0].text if res.content else "null"
                try:
                    out[name] = json.loads(text)
                except json.JSONDecodeError:
                    out[name] = [json.loads(c.text) for c in res.content]
    return out


def test_all_tools():
    tmp = tempfile.mkdtemp()
    g = _graph(tmp)
    calls = [
        ("rulebase_overview", {}),
        ("search", {"query": "vaccination", "limit": 3}),
        ("search", {"query": "x", "kind": "bogus"}),
        ("get_attribute", {"text": "the applicant is not a citizen"}),
        ("get_rule", {"rule_id": "Sub/Eligibility.docx#rule 2"}),
        ("trace_dependencies", {"attribute": "the weekly payment"}),
        ("impact_analysis", {"attribute": "the child's date of birth"}),
        ("list_rules_in_document", {"document": "Payments"}),
        ("list_entities", {}),
        ("get_entity", {"name": "child"}),
        ("list_base_attributes", {}),
        ("rulebase_diagnostics", {}),
        ("validate_rule_text", {"rule_text": "the child is immunised if\n  the child has a medical exemption",
                                "replacing_rule_id": "Rules/Eligibility.docx#rule 7"}),
        ("export_rules_docx", {"rules": [{"text": "the a if\n  the b"}], "file_name": "out"}),
        ("export_rules_docx", {"rules": []}),
        ("analyze_requirement", {"requirement": "Raise the minimum age from 18 to 21."}),
        ("evaluate_rule", {"rule_text": "the t = 40 if\n  the q and\n  the n >= 1\nthe t = 0 otherwise",
                           "facts": {"the q": True, "the n": 2}}),
        ("check_rule_examples", {"rule_text": "the a if\n  the b > 1",
                                 "examples": [{"inputs": {"the b": 2}, "expected": True}]}),
        ("generate_test_cases", {"rule_text": "the a if\n  the b > 1"}),
        ("export_change_package", {"title": "T", "requirement": "R", "file_name": "pkg",
                                   "changes": [{"rule_text": "the new flag if\n  the applicant is single"}]}),
        ("reload_graph", {}),
    ]
    res = asyncio.run(_run({"OPM_KG_GRAPH": g, "OPM_KG_OUTPUT_DIR": tmp}, calls))
    assert len(res["_tools"]) == 19, res["_tools"]
    assert res["_prompts"] == ["rules_from_requirement"]
    assert res["_resources"] == ["opm://authoring-guide"]
    assert res["analyze_requirement"]["relevant_rules"]
    assert res["evaluate_rule"]["value"] == 40
    assert res["export_change_package"]["status"] == "READY"
    assert res["rulebase_overview"]["Rule"] == 15
    assert res["get_attribute"]["text"] == "the applicant is a citizen"
    assert res["get_rule"]["found"]
    assert res["validate_rule_text"]["valid"]
    assert os.path.exists(os.path.join(tmp, "out.docx"))
    assert "error" in res["export_rules_docx"]  # last call (empty rules) overwrote the key
    assert res["check_rule_examples"]["all_pass"]
    assert os.path.exists(os.path.join(tmp, "pkg_rules.docx"))
    assert res["reload_graph"]["reloaded"]


def test_missing_graph_is_reported_not_crashed():
    res = asyncio.run(_run({"OPM_KG_GRAPH": "/nonexistent/graph.json"}, [("rulebase_overview", {})]))
    assert res["rulebase_overview"]["kind"] == "configuration"
    assert "graph file not found" in res["rulebase_overview"]["error"]


def test_bad_backend_is_reported():
    res = asyncio.run(_run({"OPM_KG_BACKEND": "neo4j", "NEO4J_PASSWORD": "x"}, [("rulebase_overview", {})]))
    assert "error" in res["rulebase_overview"]  # neo4j driver missing or server unreachable
