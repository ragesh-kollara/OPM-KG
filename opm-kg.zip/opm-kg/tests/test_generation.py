"""Step 2 - requirement to rules: evaluator, context retrieval, tests, examples, package."""
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "tests"))

from opm_kg.authoring import format_rule, validate_rule  # noqa: E402
from opm_kg.evaluator import evaluate_rule  # noqa: E402
from opm_kg.package import export_change_package  # noqa: E402
from opm_kg.parsers import load_rulebase  # noqa: E402
from opm_kg.requirements import check_examples, generate_test_cases, requirement_context  # noqa: E402
from test_accuracy import store as dummy_store  # noqa: E402

A, E, F = "the applicant's age", "the applicant is eligible for support", "the applicant is flagged for review"
INC, KIDS = "the applicant's annual income", "the applicant's number of children"
Q = "the applicant qualifies for the hardship top-up"
REQ = ("BR-101: The minimum age for social support is raised from 18 to 21. The upper age limit "
       "(under 67) is unchanged.\nBR-102: Introduce a weekly hardship top-up. Applicants who are eligible "
       "for support and whose annual income is below 15,000 receive 60 per week if they have 3 or more "
       "children, 40 per week if they have 1 or 2 children, and nothing otherwise.\nBR-103: Applicants who "
       "are flagged for review must not receive the hardship top-up.")
C_AGE = f"the applicant meets the age test if\n  {A} >= 21 and\n  {A} < 67"
C_Q = f"{Q} if\n  {E} and\n  {INC} < 15000 and\n  the applicant is not flagged for review"
C_KIDS = f"{KIDS} = InstanceCount(the applicant's children)"
C_TOPUP = (f"the applicant's weekly hardship top-up = 60 if\n  {Q} and\n  {KIDS} >= 3\n"
           f"the applicant's weekly hardship top-up = 40 if\n  {Q} and\n  {KIDS} >= 1\n"
           f"the applicant's weekly hardship top-up = 0 otherwise")


# ---------------------------------------------------------------------------- evaluator
def test_evaluator_branches_and_unknowns():
    assert evaluate_rule(C_TOPUP, {Q: True, KIDS: 3})["value"] == 60
    assert evaluate_rule(C_TOPUP, {Q: "true", KIDS: "1"})["value"] == 40
    assert evaluate_rule(C_TOPUP, {Q: False})["value"] == 0
    assert evaluate_rule(C_TOPUP, {KIDS: 2})["value"] is None          # unknown propagates


def test_evaluator_groups_negation_functions():
    r = """the x if
  the a is known and
  either
    the n < 10 or
    both
      the flag and
      the n < 20 and
  the applicant is not flagged"""
    base = {"the a": 1, "the applicant is flagged": False}
    assert evaluate_rule(r, {**base, "the n": 5})["value"] is True
    assert evaluate_rule(r, {**base, "the n": 15, "the flag": True})["value"] is True
    assert evaluate_rule(r, {**base, "the n": 15, "the flag": False})["value"] is False
    assert evaluate_rule(r, {**base, "the n": 5, "the applicant is flagged": True})["value"] is False
    assert evaluate_rule(r, {"the n": 5, "the applicant is flagged": False})["value"] is False  # a unknown
    assert evaluate_rule("the age = YearDifference(the dob, CurrentDate())", {"the dob": "2000-06-15"},
                         today="2026-06-14")["value"] == 25
    assert evaluate_rule("the t = (the a + the b) * 2 - the c / 4", {"the a": 1, "the b": 2, "the c": 8})["value"] == 4
    assert evaluate_rule("the x = If(the a > 5, the a * 2, 0)", {"the a": 6})["value"] == 12
    assert evaluate_rule('the x if\n  the name = "Bob"', {"the name": "bob"})["value"] is True
    assert "unsupported" in evaluate_rule(C_KIDS, {})


# ---------------------------------------------------------------------------- context
def test_requirement_context_finds_thresholds_and_problems():
    _, s = dummy_store()
    ctx = requirement_context(s, REQ)
    assert "101" not in ctx["numbers_in_requirement"]             # requirement ids ignored
    assert {"18", "21", "15000"} <= set(ctx["numbers_in_requirement"])
    ids = {r["id"]: r for r in ctx["relevant_rules"]}
    assert "18" in ids["Rules/Eligibility.docx#rule 2"]["contains_requirement_numbers"]
    assert "Sub/Eligibility.docx#rule 1" in ids
    texts = {a["text"] for a in ctx["relevant_attributes"]}
    assert {"the applicant meets the age test", E, F} <= texts
    probs = ctx["existing_problems_in_scope"]["attributes_proven_by_multiple_rules"]
    assert probs and probs[0]["attribute"] == "the applicant meets the age test"
    assert "modify" in ctx["intent"] and "add" in ctx["intent"]


# ---------------------------------------------------------------------------- tests / examples
def test_generated_tests_cover_boundaries():
    t = generate_test_cases(C_AGE)
    assert t["inputs"][A] == [20, 21, 22, 66, 67, 68]
    got = {c["inputs"][A]: c["expected"] for c in t["cases"]}
    assert got == {20: False, 21: True, 22: True, 66: True, 67: False, 68: False}
    assert t["branches_never_reached"] == []


def test_unreachable_branch_detected():
    r = "the x = 1 if\n  the a >= 1\nthe x = 2 if\n  the a >= 5\nthe x = 0 otherwise"
    assert generate_test_cases(r)["branches_never_reached"] == [2]


def test_unsupported_rule_is_not_reported_as_unreachable():
    t = generate_test_cases(C_KIDS)
    assert t["simulated"] is False and t["branches_never_reached"] == []


def test_examples_catch_wrong_draft():
    wrong = f"{Q} if\n  {E} and\n  {INC} <= 15000"
    r = check_examples(wrong, [{"inputs": {E: True, INC: 15000, F: False}, "expected": False},
                               {"inputs": {E: True, INC: 12000, F: True}, "expected": False}])
    assert r["failed"] == 2


def test_end_to_end_examples_through_draft_chain():
    ex = [{"inputs": {E: True, INC: 12000, F: False, KIDS: 2}, "expected": 40},
          {"inputs": {E: True, INC: 12000, F: False, KIDS: 4}, "expected": 60},
          {"inputs": {E: True, INC: 15000, F: False, KIDS: 2}, "expected": 0}]
    assert check_examples(C_TOPUP, ex, supporting_rules=[C_Q])["all_pass"]
    # without the supporting draft, 'qualifies' is unknown -> examples cannot pass
    assert not check_examples(C_TOPUP, ex)["all_pass"]


# ---------------------------------------------------------------------------- validator with drafts
def test_validator_knows_sibling_drafts():
    _, s = dummy_store()
    v = validate_rule(s, C_TOPUP, other_drafts=[C_Q, C_KIDS])
    assert v["valid"] and not v["warnings"], v
    v = validate_rule(s, C_TOPUP)
    assert any("not found" in w for w in v["warnings"])
    v = validate_rule(s, C_Q, other_drafts=[f"{Q} if\n  the applicant is single"])
    assert any("also concluded by another rule in this change" in e for e in v["errors"])
    v = validate_rule(s, f"{Q} if\n  the applicant's weekly hardship top-up > 0", other_drafts=[C_TOPUP])
    assert any("circular" in e for e in v["errors"])


def test_merge_two_rules_with_replacing_ids():
    _, s = dummy_store()
    assert not validate_rule(s, C_AGE, "Rules/Eligibility.docx#rule 2")["valid"]
    assert validate_rule(s, C_AGE, "Rules/Eligibility.docx#rule 2|Sub/Eligibility.docx#rule 1")["valid"]


# ---------------------------------------------------------------------------- package
def _changes(bad=False):
    return [
        {"change_id": "C1", "requirement_ref": "BR-101", "name": "Age test", "rule_text": C_AGE,
         "replacing_rule_id": ["Rules/Eligibility.docx#rule 2", "Sub/Eligibility.docx#rule 1"],
         "examples": [{"inputs": {A: 20}, "expected": False}, {"inputs": {A: 21}, "expected": True}]},
        {"change_id": "C2", "name": "Qualification", "rule_text": C_Q.replace("< 15000", "<= 15000") if bad else C_Q,
         "examples": [{"inputs": {E: True, INC: 15000, F: False}, "expected": False}]},
        {"change_id": "C3", "name": "Children", "rule_text": C_KIDS},
        {"change_id": "C4", "name": "Top-up", "rule_text": C_TOPUP,
         "examples": [{"inputs": {E: True, INC: 12000, F: False, KIDS: 2}, "expected": 40}]},
    ]


def test_change_package_ready(tmp_path):
    _, s = dummy_store()
    res = export_change_package(s, "CR test", REQ, _changes(), str(tmp_path), "cr")
    assert res["status"] == "READY", res
    for f in res["files"].values():
        assert os.path.exists(f)
    rb = load_rulebase(res["files"]["rules"])
    got = sorted(format_rule(r.text) for r in rb.rules)
    assert got == sorted(format_rule(t) for t in (C_AGE, C_Q, C_KIDS, C_TOPUP))
    assert [r.kind for r in rb.rules if "top-up =" in r.text] == ["table"]


def test_change_package_needs_work_when_example_fails(tmp_path):
    _, s = dummy_store()
    res = export_change_package(s, "CR bad", REQ, _changes(bad=True), str(tmp_path), "bad")
    assert res["status"] == "NEEDS WORK"
    c2 = [c for c in res["changes"] if c["change_id"] == "C2"][0]
    assert c2["status"] == "NEEDS WORK" and c2["examples"] == "0/1 pass"
