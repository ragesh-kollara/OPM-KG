"""Neo4j backend checks that run without a Neo4j server.

* Neo4jStore's traversal primitives are fed by a fake `_q` that answers the primitive Cypher
  queries from the in-memory graph, so the Python glue and the shared traversal logic are checked
  for parity with GraphStore.
* The .cypher export is checked for structure and correct literal escaping.
"""
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "tests"))

from opm_kg.graph import build_graph  # noqa: E402
from opm_kg.neo4j_store import Neo4jStore, cypher_literal, export_cypher, _grouped  # noqa: E402
from opm_kg.parsers import load_rulebase  # noqa: E402
from test_accuracy import store as dummy_store  # noqa: E402


class FakeNeo4j(Neo4jStore):
    """Answers only the primitive queries used by TraversalMixin, from a GraphStore."""

    def __init__(self, gs):
        self.gs = gs
        self.driver = None
        self.database = None

    def _q(self, cypher, **p):
        g = self.gs.g
        attrs = {d["key"]: (n, d) for n, d in g.nodes(data=True) if d.get("label") == "Attribute"}
        if cypher.startswith("MATCH (a:Attribute) WHERE a.key = $k OR a.negative_key = $k"):
            k = p["k"]
            return [{"key": d["key"]} for _, d in attrs.values()
                    if d["key"] == k or d.get("negative_key") == k][:1]
        if cypher.startswith("MATCH (a:Attribute) WHERE a.key IN $c RETURN a.key AS key"):
            return [{"key": c} for c in p["c"] if c in attrs][:1]
        if cypher.startswith("MATCH (a:Attribute {key:$k}) RETURN a.text AS t"):
            return [{"t": attrs[p["k"]][1]["text"]}] if p["k"] in attrs else []
        if "[e:DEPENDS_ON]" in cypher and "AS fk" in cypher:
            up = cypher.startswith("MATCH (a:Attribute)-[e:DEPENDS_ON]->(b:Attribute)")
            rows = []
            for k in p["keys"]:
                aid = f"attr:{k}"
                edges = g.out_edges(aid, data=True) if up else g.in_edges(aid, data=True)
                for u, v, e in edges:
                    if e["type"] != "DEPENDS_ON":
                        continue
                    other = v if up else u
                    rows.append({"fk": k, "tk": other[5:], "to_text": g.nodes[other]["text"],
                                 "rule": e.get("rule"), "to_is_base": self.gs._is_base(other)})
            return rows
        if cypher.startswith("MATCH (r:Rule)-[:USES]->(a:Attribute) WHERE a.key IN $keys"):
            return [{"id": r} for r in self.gs._rules_using(p["keys"])]
        if cypher.startswith("MATCH (a:Attribute)-[:DEPENDS_ON]->(b:Attribute) RETURN DISTINCT"):
            return [{"a": a, "b": b, "ta": ta, "tb": tb} for a, b, ta, tb in set(self.gs._all_dep_pairs())]
        raise AssertionError(f"unexpected query: {cypher}")

    def suggest(self, text, n=5):
        return self.gs.suggest(text, n)


def test_traversal_parity_with_graphstore():
    _, gs = dummy_store()
    fake = FakeNeo4j(gs)
    for attr in ["the weekly payment", "the applicant is eligible for support",
                 "the applicant is not a citizen", "the child’s date of birth", "nonexistent thing"]:
        assert fake.upstream(attr) == gs.upstream(attr), attr
        assert fake.downstream(attr) == gs.downstream(attr), attr
        assert fake.depends_on_closure(attr) == gs.depends_on_closure(attr), attr
    norm_cycles = lambda cs: sorted(sorted(c) for c in cs)  # noqa: E731
    assert norm_cycles(fake.dependency_cycles()) == norm_cycles(gs.dependency_cycles())


def test_cypher_literal_escaping():
    assert cypher_literal("the applicant's age") == r"'the applicant\'s age'"
    assert cypher_literal('a "quoted" \\ back') == r"""'a "quoted" \\ back'"""
    assert cypher_literal({"key": "x", "n": 1, "b": True, "z": None}) == "{`key`: 'x', `n`: 1, `b`: true, `z`: null}"
    assert cypher_literal("line1\nline2") == r"'line1\nline2'"


def test_cypher_export_structure(tmp_path):
    rb, gs = dummy_store()
    path = str(tmp_path / "g.cypher")
    export_cypher(gs.g, path)
    text = open(path, encoding="utf-8").read()
    stmts = [s for s in text.split(";\n") if s.strip() and not s.strip().startswith("//")]
    nodes, edges = _grouped(gs.g)
    merges = [s for s in stmts if " MERGE (n:" in s]
    creates = [s for s in stmts if " CREATE (a)-[e:" in s]
    assert len(merges) == len(nodes) and len(creates) == len(edges)
    # every statement balanced once string literals are removed
    for s in stmts:
        bare = re.sub(r"'(?:\\.|[^'\\])*'", "''", s)
        for o, c in ("()", "[]", "{}"):
            assert bare.count(o) == bare.count(c), s[:200]
    # every node row made it into the script
    assert sum(len(v) for v in nodes.values()) == gs.g.number_of_nodes()
    assert sum(len(v) for v in edges.values()) == gs.g.number_of_edges()


def test_every_node_has_its_key_property():
    _, gs = dummy_store()
    from opm_kg.neo4j_store import LABEL_KEYS
    for n, d in gs.g.nodes(data=True):
        assert d.get("label") in LABEL_KEYS, (n, d)
        assert d.get(LABEL_KEYS[d["label"]]), (n, d)
